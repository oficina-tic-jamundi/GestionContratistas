<?php
// ?nico archivo PHP p?blico de SIGCON: incluye el front controller real, que est? FUERA del
// document root. Reemplace /home/USUARIO por la ruta real de la cuenta de cPanel.
putenv('SIGCON_ENV_DIR=/home/USUARIO/sigcon');
require '/home/USUARIO/sigcon/backend/public/index.php';
