# database/

- `migrations/` — migraciones SQL versionadas (ver `docs/decisions/ADR-011-migraciones.md`).
- `seeds/` — **solo datos ficticios** para desarrollo y pruebas. Nunca datos reales de la
  Alcaldía.
- `documentation/` — material de apoyo del modelo de datos (diagramas exportados, etc.).

Las convenciones y el diccionario de datos están en `docs/database/`.
