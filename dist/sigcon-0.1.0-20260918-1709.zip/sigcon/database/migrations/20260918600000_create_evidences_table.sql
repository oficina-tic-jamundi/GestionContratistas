-- Evidencias fotográficas georreferenciadas (ADR-006, ADR-016).
-- Se conservan el original (acceso restringido) y la versión oficial con marca de agua
-- generada en el servidor con la hora oficial.

CREATE TABLE evidences (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    contract_id BIGINT UNSIGNED NOT NULL,
    -- Obligación, tarea o subtarea a la que corresponde la foto.
    activity_id BIGINT UNSIGNED NOT NULL,
    description VARCHAR(500) NULL,

    -- Original tal como lo envió el dispositivo (nunca se modifica ni se redimensiona).
    original_path VARCHAR(255) NOT NULL,
    original_mime VARCHAR(50) NOT NULL,
    original_size_bytes INT UNSIGNED NOT NULL,
    original_sha256 CHAR(64) NOT NULL,
    width INT UNSIGNED NOT NULL,
    height INT UNSIGNED NOT NULL,

    -- Versión oficial (JPEG con marca de agua) y miniatura, generadas en el servidor.
    official_path VARCHAR(255) NOT NULL,
    official_sha256 CHAR(64) NOT NULL,
    thumbnail_path VARCHAR(255) NOT NULL,

    -- Ubicación reportada por el dispositivo. Nunca se inventa: sin coordenadas el estado lo explica.
    location_status VARCHAR(20) NOT NULL,
    latitude DECIMAL(9,6) NULL,
    longitude DECIMAL(9,6) NULL,
    accuracy_m DECIMAL(9,2) NULL,
    altitude_m DECIMAL(8,2) NULL,
    heading_deg DECIMAL(5,2) NULL,
    speed_mps DECIMAL(7,2) NULL,
    location_captured_at DATETIME NULL,

    -- Hora del dispositivo (informativa) y hora oficial del servidor (la de la marca de agua).
    device_captured_at DATETIME NULL,
    captured_at DATETIME NOT NULL,
    captured_by BIGINT UNSIGNED NOT NULL,

    status VARCHAR(20) NOT NULL DEFAULT 'active',
    withdrawn_reason VARCHAR(500) NULL,
    withdrawn_at DATETIME NULL,
    withdrawn_by BIGINT UNSIGNED NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_evidences_uuid (uuid),
    UNIQUE KEY uq_evidences_original_path (original_path),
    KEY idx_evidences_contract (contract_id, captured_at),
    KEY idx_evidences_activity (activity_id, captured_at),
    KEY idx_evidences_original_sha (contract_id, original_sha256),
    CONSTRAINT chk_evidences_location_status CHECK (location_status IN ('ok', 'low_accuracy', 'denied', 'unavailable', 'timeout')),
    -- Hay coordenadas si y solo si el dispositivo las entregó.
    CONSTRAINT chk_evidences_coordinates CHECK (
        (location_status IN ('ok', 'low_accuracy')) = (latitude IS NOT NULL AND longitude IS NOT NULL AND accuracy_m IS NOT NULL)
    ),
    CONSTRAINT chk_evidences_latitude CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT chk_evidences_longitude CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180),
    CONSTRAINT chk_evidences_status CHECK (status IN ('active', 'withdrawn')),
    CONSTRAINT chk_evidences_withdrawn CHECK (
        (status = 'withdrawn') = (withdrawn_reason IS NOT NULL AND withdrawn_at IS NOT NULL AND withdrawn_by IS NOT NULL)
    ),
    CONSTRAINT fk_evidences_contract FOREIGN KEY (contract_id) REFERENCES contracts (id),
    CONSTRAINT fk_evidences_activity FOREIGN KEY (activity_id) REFERENCES activities (id),
    CONSTRAINT fk_evidences_captured_by FOREIGN KEY (captured_by) REFERENCES users (id),
    CONSTRAINT fk_evidences_withdrawn_by FOREIGN KEY (withdrawn_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permissions (code, module, description) VALUES
    ('evidence.capture', 'evidence', 'Registrar evidencias fotográficas en sus propios contratos (contratista)'),
    ('evidence.view_original', 'evidence', 'Consultar la fotografía original, sin marca de agua');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'evidence.capture' WHERE r.code = 'contractor';
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'evidence.view_original' WHERE r.code = 'admin';
