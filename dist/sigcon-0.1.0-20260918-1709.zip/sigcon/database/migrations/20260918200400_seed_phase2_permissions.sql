-- Permisos de la Fase 2 (dependencias, contratistas, contratos).

INSERT INTO permissions (code, module, description) VALUES
    ('departments.view', 'departments', 'Consultar dependencias'),
    ('departments.manage', 'departments', 'Crear, modificar y desactivar dependencias'),
    ('contractors.view', 'contractors', 'Consultar contratistas'),
    ('contractors.manage', 'contractors', 'Crear, modificar y desactivar contratistas'),
    ('contracts.view_all', 'contracts', 'Consultar todos los contratos'),
    ('contracts.view_assigned', 'contracts', 'Consultar los contratos que supervisa'),
    ('contracts.view_own', 'contracts', 'Consultar sus propios contratos (contratista)'),
    ('contracts.manage', 'contracts', 'Crear y modificar contratos y cambiar su estado'),
    ('contracts.supervise', 'contracts', 'Puede ser designado supervisor de contratos');

-- Administrador: gestión completa. No recibe los permisos propios de otros perfiles
-- (ser supervisor o ver "sus" contratos como contratista).
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p
  ON p.code IN ('departments.view', 'departments.manage', 'contractors.view', 'contractors.manage',
                'contracts.view_all', 'contracts.manage')
WHERE r.code = 'admin';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p
  ON p.code IN ('departments.view', 'contracts.view_assigned', 'contracts.supervise')
WHERE r.code = 'supervisor';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p
  ON p.code IN ('contracts.view_own')
WHERE r.code = 'contractor';
