-- Obligaciones contractuales, tareas y subtareas (árbol de hasta 3 niveles) y registro de avances.
-- Reglas: ver ADR-013 (propuesta pendiente de validación institucional).

CREATE TABLE activities (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    contract_id BIGINT UNSIGNED NOT NULL,
    parent_id BIGINT UNSIGNED NULL,
    -- obligation (nivel 1, sin padre) → task (nivel 2) → subtask (nivel 3)
    level VARCHAR(20) NOT NULL,
    position INT UNSIGNED NOT NULL DEFAULT 1,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    -- Peso relativo frente a sus hermanos para el promedio ponderado del padre.
    weight DECIMAL(6,2) NOT NULL DEFAULT 1.00,
    -- En hojas: último avance declarado. En nodos con hijos: valor calculado (caché).
    progress DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    due_date DATE NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_activities_uuid (uuid),
    KEY idx_activities_contract (contract_id, parent_id, position),
    KEY idx_activities_parent (parent_id),
    CONSTRAINT chk_activities_level CHECK (level IN ('obligation', 'task', 'subtask')),
    CONSTRAINT chk_activities_root CHECK ((level = 'obligation') = (parent_id IS NULL)),
    CONSTRAINT chk_activities_weight CHECK (weight > 0 AND weight <= 1000),
    CONSTRAINT chk_activities_progress CHECK (progress >= 0 AND progress <= 100),
    CONSTRAINT fk_activities_contract FOREIGN KEY (contract_id) REFERENCES contracts (id),
    CONSTRAINT fk_activities_parent FOREIGN KEY (parent_id) REFERENCES activities (id),
    CONSTRAINT fk_activities_created_by FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT fk_activities_updated_by FOREIGN KEY (updated_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cada declaración de avance (solo inserción). Base para los informes (Fase 5).
CREATE TABLE progress_updates (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    activity_id BIGINT UNSIGNED NOT NULL,
    previous_progress DECIMAL(5,2) NOT NULL,
    new_progress DECIMAL(5,2) NOT NULL,
    note TEXT NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    recorded_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_progress_updates_uuid (uuid),
    KEY idx_progress_updates_activity (activity_id, recorded_at),
    CONSTRAINT chk_progress_updates_range CHECK (new_progress >= 0 AND new_progress <= 100),
    CONSTRAINT fk_progress_updates_activity FOREIGN KEY (activity_id) REFERENCES activities (id),
    CONSTRAINT fk_progress_updates_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permissions (code, module, description) VALUES
    ('activities.execute', 'activities', 'Planear tareas y registrar avances en sus propios contratos (contratista)');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'activities.execute' WHERE r.code = 'contractor';
