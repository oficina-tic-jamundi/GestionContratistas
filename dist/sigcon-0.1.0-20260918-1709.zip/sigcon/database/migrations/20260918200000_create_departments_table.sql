-- Dependencias / Secretarías de la Alcaldía.
-- No se eliminan: se desactivan (los contratos históricos las siguen referenciando).

CREATE TABLE departments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    -- Sigla o código interno (ej. SPLAN). Único.
    code VARCHAR(20) NOT NULL,
    name VARCHAR(150) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_departments_uuid (uuid),
    UNIQUE KEY uq_departments_code (code),
    UNIQUE KEY uq_departments_name (name),
    KEY idx_departments_status (status),
    CONSTRAINT chk_departments_status CHECK (status IN ('active', 'inactive')),
    CONSTRAINT chk_departments_code_format CHECK (code REGEXP '^[A-Z0-9][A-Z0-9_-]{1,19}$'),
    CONSTRAINT fk_departments_created_by FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT fk_departments_updated_by FOREIGN KEY (updated_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dependencia principal a la que pertenece un usuario (funcionarios, supervisores).
-- Opcional: los contratistas se relacionan con dependencias a través de sus contratos.
ALTER TABLE users
    ADD COLUMN department_id BIGINT UNSIGNED NULL AFTER phone,
    ADD KEY idx_users_department (department_id),
    ADD CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments (id);
