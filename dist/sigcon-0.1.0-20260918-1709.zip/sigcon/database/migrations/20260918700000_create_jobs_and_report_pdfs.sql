-- Cola de trabajos en MySQL procesada por Cron (ADR-005, ADR-017) y PDF de cada versión de informe.

CREATE TABLE jobs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    type VARCHAR(60) NOT NULL,
    payload JSON NOT NULL,
    -- Evita encolar dos veces el mismo trabajo mientras está pendiente. Si ya está en proceso sí se
    -- permite otro: el cambio que lo originó puede no estar reflejado en la ejecución en curso.
    dedupe_key VARCHAR(191) NULL,
    active_dedupe_key VARCHAR(191) GENERATED ALWAYS AS (IF(status = 'pending', dedupe_key, NULL)) STORED,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    max_attempts INT UNSIGNED NOT NULL,
    available_at DATETIME NOT NULL,
    locked_until DATETIME NULL,
    locked_by VARCHAR(64) NULL,
    last_error VARCHAR(1000) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    completed_at DATETIME NULL,
    failed_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_jobs_uuid (uuid),
    UNIQUE KEY uq_jobs_active_dedupe (active_dedupe_key),
    KEY idx_jobs_claim (status, available_at),
    KEY idx_jobs_created (created_at),
    CONSTRAINT chk_jobs_status CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    CONSTRAINT chk_jobs_processing_lock CHECK ((status = 'processing') = (locked_until IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cada ejecución del procesador (permite saber si el Cron está funcionando).
CREATE TABLE job_runs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    runner_id VARCHAR(64) NOT NULL,
    started_at DATETIME NOT NULL,
    finished_at DATETIME NULL,
    processed INT UNSIGNED NOT NULL DEFAULT 0,
    failed INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_job_runs_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PDF de cada versión enviada. Su estado es independiente del estado del informe (§89).
ALTER TABLE report_versions
    ADD COLUMN pdf_status VARCHAR(20) NOT NULL DEFAULT 'pending',
    ADD COLUMN pdf_path VARCHAR(255) NULL,
    ADD COLUMN pdf_sha256 CHAR(64) NULL,
    ADD COLUMN pdf_size_bytes INT UNSIGNED NULL,
    ADD COLUMN pdf_generated_at DATETIME NULL,
    ADD CONSTRAINT chk_report_versions_pdf_status CHECK (pdf_status IN ('pending', 'ready', 'failed')),
    ADD CONSTRAINT chk_report_versions_pdf_ready CHECK ((pdf_status = 'ready') = (pdf_path IS NOT NULL AND pdf_sha256 IS NOT NULL));

-- Versiones enviadas antes de esta migración: se encola la generación de su PDF.
INSERT INTO jobs (uuid, type, payload, dedupe_key, status, attempts, max_attempts, available_at, created_at, updated_at)
SELECT UUID(), 'report.pdf', JSON_OBJECT('report_id', v.report_id, 'version', v.version),
       CONCAT('report.pdf:', v.report_id, ':v', v.version), 'pending', 0, 5, UTC_TIMESTAMP(), UTC_TIMESTAMP(), UTC_TIMESTAMP()
FROM report_versions v;

INSERT INTO permissions (code, module, description) VALUES
    ('jobs.manage', 'system', 'Consultar la cola de tareas en segundo plano y reintentar las fallidas');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'jobs.manage' WHERE r.code = 'admin';
