-- Documentos (ADR-014). Los archivos viven fuera del web root; aquí solo su metadato.
-- Los documentos no se eliminan: se retiran con motivo (trazabilidad).

CREATE TABLE document_types (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(150) NOT NULL,
    -- Entidad a la que aplica (hoy: contract; luego: report, payment...).
    entity_type VARCHAR(30) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    position INT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_document_types_code (entity_type, code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lista inicial GENÉRICA. La lista institucional (pólizas, RUT, certificados, etc.) está
-- pendiente de definición (ADR-014) y se agregará por migración.
INSERT INTO document_types (code, name, entity_type, position) VALUES
    ('signed_contract', 'Contrato firmado', 'contract', 1),
    ('start_minute', 'Acta de inicio', 'contract', 2),
    ('other', 'Otro documento', 'contract', 99);

CREATE TABLE documents (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    entity_type VARCHAR(30) NOT NULL,
    entity_id BIGINT UNSIGNED NOT NULL,
    document_type_id BIGINT UNSIGNED NOT NULL,
    description VARCHAR(255) NULL,
    -- Nombre original: solo para mostrar y para la descarga. Nunca se usa como ruta.
    original_name VARCHAR(255) NOT NULL,
    extension VARCHAR(10) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT UNSIGNED NOT NULL,
    sha256 CHAR(64) NOT NULL,
    -- Ruta relativa dentro de STORAGE_PATH (ej. private/2026/09/<uuid>.pdf).
    storage_path VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    withdrawn_reason VARCHAR(500) NULL,
    withdrawn_at DATETIME NULL,
    withdrawn_by BIGINT UNSIGNED NULL,
    uploaded_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    -- Hash solo mientras está vigente: impide duplicados activos pero permite volver a cargar
    -- un archivo que fue retirado.
    active_sha256 CHAR(64) GENERATED ALWAYS AS (IF(status = 'active', sha256, NULL)) STORED,
    PRIMARY KEY (id),
    UNIQUE KEY uq_documents_uuid (uuid),
    UNIQUE KEY uq_documents_storage (storage_path),
    UNIQUE KEY uq_documents_active_hash (entity_type, entity_id, active_sha256),
    KEY idx_documents_entity (entity_type, entity_id, status, created_at),
    CONSTRAINT chk_documents_status CHECK (status IN ('active', 'withdrawn')),
    CONSTRAINT chk_documents_withdrawn CHECK (status = 'active' OR (withdrawn_reason IS NOT NULL AND withdrawn_at IS NOT NULL)),
    CONSTRAINT chk_documents_size CHECK (size_bytes > 0),
    CONSTRAINT fk_documents_type FOREIGN KEY (document_type_id) REFERENCES document_types (id),
    CONSTRAINT fk_documents_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users (id),
    CONSTRAINT fk_documents_withdrawn_by FOREIGN KEY (withdrawn_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
