-- Historial de negocio (§42): responde "¿qué pasó con este contrato/informe?" en lenguaje
-- comprensible para los usuarios. Es distinto de audit_logs (auditoría técnica).
-- Solo inserción. Genérico por entidad para reutilizarlo en informes, pagos, etc.

CREATE TABLE business_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    entity_type VARCHAR(30) NOT NULL,
    entity_id BIGINT UNSIGNED NOT NULL,
    event VARCHAR(50) NOT NULL,
    -- Texto legible, generado por el sistema (ej. "Contrato activado").
    summary VARCHAR(255) NOT NULL,
    -- Observación escrita por el usuario (ej. motivo de una suspensión).
    comment TEXT NULL,
    from_status VARCHAR(20) NULL,
    to_status VARCHAR(20) NULL,
    user_id BIGINT UNSIGNED NULL,
    occurred_at DATETIME NOT NULL,
    metadata JSON NULL,
    PRIMARY KEY (id),
    KEY idx_business_history_entity (entity_type, entity_id, occurred_at),
    CONSTRAINT fk_business_history_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
