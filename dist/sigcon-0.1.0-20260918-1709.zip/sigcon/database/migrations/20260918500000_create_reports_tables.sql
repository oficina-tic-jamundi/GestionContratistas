-- Informes periódicos del contratista (ADR-015): flujo de revisión, versiones inmutables y
-- observaciones del supervisor.

CREATE TABLE reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    contract_id BIGINT UNSIGNED NOT NULL,
    -- Consecutivo por contrato (1, 2, 3...).
    number INT UNSIGNED NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    -- Contenido editable (solo en borrador o con observaciones).
    summary TEXT NULL,
    contractor_notes TEXT NULL,
    -- Última versión enviada y versión aprobada (inmutables en report_versions).
    current_version INT UNSIGNED NOT NULL DEFAULT 0,
    approved_version INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    approved_by BIGINT UNSIGNED NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_reports_uuid (uuid),
    UNIQUE KEY uq_reports_number (contract_id, number),
    KEY idx_reports_status (status, updated_at),
    KEY idx_reports_period (contract_id, period_start, period_end),
    CONSTRAINT chk_reports_status CHECK (status IN ('draft', 'submitted', 'in_review', 'observed', 'resubmitted', 'approved', 'rejected')),
    CONSTRAINT chk_reports_period CHECK (period_end >= period_start),
    CONSTRAINT chk_reports_approved CHECK ((status = 'approved') = (approved_version IS NOT NULL AND approved_at IS NOT NULL)),
    CONSTRAINT fk_reports_contract FOREIGN KEY (contract_id) REFERENCES contracts (id),
    CONSTRAINT fk_reports_approved_by FOREIGN KEY (approved_by) REFERENCES users (id),
    CONSTRAINT fk_reports_created_by FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Descripción de lo realizado en el período, por obligación.
CREATE TABLE report_items (
    report_id BIGINT UNSIGNED NOT NULL,
    activity_id BIGINT UNSIGNED NOT NULL,
    description TEXT NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (report_id, activity_id),
    CONSTRAINT fk_report_items_report FOREIGN KEY (report_id) REFERENCES reports (id) ON DELETE CASCADE,
    CONSTRAINT fk_report_items_activity FOREIGN KEY (activity_id) REFERENCES activities (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cada envío congela el contenido completo (solo inserción).
CREATE TABLE report_versions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    report_id BIGINT UNSIGNED NOT NULL,
    version INT UNSIGNED NOT NULL,
    content JSON NOT NULL,
    -- SHA-256 del contenido canónico: permite verificar que la versión no se alteró.
    content_hash CHAR(64) NOT NULL,
    submitted_by BIGINT UNSIGNED NOT NULL,
    submitted_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_report_versions (report_id, version),
    CONSTRAINT fk_report_versions_report FOREIGN KEY (report_id) REFERENCES reports (id),
    CONSTRAINT fk_report_versions_user FOREIGN KEY (submitted_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Decisiones de revisión (solo inserción): observación, aprobación, rechazo, reapertura.
CREATE TABLE report_reviews (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    report_id BIGINT UNSIGNED NOT NULL,
    version INT UNSIGNED NOT NULL,
    decision VARCHAR(20) NOT NULL,
    comment TEXT NULL,
    reviewer_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_report_reviews_uuid (uuid),
    KEY idx_report_reviews_report (report_id, created_at),
    CONSTRAINT chk_report_reviews_decision CHECK (decision IN ('observed', 'approved', 'rejected', 'reopened')),
    CONSTRAINT fk_report_reviews_report FOREIGN KEY (report_id) REFERENCES reports (id),
    CONSTRAINT fk_report_reviews_user FOREIGN KEY (reviewer_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Observaciones puntuales de una revisión: generales o sobre una obligación específica.
CREATE TABLE report_observations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    review_id BIGINT UNSIGNED NOT NULL,
    activity_id BIGINT UNSIGNED NULL,
    text TEXT NOT NULL,
    PRIMARY KEY (id),
    KEY idx_report_observations_review (review_id),
    CONSTRAINT fk_report_observations_review FOREIGN KEY (review_id) REFERENCES report_reviews (id),
    CONSTRAINT fk_report_observations_activity FOREIGN KEY (activity_id) REFERENCES activities (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO document_types (code, name, entity_type, position) VALUES
    ('report_annex', 'Anexo del informe', 'report', 1),
    ('other', 'Otro documento', 'report', 99);

INSERT INTO permissions (code, module, description) VALUES
    ('reports.create', 'reports', 'Elaborar y enviar informes de sus propios contratos (contratista)'),
    ('reports.review', 'reports', 'Revisar y observar informes de los contratos que supervisa'),
    ('reports.approve', 'reports', 'Aprobar o rechazar informes de los contratos que supervisa'),
    ('reports.reopen', 'reports', 'Reabrir un informe aprobado, con motivo');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'reports.create' WHERE r.code = 'contractor';
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('reports.review', 'reports.approve') WHERE r.code = 'supervisor';
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'reports.reopen' WHERE r.code = 'admin';
