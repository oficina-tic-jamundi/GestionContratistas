-- Datos de referencia requeridos en producción (ADR-011): roles iniciales y permisos de la Fase 1.
-- Los módulos posteriores agregan sus permisos en sus propias migraciones.

INSERT INTO roles (code, name, description, is_system, created_at, updated_at) VALUES
    ('admin', 'Administrador', 'Configuración, usuarios, roles, permisos y auditoría del sistema.', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
    ('supervisor', 'Supervisor', 'Supervisa contratos asignados: revisa, observa y aprueba informes.', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
    ('contractor', 'Contratista', 'Consulta sus contratos, registra avances, evidencias e informes.', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP());

INSERT INTO permissions (code, module, description) VALUES
    ('users.view', 'users', 'Consultar usuarios'),
    ('users.create', 'users', 'Crear usuarios'),
    ('users.update', 'users', 'Modificar datos de usuarios'),
    ('users.deactivate', 'users', 'Activar y desactivar usuarios'),
    ('users.reset_password', 'users', 'Restablecer la contraseña de un usuario'),
    ('users.assign_roles', 'users', 'Asignar y retirar roles a usuarios'),
    ('roles.view', 'roles', 'Consultar roles y permisos'),
    ('roles.manage', 'roles', 'Crear, modificar y eliminar roles y sus permisos'),
    ('audit.view', 'audit', 'Consultar el registro de auditoría');

-- El administrador recibe todos los permisos de la Fase 1.
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.code = 'admin';
