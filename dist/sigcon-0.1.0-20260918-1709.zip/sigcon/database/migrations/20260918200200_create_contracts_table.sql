-- Contratos. Los contratos no se eliminan físicamente: un borrador descartado se retira
-- lógicamente (deleted_at); los demás siguen su ciclo de estados hasta archivarse.

CREATE TABLE contracts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    -- Número institucional del contrato. El formato lo define la Oficina Jurídica;
    -- el sistema solo exige que sea único.
    contract_number VARCHAR(50) NOT NULL,
    object TEXT NOT NULL,
    contractor_id BIGINT UNSIGNED NOT NULL,
    department_id BIGINT UNSIGNED NOT NULL,
    -- Puede ser NULL solo en borrador: activar un contrato exige supervisor.
    supervisor_user_id BIGINT UNSIGNED NULL,
    signed_at DATE NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    -- Valor total en pesos colombianos (COP).
    total_value DECIMAL(15,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    -- Enlace opcional al proceso en SECOP II.
    secop_url VARCHAR(500) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    deleted_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_contracts_uuid (uuid),
    UNIQUE KEY uq_contracts_number (contract_number),
    KEY idx_contracts_contractor (contractor_id),
    KEY idx_contracts_department (department_id, status),
    KEY idx_contracts_supervisor (supervisor_user_id, status),
    KEY idx_contracts_status_end (status, end_date),
    CONSTRAINT chk_contracts_status CHECK (status IN ('draft', 'active', 'suspended', 'terminated', 'liquidated', 'archived')),
    CONSTRAINT chk_contracts_dates CHECK (end_date >= start_date),
    CONSTRAINT chk_contracts_value CHECK (total_value > 0),
    CONSTRAINT chk_contracts_supervisor_when_active CHECK (status = 'draft' OR supervisor_user_id IS NOT NULL),
    CONSTRAINT fk_contracts_contractor FOREIGN KEY (contractor_id) REFERENCES contractors (id),
    CONSTRAINT fk_contracts_department FOREIGN KEY (department_id) REFERENCES departments (id),
    CONSTRAINT fk_contracts_supervisor FOREIGN KEY (supervisor_user_id) REFERENCES users (id),
    CONSTRAINT fk_contracts_created_by FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT fk_contracts_updated_by FOREIGN KEY (updated_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
