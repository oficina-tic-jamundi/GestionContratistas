-- Contratistas (personas naturales o jurídicas).
-- Minimización de datos (Ley 1581 de 2012): solo lo necesario para identificar al contratista
-- y contactarlo. Datos bancarios, seguridad social y soportes se modelarán en sus módulos,
-- con controles de acceso propios, cuando exista una necesidad definida.

CREATE TABLE contractors (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    person_type VARCHAR(20) NOT NULL,
    document_type VARCHAR(10) NOT NULL,
    -- Solo dígitos o alfanumérico en mayúsculas según el tipo; sin puntos ni guiones.
    document_number VARCHAR(20) NOT NULL,
    -- Dígito de verificación, obligatorio solo para NIT.
    verification_digit TINYINT UNSIGNED NULL,
    -- Nombre completo (persona natural) o razón social (persona jurídica).
    name VARCHAR(200) NOT NULL,
    email VARCHAR(191) NULL,
    phone VARCHAR(30) NULL,
    address VARCHAR(200) NULL,
    -- Cuenta de SIGCON con la que el contratista inicia sesión (opcional, una por contratista).
    user_id BIGINT UNSIGNED NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_contractors_uuid (uuid),
    UNIQUE KEY uq_contractors_document (document_type, document_number),
    UNIQUE KEY uq_contractors_user (user_id),
    KEY idx_contractors_name (name),
    KEY idx_contractors_status (status),
    CONSTRAINT chk_contractors_person_type CHECK (person_type IN ('natural', 'juridica')),
    CONSTRAINT chk_contractors_document_type CHECK (document_type IN ('CC', 'CE', 'PA', 'PPT', 'NIT')),
    CONSTRAINT chk_contractors_status CHECK (status IN ('active', 'inactive')),
    CONSTRAINT chk_contractors_dv CHECK (
        (document_type = 'NIT' AND verification_digit IS NOT NULL AND verification_digit <= 9)
        OR (document_type <> 'NIT' AND verification_digit IS NULL)
    ),
    CONSTRAINT chk_contractors_email_lowercase CHECK (email IS NULL OR email = LOWER(email)),
    CONSTRAINT fk_contractors_user FOREIGN KEY (user_id) REFERENCES users (id),
    CONSTRAINT fk_contractors_created_by FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT fk_contractors_updated_by FOREIGN KEY (updated_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
