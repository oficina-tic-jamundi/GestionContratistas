-- Notificaciones dentro de SIGCON (ADR-019). Se crean en la misma transacción del evento
-- que las origina. El envío por correo electrónico está pendiente de credenciales SMTP.

CREATE TABLE notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(200) NOT NULL,
    body VARCHAR(1000) NULL,
    -- Ruta interna de la aplicación (siempre relativa, empieza por "/").
    link_path VARCHAR(255) NULL,
    read_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_notifications_uuid (uuid),
    KEY idx_notifications_user (user_id, read_at, created_at),
    CONSTRAINT chk_notifications_link CHECK (link_path IS NULL OR (link_path LIKE '/%' AND link_path NOT LIKE '//%')),
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permissions (code, module, description) VALUES
    ('exports.run', 'reports', 'Exportar listados de contratos y pagos (CSV) dentro de su alcance');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = 'exports.run' WHERE r.code = 'admin';
