-- Pagos (cuentas de cobro) y elegibilidad configurable (ADR-007, ADR-018).
-- SIGCON registra y controla el trámite; no ejecuta pagos: "pagado" registra un hecho externo
-- (fecha y comprobante de tesorería).

CREATE TABLE payments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid CHAR(36) NOT NULL,
    contract_id BIGINT UNSIGNED NOT NULL,
    report_id BIGINT UNSIGNED NOT NULL,
    -- Consecutivo por contrato.
    number INT UNSIGNED NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    notes VARCHAR(1000) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    -- Último resultado de elegibilidad (el detalle está en payment_evaluations).
    last_eligible TINYINT(1) NULL,
    last_evaluated_at DATETIME NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    submitted_by BIGINT UNSIGNED NULL,
    submitted_at DATETIME NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,
    payment_date DATE NULL,
    payment_reference VARCHAR(100) NULL,
    paid_registered_by BIGINT UNSIGNED NULL,
    paid_registered_at DATETIME NULL,
    cancelled_reason VARCHAR(1000) NULL,
    cancelled_by BIGINT UNSIGNED NULL,
    cancelled_at DATETIME NULL,
    -- Un informe tiene como máximo un pago vigente (no anulado).
    active_report_id BIGINT UNSIGNED GENERATED ALWAYS AS (IF(status <> 'cancelled', report_id, NULL)) STORED,
    PRIMARY KEY (id),
    UNIQUE KEY uq_payments_uuid (uuid),
    UNIQUE KEY uq_payments_number (contract_id, number),
    UNIQUE KEY uq_payments_active_report (active_report_id),
    KEY idx_payments_status (status, updated_at),
    CONSTRAINT chk_payments_status CHECK (status IN ('draft', 'ready_for_approval', 'approved', 'paid', 'cancelled')),
    CONSTRAINT chk_payments_amount CHECK (amount > 0),
    CONSTRAINT chk_payments_approved CHECK (status NOT IN ('approved', 'paid') OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)),
    CONSTRAINT chk_payments_paid CHECK ((status = 'paid') = (payment_date IS NOT NULL AND payment_reference IS NOT NULL AND paid_registered_by IS NOT NULL)),
    CONSTRAINT chk_payments_cancelled CHECK ((status = 'cancelled') = (cancelled_reason IS NOT NULL AND cancelled_by IS NOT NULL AND cancelled_at IS NOT NULL)),
    CONSTRAINT fk_payments_contract FOREIGN KEY (contract_id) REFERENCES contracts (id),
    CONSTRAINT fk_payments_report FOREIGN KEY (report_id) REFERENCES reports (id),
    CONSTRAINT fk_payments_created_by FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT fk_payments_submitted_by FOREIGN KEY (submitted_by) REFERENCES users (id),
    CONSTRAINT fk_payments_approved_by FOREIGN KEY (approved_by) REFERENCES users (id),
    CONSTRAINT fk_payments_paid_by FOREIGN KEY (paid_registered_by) REFERENCES users (id),
    CONSTRAINT fk_payments_cancelled_by FOREIGN KEY (cancelled_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cada evaluación de elegibilidad, con el resultado de TODAS las reglas (solo inserción).
CREATE TABLE payment_evaluations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    payment_id BIGINT UNSIGNED NOT NULL,
    eligible TINYINT(1) NOT NULL,
    results JSON NOT NULL,
    trigger_event VARCHAR(20) NOT NULL,
    evaluated_by BIGINT UNSIGNED NOT NULL,
    evaluated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_payment_evaluations_payment (payment_id, evaluated_at),
    CONSTRAINT chk_payment_evaluations_trigger CHECK (trigger_event IN ('manual', 'submit', 'approve')),
    CONSTRAINT fk_payment_evaluations_payment FOREIGN KEY (payment_id) REFERENCES payments (id),
    CONSTRAINT fk_payment_evaluations_user FOREIGN KEY (evaluated_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Configuración de las reglas (ADR-007): activación y parámetros, editables y auditados.
CREATE TABLE payment_rule_settings (
    code VARCHAR(50) NOT NULL,
    enabled TINYINT(1) NOT NULL,
    params JSON NOT NULL,
    updated_by BIGINT UNSIGNED NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (code),
    CONSTRAINT fk_payment_rule_settings_user FOREIGN KEY (updated_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activas por defecto: las condiciones de ADR-007 que se verifican con datos existentes.
-- Desactivadas: las que dependen de definiciones institucionales pendientes (ADR-018).
INSERT INTO payment_rule_settings (code, enabled, params, updated_at) VALUES
    ('contract_active', 1, JSON_OBJECT('statuses', JSON_ARRAY('active')), UTC_TIMESTAMP()),
    ('report_approved', 1, JSON_OBJECT(), UTC_TIMESTAMP()),
    ('no_pending_observations', 1, JSON_OBJECT(), UTC_TIMESTAMP()),
    ('required_documents', 0, JSON_OBJECT('types', JSON_ARRAY()), UTC_TIMESTAMP()),
    ('min_evidences', 0, JSON_OBJECT('min', 1), UTC_TIMESTAMP()),
    ('min_progress', 0, JSON_OBJECT('min_percent', 100), UTC_TIMESTAMP());

INSERT INTO permissions (code, module, description) VALUES
    ('payments.manage', 'payments', 'Registrar pagos, evaluar su elegibilidad, enviarlos a aprobación y anularlos'),
    ('payments.approve', 'payments', 'Aprobar o devolver pagos listos para aprobación'),
    ('payments.register', 'payments', 'Registrar que un pago aprobado fue pagado (fecha y comprobante)'),
    ('payments.configure', 'payments', 'Configurar las reglas de elegibilidad de pagos');

-- Asignación inicial a administración; la Alcaldía los reasigna desde Roles (ADR-018).
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('payments.manage', 'payments.approve', 'payments.register', 'payments.configure') WHERE r.code = 'admin';
