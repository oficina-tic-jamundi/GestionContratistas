-- Auditoría técnica institucional. Solo inserción: la aplicación nunca actualiza ni borra registros.
-- (El historial de negocio legible por usuarios se modela aparte en fases posteriores.)

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    occurred_at DATETIME NOT NULL,
    -- NULL para eventos sin usuario autenticado (ej. intento de login fallido).
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NULL,
    entity_id VARCHAR(64) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    request_id CHAR(16) NULL,
    -- Datos adicionales no consultables. Nunca contraseñas, tokens ni secretos.
    metadata JSON NULL,
    PRIMARY KEY (id),
    KEY idx_audit_logs_occurred (occurred_at),
    KEY idx_audit_logs_user (user_id, occurred_at),
    KEY idx_audit_logs_action (action, occurred_at),
    KEY idx_audit_logs_entity (entity_type, entity_id),
    CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
