<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Models\ActivityLevel;
use Sigcon\Models\Evidence;
use Sigcon\Models\LocationStatus;

final class EvidenceRepository
{
    private const SELECT = "SELECT e.*, a.uuid AS activity_uuid, a.title AS activity_title, a.level AS activity_level,
        CONCAT(u.first_name, ' ', u.last_name) AS captured_by_name, CONCAT(w.first_name, ' ', w.last_name) AS withdrawn_by_name
        FROM evidences e
        JOIN activities a ON a.id = e.activity_id
        JOIN users u ON u.id = e.captured_by
        LEFT JOIN users w ON w.id = e.withdrawn_by";

    public function __construct(private readonly Database $db)
    {
    }

    public function findByUuid(string $uuid): ?Evidence
    {
        $rows = $this->db->fetchAll(self::SELECT . ' WHERE e.uuid = :uuid', ['uuid' => $uuid]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    /** @return list<Evidence> más recientes primero */
    public function forContract(int $contractId, ?int $activityId = null): array
    {
        $sql = self::SELECT . ' WHERE e.contract_id = :contract';
        $params = ['contract' => $contractId];
        if ($activityId !== null) {
            $sql .= ' AND e.activity_id = :activity';
            $params['activity'] = $activityId;
        }

        return array_map($this->hydrate(...), $this->db->fetchAll($sql . ' ORDER BY e.captured_at DESC, e.id DESC', $params));
    }

    /**
     * Evidencias vigentes capturadas en el período, con la obligación a la que pertenecen.
     *
     * @return list<array{obligation_id: int, evidence: Evidence}>
     */
    public function activeInPeriod(int $contractId, DateTimeImmutable $fromUtc, DateTimeImmutable $toUtc): array
    {
        $rows = $this->db->fetchAll(
            "SELECT e.*, a.uuid AS activity_uuid, a.title AS activity_title, a.level AS activity_level,
                    CONCAT(u.first_name, ' ', u.last_name) AS captured_by_name, NULL AS withdrawn_by_name,
                    COALESCE(gp.id, p.id, a.id) AS obligation_id
             FROM evidences e
             JOIN activities a ON a.id = e.activity_id
             LEFT JOIN activities p ON p.id = a.parent_id
             LEFT JOIN activities gp ON gp.id = p.parent_id
             JOIN users u ON u.id = e.captured_by
             WHERE e.contract_id = :contract AND e.status = 'active' AND e.captured_at >= :from AND e.captured_at < :to
             ORDER BY e.captured_at, e.id",
            ['contract' => $contractId, 'from' => DateTimes::toDb($fromUtc), 'to' => DateTimes::toDb($toUtc)],
        );

        return array_map(fn (array $row) => ['obligation_id' => (int) $row['obligation_id'], 'evidence' => $this->hydrate($row)], $rows);
    }

    public function activeOriginalExists(int $contractId, string $sha256): bool
    {
        return $this->db->fetchAll(
            "SELECT 1 FROM evidences WHERE contract_id = :contract AND original_sha256 = :hash AND status = 'active'",
            ['contract' => $contractId, 'hash' => $sha256],
        ) !== [];
    }

    /** @param array<string, string|int|float|null> $data columnas => valores (ya validados) */
    public function create(array $data): void
    {
        $columns = array_keys($data);
        $this->db->pdo()->prepare(sprintf(
            'INSERT INTO evidences (%s) VALUES (%s)',
            implode(', ', $columns),
            implode(', ', array_map(static fn (string $c) => ':' . $c, $columns)),
        ))->execute($data);
    }

    public function withdraw(int $id, string $reason, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE evidences SET status = 'withdrawn', withdrawn_reason = :reason, withdrawn_by = :user, withdrawn_at = :now
             WHERE id = :id AND status = 'active'",
        )->execute(['reason' => $reason, 'user' => $userId, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Evidence
    {
        $nullable = static fn (mixed $v): ?string => $v === null ? null : (string) $v;

        return new Evidence(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            contractId: (int) $row['contract_id'],
            activityId: (int) $row['activity_id'],
            activityUuid: (string) $row['activity_uuid'],
            activityTitle: (string) $row['activity_title'],
            activityLevel: ActivityLevel::from((string) $row['activity_level']),
            description: $nullable($row['description']),
            originalPath: (string) $row['original_path'],
            originalMime: (string) $row['original_mime'],
            originalSizeBytes: (int) $row['original_size_bytes'],
            originalSha256: (string) $row['original_sha256'],
            width: (int) $row['width'],
            height: (int) $row['height'],
            officialPath: (string) $row['official_path'],
            officialSha256: (string) $row['official_sha256'],
            thumbnailPath: (string) $row['thumbnail_path'],
            locationStatus: LocationStatus::from((string) $row['location_status']),
            latitude: $nullable($row['latitude']),
            longitude: $nullable($row['longitude']),
            accuracyM: $nullable($row['accuracy_m']),
            altitudeM: $nullable($row['altitude_m']),
            headingDeg: $nullable($row['heading_deg']),
            speedMps: $nullable($row['speed_mps']),
            locationCapturedAt: DateTimes::fromDbNullable($nullable($row['location_captured_at'])),
            deviceCapturedAt: DateTimes::fromDbNullable($nullable($row['device_captured_at'])),
            capturedAt: DateTimes::fromDb((string) $row['captured_at']),
            capturedBy: (int) $row['captured_by'],
            capturedByName: (string) $row['captured_by_name'],
            status: (string) $row['status'],
            withdrawnReason: $nullable($row['withdrawn_reason']),
            withdrawnAt: DateTimes::fromDbNullable($nullable($row['withdrawn_at'])),
            withdrawnByName: $nullable($row['withdrawn_by_name']),
        );
    }
}
