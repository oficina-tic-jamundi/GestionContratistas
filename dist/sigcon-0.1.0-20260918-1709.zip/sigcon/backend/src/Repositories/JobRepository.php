<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use PDOException;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Job;
use Sigcon\Models\JobStatus;

final class JobRepository
{
    public const SORTABLE = ['created_at' => 'created_at', 'updated_at' => 'updated_at', 'available_at' => 'available_at'];

    /** Condición de un trabajo reclamable: pendiente y vencido, o en proceso con el bloqueo vencido. */
    private const CLAIMABLE = "((status = 'pending' AND available_at <= :now1) OR (status = 'processing' AND locked_until < :now2))";

    public function __construct(private readonly Database $db)
    {
    }

    /**
     * Inserta el trabajo. Con `dedupeKey`, si ya hay uno igual pendiente no se
     * duplica (devuelve false).
     *
     * @param array<string, mixed> $payload
     */
    public function insert(string $uuid, string $type, array $payload, ?string $dedupeKey, int $maxAttempts, DateTimeImmutable $availableAt, DateTimeImmutable $now): bool
    {
        try {
            $this->db->pdo()->prepare(
                'INSERT INTO jobs (uuid, type, payload, dedupe_key, status, attempts, max_attempts, available_at, created_at, updated_at)
                 VALUES (:uuid, :type, :payload, :dedupe, :status, 0, :max, :available, :now, :now2)',
            )->execute([
                'uuid' => $uuid,
                'type' => $type,
                'payload' => json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'dedupe' => $dedupeKey,
                'status' => JobStatus::Pending->value,
                'max' => $maxAttempts,
                'available' => DateTimes::toDb($availableAt),
                'now' => DateTimes::toDb($now),
                'now2' => DateTimes::toDb($now),
            ]);

            return true;
        } catch (PDOException $e) {
            if ($dedupeKey !== null && Database::isUniqueViolation($e)) {
                return false;
            }
            throw $e;
        }
    }

    /**
     * Reclama el siguiente trabajo disponible. Dos procesadores simultáneos nunca toman el mismo:
     * el UPDATE vuelve a exigir la condición y solo uno lo logra.
     */
    public function claimNext(string $runnerId, DateTimeImmutable $now, DateTimeImmutable $lockedUntil): ?Job
    {
        for ($tries = 0; $tries < 5; $tries++) {
            $candidate = $this->db->fetchAll(
                'SELECT id FROM jobs WHERE ' . self::CLAIMABLE . ' ORDER BY available_at, id LIMIT 1',
                ['now1' => DateTimes::toDb($now), 'now2' => DateTimes::toDb($now)],
            )[0]['id'] ?? null;
            if ($candidate === null) {
                return null;
            }
            $statement = $this->db->pdo()->prepare(
                "UPDATE jobs SET status = 'processing', locked_by = :runner, locked_until = :until, attempts = attempts + 1, updated_at = :now
                 WHERE id = :id AND " . self::CLAIMABLE,
            );
            $statement->execute([
                'runner' => $runnerId,
                'until' => DateTimes::toDb($lockedUntil),
                'now' => DateTimes::toDb($now),
                'id' => (int) $candidate,
                'now1' => DateTimes::toDb($now),
                'now2' => DateTimes::toDb($now),
            ]);
            if ($statement->rowCount() === 1) {
                return $this->findById((int) $candidate);
            }
            // Otro procesador lo tomó primero: se busca el siguiente.
        }

        return null;
    }

    /** Solo el procesador que lo reclamó puede cerrarlo (si su bloqueo venció y otro lo tomó, no pisa). */
    public function markCompleted(int $id, string $runnerId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE jobs SET status = 'completed', locked_by = NULL, locked_until = NULL, last_error = NULL, completed_at = :now, updated_at = :now2
             WHERE id = :id AND status = 'processing' AND locked_by = :runner",
        )->execute(['now' => DateTimes::toDb($now), 'now2' => DateTimes::toDb($now), 'id' => $id, 'runner' => $runnerId]);
    }

    public function markRetry(int $id, string $runnerId, string $error, DateTimeImmutable $availableAt, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE jobs SET status = 'pending', locked_by = NULL, locked_until = NULL, last_error = :error, available_at = :available, updated_at = :now
             WHERE id = :id AND status = 'processing' AND locked_by = :runner",
        )->execute(['error' => mb_substr($error, 0, 1000), 'available' => DateTimes::toDb($availableAt), 'now' => DateTimes::toDb($now), 'id' => $id, 'runner' => $runnerId]);
    }

    public function markFailed(int $id, string $runnerId, string $error, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE jobs SET status = 'failed', locked_by = NULL, locked_until = NULL, last_error = :error, failed_at = :now, updated_at = :now2
             WHERE id = :id AND status = 'processing' AND locked_by = :runner",
        )->execute(['error' => mb_substr($error, 0, 1000), 'now' => DateTimes::toDb($now), 'now2' => DateTimes::toDb($now), 'id' => $id, 'runner' => $runnerId]);
    }

    /** Reintento manual de un trabajo fallido: vuelve a pendiente con los intentos en cero. */
    public function requeueFailed(int $id, DateTimeImmutable $now): bool
    {
        try {
            $statement = $this->db->pdo()->prepare(
                "UPDATE jobs SET status = 'pending', attempts = 0, available_at = :now, failed_at = NULL, updated_at = :now2
                 WHERE id = :id AND status = 'failed'",
            );
            $statement->execute(['now' => DateTimes::toDb($now), 'now2' => DateTimes::toDb($now), 'id' => $id]);

            return $statement->rowCount() === 1;
        } catch (PDOException $e) {
            // Ya hay otro trabajo igual pendiente: no hace falta reintentar este.
            if (Database::isUniqueViolation($e)) {
                return false;
            }
            throw $e;
        }
    }

    public function findById(int $id): ?Job
    {
        $rows = $this->db->fetchAll('SELECT * FROM jobs WHERE id = :id', ['id' => $id]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    public function findByUuid(string $uuid): ?Job
    {
        $rows = $this->db->fetchAll('SELECT * FROM jobs WHERE uuid = :uuid', ['uuid' => $uuid]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    /** @return Page<Job> */
    public function paginate(?JobStatus $status, PageRequest $page): Page
    {
        $where = $status === null ? '1 = 1' : 'status = :status';
        $params = $status === null ? [] : ['status' => $status->value];
        $total = (int) ($this->db->fetchAll("SELECT COUNT(*) AS total FROM jobs WHERE {$where}", $params)[0]['total'] ?? 0);
        $rows = $this->db->fetchAll(sprintf(
            'SELECT * FROM jobs WHERE %s ORDER BY %s LIMIT %d OFFSET %d',
            $where,
            $page->orderBy('id'),
            $page->perPage,
            $page->offset(),
        ), $params);

        return new Page(array_map($this->hydrate(...), $rows), $total, $page);
    }

    /** @return array<string, int> estado => cantidad */
    public function countsByStatus(): array
    {
        $counts = array_fill_keys(array_map(static fn (JobStatus $s) => $s->value, JobStatus::cases()), 0);
        foreach ($this->db->fetchAll('SELECT status, COUNT(*) AS total FROM jobs GROUP BY status') as $row) {
            $counts[(string) $row['status']] = (int) $row['total'];
        }

        return $counts;
    }

    public function startRun(string $runnerId, DateTimeImmutable $now): int
    {
        $this->db->pdo()->prepare('INSERT INTO job_runs (runner_id, started_at) VALUES (:runner, :now)')
            ->execute(['runner' => $runnerId, 'now' => DateTimes::toDb($now)]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    public function finishRun(int $runId, int $processed, int $failed, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE job_runs SET finished_at = :now, processed = :processed, failed = :failed WHERE id = :id')
            ->execute(['now' => DateTimes::toDb($now), 'processed' => $processed, 'failed' => $failed, 'id' => $runId]);
    }

    /** @return array{started_at: DateTimeImmutable, finished_at: ?DateTimeImmutable, processed: int, failed: int}|null */
    public function lastRun(): ?array
    {
        $row = $this->db->fetchAll('SELECT * FROM job_runs ORDER BY started_at DESC, id DESC LIMIT 1')[0] ?? null;

        return $row === null ? null : [
            'started_at' => DateTimes::fromDb((string) $row['started_at']),
            'finished_at' => DateTimes::fromDbNullable($row['finished_at'] === null ? null : (string) $row['finished_at']),
            'processed' => (int) $row['processed'],
            'failed' => (int) $row['failed'],
        ];
    }

    /** Limpieza: trabajos completados y ejecuciones antiguas. Los fallidos se conservan. */
    public function deleteCompletedBefore(DateTimeImmutable $before): int
    {
        $statement = $this->db->pdo()->prepare("DELETE FROM jobs WHERE status = 'completed' AND completed_at < :before");
        $statement->execute(['before' => DateTimes::toDb($before)]);
        $this->db->pdo()->prepare('DELETE FROM job_runs WHERE started_at < :before')->execute(['before' => DateTimes::toDb($before)]);

        return $statement->rowCount();
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Job
    {
        $payload = json_decode((string) $row['payload'], true);
        $nullable = static fn (mixed $v): ?string => $v === null ? null : (string) $v;

        return new Job(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            type: (string) $row['type'],
            payload: is_array($payload) ? $payload : [],
            dedupeKey: $nullable($row['dedupe_key']),
            status: JobStatus::from((string) $row['status']),
            attempts: (int) $row['attempts'],
            maxAttempts: (int) $row['max_attempts'],
            availableAt: DateTimes::fromDb((string) $row['available_at']),
            lockedUntil: DateTimes::fromDbNullable($nullable($row['locked_until'])),
            lockedBy: $nullable($row['locked_by']),
            lastError: $nullable($row['last_error']),
            createdAt: DateTimes::fromDb((string) $row['created_at']),
            updatedAt: DateTimes::fromDb((string) $row['updated_at']),
            completedAt: DateTimes::fromDbNullable($nullable($row['completed_at'])),
            failedAt: DateTimes::fromDbNullable($nullable($row['failed_at'])),
        );
    }
}
