<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use PDO;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Models\PermissionDefinition;
use Sigcon\Models\Role;

final class RoleRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    /** @return list<Role> roles con sus permisos y número de usuarios (3 consultas en total) */
    public function all(): array
    {
        $rows = $this->db->fetchAll('SELECT id, code, name, description, is_system FROM roles ORDER BY is_system DESC, name');

        $permissions = [];
        foreach ($this->db->fetchAll(
            'SELECT rp.role_id, p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id ORDER BY p.code',
        ) as $row) {
            $permissions[(int) $row['role_id']][] = (string) $row['code'];
        }

        $counts = [];
        foreach ($this->db->fetchAll(
            'SELECT ur.role_id, COUNT(*) AS total FROM user_roles ur JOIN users u ON u.id = ur.user_id
             WHERE u.deleted_at IS NULL GROUP BY ur.role_id',
        ) as $row) {
            $counts[(int) $row['role_id']] = (int) $row['total'];
        }

        return array_map(
            fn (array $row) => $this->hydrate($row, $permissions[(int) $row['id']] ?? [], $counts[(int) $row['id']] ?? 0),
            $rows,
        );
    }

    public function findByCode(string $code): ?Role
    {
        foreach ($this->all() as $role) {
            if ($role->code === $code) {
                return $role;
            }
        }

        return null;
    }

    /**
     * @param list<string> $codes
     * @return array<string, int> código => id (solo los que existen)
     */
    public function idsByCodes(array $codes): array
    {
        if ($codes === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($codes), '?'));
        $stmt = $this->db->pdo()->prepare("SELECT code, id FROM roles WHERE code IN ({$placeholders})");
        $stmt->execute($codes);

        $result = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[(string) $row['code']] = (int) $row['id'];
        }

        return $result;
    }

    public function create(string $code, string $name, ?string $description, DateTimeImmutable $now): int
    {
        $this->db->pdo()->prepare(
            'INSERT INTO roles (code, name, description, is_system, created_at, updated_at)
             VALUES (:code, :name, :description, 0, :now, :now2)',
        )->execute([
            'code' => $code,
            'name' => $name,
            'description' => $description,
            'now' => DateTimes::toDb($now),
            'now2' => DateTimes::toDb($now),
        ]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    public function update(int $id, string $name, ?string $description, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE roles SET name = :name, description = :description, updated_at = :now WHERE id = :id')
            ->execute(['name' => $name, 'description' => $description, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    /** @param list<string> $permissionCodes */
    public function replacePermissions(int $roleId, array $permissionCodes): void
    {
        $pdo = $this->db->pdo();
        $pdo->prepare('DELETE FROM role_permissions WHERE role_id = :id')->execute(['id' => $roleId]);
        if ($permissionCodes === []) {
            return;
        }
        $placeholders = implode(',', array_fill(0, count($permissionCodes), '?'));
        $pdo->prepare(
            "INSERT INTO role_permissions (role_id, permission_id) SELECT ?, id FROM permissions WHERE code IN ({$placeholders})",
        )->execute([$roleId, ...$permissionCodes]);
    }

    public function delete(int $id): void
    {
        $this->db->pdo()->prepare('DELETE FROM roles WHERE id = :id AND is_system = 0')->execute(['id' => $id]);
    }

    /** Bloquea la fila del rol hasta el fin de la transacción. */
    public function lockById(int $id): void
    {
        $this->db->pdo()->prepare('SELECT id FROM roles WHERE id = :id FOR UPDATE')->execute(['id' => $id]);
    }

    /** @return list<PermissionDefinition> */
    public function allPermissions(): array
    {
        $rows = $this->db->fetchAll('SELECT code, module, description FROM permissions ORDER BY module, code');

        return array_map(
            static fn (array $row) => new PermissionDefinition((string) $row['code'], (string) $row['module'], (string) $row['description']),
            $rows,
        );
    }

    /**
     * @param array<string, mixed> $row
     * @param list<string> $permissions
     */
    private function hydrate(array $row, array $permissions, int $userCount): Role
    {
        return new Role(
            id: (int) $row['id'],
            code: (string) $row['code'],
            name: (string) $row['name'],
            description: $row['description'] === null ? null : (string) $row['description'],
            isSystem: (bool) $row['is_system'],
            permissions: $permissions,
            userCount: $userCount,
        );
    }
}
