<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;

final class LoginAttemptRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    public function record(string $emailHash, string $ip, bool $succeeded, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'INSERT INTO login_attempts (email_hash, ip_address, succeeded, attempted_at) VALUES (:email, :ip, :ok, :now)',
        )->execute(['email' => $emailHash, 'ip' => $ip, 'ok' => (int) $succeeded, 'now' => DateTimes::toDb($now)]);
    }

    /**
     * Fallos para una cuenta desde $since, sin contar los anteriores al último inicio exitoso.
     */
    public function failuresForEmailSince(string $emailHash, DateTimeImmutable $since): int
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE email_hash = :email AND succeeded = 0 AND attempted_at >= :since
               AND attempted_at > COALESCE(
                   (SELECT MAX(attempted_at) FROM login_attempts WHERE email_hash = :email2 AND succeeded = 1),
                   \'1970-01-01 00:00:00\')',
        );
        $stmt->execute(['email' => $emailHash, 'since' => DateTimes::toDb($since), 'email2' => $emailHash]);

        return (int) $stmt->fetchColumn();
    }

    public function failuresForIpSince(string $ip, DateTimeImmutable $since): int
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT COUNT(*) FROM login_attempts WHERE ip_address = :ip AND succeeded = 0 AND attempted_at >= :since',
        );
        $stmt->execute(['ip' => $ip, 'since' => DateTimes::toDb($since)]);

        return (int) $stmt->fetchColumn();
    }

    public function deleteOlderThan(DateTimeImmutable $before): int
    {
        $stmt = $this->db->pdo()->prepare('DELETE FROM login_attempts WHERE attempted_at < :before');
        $stmt->execute(['before' => DateTimes::toDb($before)]);

        return $stmt->rowCount();
    }
}
