<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use PDO;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Models\Session;

final class SessionRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    public function create(
        string $tokenHash,
        int $userId,
        DateTimeImmutable $now,
        DateTimeImmutable $expiresAt,
        ?string $ip,
        ?string $userAgent,
    ): int {
        $this->db->pdo()->prepare(
            'INSERT INTO user_sessions (token_hash, user_id, created_at, last_activity_at, expires_at, ip_address, user_agent)
             VALUES (:hash, :user, :now, :now2, :expires, :ip, :ua)',
        )->execute([
            'hash' => $tokenHash,
            'user' => $userId,
            'now' => DateTimes::toDb($now),
            'now2' => DateTimes::toDb($now),
            'expires' => DateTimes::toDb($expiresAt),
            'ip' => $ip,
            'ua' => $userAgent,
        ]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    public function findActiveByTokenHash(string $tokenHash): ?Session
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT id, user_id, created_at, last_activity_at, expires_at, revoked_at
             FROM user_sessions WHERE token_hash = :hash AND revoked_at IS NULL',
        );
        $stmt->execute(['hash' => $tokenHash]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return null;
        }

        return new Session(
            id: (int) $row['id'],
            userId: (int) $row['user_id'],
            createdAt: DateTimes::fromDb((string) $row['created_at']),
            lastActivityAt: DateTimes::fromDb((string) $row['last_activity_at']),
            expiresAt: DateTimes::fromDb((string) $row['expires_at']),
            revokedAt: null,
        );
    }

    public function touch(int $id, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE user_sessions SET last_activity_at = :now WHERE id = :id')
            ->execute(['now' => DateTimes::toDb($now), 'id' => $id]);
    }

    public function revoke(int $id, string $reason, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'UPDATE user_sessions SET revoked_at = :now, revoked_reason = :reason WHERE id = :id AND revoked_at IS NULL',
        )->execute(['now' => DateTimes::toDb($now), 'reason' => $reason, 'id' => $id]);
    }

    /** @return int sesiones revocadas */
    public function revokeAllForUser(int $userId, string $reason, DateTimeImmutable $now, ?int $exceptSessionId = null): int
    {
        $stmt = $this->db->pdo()->prepare(
            'UPDATE user_sessions SET revoked_at = :now, revoked_reason = :reason
             WHERE user_id = :user AND revoked_at IS NULL AND (:except IS NULL OR id <> :except2)',
        );
        $stmt->execute([
            'now' => DateTimes::toDb($now),
            'reason' => $reason,
            'user' => $userId,
            'except' => $exceptSessionId,
            'except2' => $exceptSessionId,
        ]);

        return $stmt->rowCount();
    }

    /** Elimina sesiones vencidas o revocadas antes de $before. @return int filas eliminadas */
    public function deleteFinishedBefore(DateTimeImmutable $before): int
    {
        $stmt = $this->db->pdo()->prepare(
            'DELETE FROM user_sessions WHERE expires_at < :before OR (revoked_at IS NOT NULL AND revoked_at < :before2)',
        );
        $stmt->execute(['before' => DateTimes::toDb($before), 'before2' => DateTimes::toDb($before)]);

        return $stmt->rowCount();
    }
}
