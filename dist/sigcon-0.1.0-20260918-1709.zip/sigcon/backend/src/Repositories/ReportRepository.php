<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Report;
use Sigcon\Models\ReportStatus;

final class ReportRepository
{
    private const SELECT = "SELECT r.id, r.uuid, r.contract_id, c.uuid AS contract_uuid, c.contract_number, ct.name AS contractor_name,
        r.number, r.period_start, r.period_end, r.status, r.summary, r.contractor_notes, r.current_version, r.approved_version,
        r.approved_at, CONCAT(a.first_name, ' ', a.last_name) AS approved_by_name, r.created_by, r.created_at, r.updated_at
        FROM reports r
        JOIN contracts c ON c.id = r.contract_id
        JOIN contractors ct ON ct.id = c.contractor_id
        LEFT JOIN users a ON a.id = r.approved_by";

    public const SORTABLE = ['updated_at' => 'r.updated_at', 'period' => 'r.period_start', 'number' => 'r.number'];

    public function __construct(private readonly Database $db)
    {
    }

    public function findByUuid(string $uuid): ?Report
    {
        $rows = $this->db->fetchAll(self::SELECT . ' WHERE r.uuid = :uuid', ['uuid' => $uuid]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    public function findById(int $id): ?Report
    {
        $rows = $this->db->fetchAll(self::SELECT . ' WHERE r.id = :id', ['id' => $id]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    /**
     * @param ?int $draftOwnerUserId si no es null, los borradores solo se incluyen cuando pertenecen
     *                               al contratista con esa cuenta (los borradores son del contratista).
     * @param list<ReportStatus> $statuses vacío = todos
     * @return Page<Report>
     */
    public function paginate(array $statuses, ?string $contractUuid, PageRequest $page, ContractScope $scope, ?int $draftOwnerUserId): Page
    {
        [$scopeSql, $params] = $scope->toSql();
        $where = ['c.deleted_at IS NULL', $scopeSql];
        if ($draftOwnerUserId !== null) {
            $where[] = "(r.status <> 'draft' OR ct.user_id = :draft_owner)";
            $params['draft_owner'] = $draftOwnerUserId;
        }
        if ($statuses !== []) {
            $names = [];
            foreach ($statuses as $i => $status) {
                $names[] = ":status{$i}";
                $params["status{$i}"] = $status->value;
            }
            $where[] = 'r.status IN (' . implode(', ', $names) . ')';
        }
        if ($contractUuid !== null) {
            $where[] = 'c.uuid = :contract';
            $params['contract'] = $contractUuid;
        }
        $whereSql = implode(' AND ', $where);
        $from = 'FROM reports r JOIN contracts c ON c.id = r.contract_id JOIN contractors ct ON ct.id = c.contractor_id';

        $total = (int) ($this->db->fetchAll("SELECT COUNT(*) AS total {$from} WHERE {$whereSql}", $params)[0]['total'] ?? 0);
        $rows = $this->db->fetchAll(sprintf(
            '%s WHERE %s ORDER BY %s LIMIT %d OFFSET %d',
            self::SELECT,
            $whereSql,
            $page->orderBy('r.id'),
            $page->perPage,
            $page->offset(),
        ), $params);

        return new Page(array_map($this->hydrate(...), $rows), $total, $page);
    }

    /** @return list<int> números de los informes del contrato que esperan corrección del contratista */
    public function numbersWithPendingObservations(int $contractId): array
    {
        return array_map(
            static fn (array $r) => (int) $r['number'],
            $this->db->fetchAll("SELECT number FROM reports WHERE contract_id = :id AND status = 'observed' ORDER BY number", ['id' => $contractId]),
        );
    }

    public function nextNumber(int $contractId): int
    {
        return (int) ($this->db->fetchAll('SELECT COALESCE(MAX(number), 0) + 1 AS n FROM reports WHERE contract_id = :id', ['id' => $contractId])[0]['n'] ?? 1);
    }

    public function periodOverlaps(int $contractId, DateTimeImmutable $start, DateTimeImmutable $end, ?int $exceptId = null): bool
    {
        return $this->db->fetchAll(
            "SELECT 1 FROM reports WHERE contract_id = :id AND status <> 'rejected'
               AND period_start <= :end AND period_end >= :start AND (:except IS NULL OR id <> :except2)",
            ['id' => $contractId, 'start' => $start->format('Y-m-d'), 'end' => $end->format('Y-m-d'), 'except' => $exceptId, 'except2' => $exceptId],
        ) !== [];
    }

    public function create(string $uuid, int $contractId, int $number, DateTimeImmutable $start, DateTimeImmutable $end, int $userId, DateTimeImmutable $now): int
    {
        $this->db->pdo()->prepare(
            'INSERT INTO reports (uuid, contract_id, number, period_start, period_end, status, created_by, created_at, updated_at)
             VALUES (:uuid, :contract, :number, :start, :end, :status, :user, :now, :now2)',
        )->execute([
            'uuid' => $uuid,
            'contract' => $contractId,
            'number' => $number,
            'start' => $start->format('Y-m-d'),
            'end' => $end->format('Y-m-d'),
            'status' => ReportStatus::Draft->value,
            'user' => $userId,
            'now' => DateTimes::toDb($now),
            'now2' => DateTimes::toDb($now),
        ]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    public function updateContent(int $id, ?string $summary, ?string $notes, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE reports SET summary = :s, contractor_notes = :n, updated_at = :now WHERE id = :id')
            ->execute(['s' => $summary, 'n' => $notes, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    /** @param array<int, string> $items activity_id => descripción */
    public function replaceItems(int $reportId, array $items, DateTimeImmutable $now): void
    {
        $pdo = $this->db->pdo();
        $pdo->prepare('DELETE FROM report_items WHERE report_id = :id')->execute(['id' => $reportId]);
        $insert = $pdo->prepare('INSERT INTO report_items (report_id, activity_id, description, updated_at) VALUES (:r, :a, :d, :now)');
        foreach ($items as $activityId => $description) {
            $insert->execute(['r' => $reportId, 'a' => $activityId, 'd' => $description, 'now' => DateTimes::toDb($now)]);
        }
    }

    /** @return array<int, string> activity_id => descripción */
    public function items(int $reportId): array
    {
        $result = [];
        foreach ($this->db->fetchAll('SELECT activity_id, description FROM report_items WHERE report_id = :id', ['id' => $reportId]) as $row) {
            $result[(int) $row['activity_id']] = (string) $row['description'];
        }

        return $result;
    }

    /** Bloquea el informe y devuelve su estado actual (decisiones concurrentes seguras). */
    public function lockStatus(int $id): ?ReportStatus
    {
        $rows = $this->db->fetchAll('SELECT status FROM reports WHERE id = :id FOR UPDATE', ['id' => $id]);

        return isset($rows[0]) ? ReportStatus::from((string) $rows[0]['status']) : null;
    }

    public function setStatus(int $id, ReportStatus $status, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE reports SET status = :s, updated_at = :now WHERE id = :id')
            ->execute(['s' => $status->value, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    public function setSubmitted(int $id, ReportStatus $status, int $version, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE reports SET status = :s, current_version = :v, updated_at = :now WHERE id = :id')
            ->execute(['s' => $status->value, 'v' => $version, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    public function setApproved(int $id, int $version, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE reports SET status = 'approved', approved_version = :v, approved_at = :now, approved_by = :u, updated_at = :now2 WHERE id = :id",
        )->execute(['v' => $version, 'now' => DateTimes::toDb($now), 'u' => $userId, 'now2' => DateTimes::toDb($now), 'id' => $id]);
    }

    /** Reapertura: el informe deja de estar aprobado (la aprobación queda en report_reviews). */
    public function reopen(int $id, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE reports SET status = 'observed', approved_version = NULL, approved_at = NULL, approved_by = NULL, updated_at = :now WHERE id = :id",
        )->execute(['now' => DateTimes::toDb($now), 'id' => $id]);
    }

    public function insertVersion(int $reportId, int $version, string $content, string $hash, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'INSERT INTO report_versions (report_id, version, content, content_hash, submitted_by, submitted_at)
             VALUES (:r, :v, :c, :h, :u, :now)',
        )->execute(['r' => $reportId, 'v' => $version, 'c' => $content, 'h' => $hash, 'u' => $userId, 'now' => DateTimes::toDb($now)]);
    }

    /**
     * @return list<array{version: int, content_hash: string, submitted_by: string, submitted_at: DateTimeImmutable,
     *     pdf_status: string, pdf_path: ?string, pdf_sha256: ?string, pdf_size_bytes: ?int, pdf_generated_at: ?DateTimeImmutable}>
     */
    public function versions(int $reportId, ?int $version = null): array
    {
        $sql = 'SELECT v.version, v.content_hash, v.submitted_at, v.pdf_status, v.pdf_path, v.pdf_sha256, v.pdf_size_bytes,
                    v.pdf_generated_at, u.first_name, u.last_name
             FROM report_versions v JOIN users u ON u.id = v.submitted_by WHERE v.report_id = :id';
        $params = ['id' => $reportId];
        if ($version !== null) {
            $sql .= ' AND v.version = :version';
            $params['version'] = $version;
        }

        return array_map(static fn (array $r) => [
            'version' => (int) $r['version'],
            'content_hash' => (string) $r['content_hash'],
            'submitted_by' => trim($r['first_name'] . ' ' . $r['last_name']),
            'submitted_at' => DateTimes::fromDb((string) $r['submitted_at']),
            'pdf_status' => (string) $r['pdf_status'],
            'pdf_path' => $r['pdf_path'] === null ? null : (string) $r['pdf_path'],
            'pdf_sha256' => $r['pdf_sha256'] === null ? null : (string) $r['pdf_sha256'],
            'pdf_size_bytes' => $r['pdf_size_bytes'] === null ? null : (int) $r['pdf_size_bytes'],
            'pdf_generated_at' => DateTimes::fromDbNullable($r['pdf_generated_at'] === null ? null : (string) $r['pdf_generated_at']),
        ], $this->db->fetchAll($sql . ' ORDER BY v.version DESC', $params));
    }

    /** @return array{content: string, content_hash: string}|null */
    public function versionContent(int $reportId, int $version): ?array
    {
        $rows = $this->db->fetchAll('SELECT content, content_hash FROM report_versions WHERE report_id = :r AND version = :v', ['r' => $reportId, 'v' => $version]);

        return isset($rows[0]) ? ['content' => (string) $rows[0]['content'], 'content_hash' => (string) $rows[0]['content_hash']] : null;
    }

    public function setPdfReady(int $reportId, int $version, string $path, string $sha256, int $size, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE report_versions SET pdf_status = 'ready', pdf_path = :path, pdf_sha256 = :hash, pdf_size_bytes = :size, pdf_generated_at = :now
             WHERE report_id = :r AND version = :v",
        )->execute(['path' => $path, 'hash' => $sha256, 'size' => $size, 'now' => DateTimes::toDb($now), 'r' => $reportId, 'v' => $version]);
    }

    /** Falla definitiva de la generación: si ya había un PDF anterior, se conserva. */
    public function setPdfFailed(int $reportId, int $version): void
    {
        $this->db->pdo()->prepare(
            "UPDATE report_versions SET pdf_status = 'failed' WHERE report_id = :r AND version = :v AND pdf_path IS NULL",
        )->execute(['r' => $reportId, 'v' => $version]);
    }

    public function insertReview(string $uuid, int $reportId, int $version, string $decision, ?string $comment, int $userId, DateTimeImmutable $now): int
    {
        $this->db->pdo()->prepare(
            'INSERT INTO report_reviews (uuid, report_id, version, decision, comment, reviewer_id, created_at)
             VALUES (:uuid, :r, :v, :d, :c, :u, :now)',
        )->execute(['uuid' => $uuid, 'r' => $reportId, 'v' => $version, 'd' => $decision, 'c' => $comment, 'u' => $userId, 'now' => DateTimes::toDb($now)]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    public function insertObservation(int $reviewId, ?int $activityId, string $text): void
    {
        $this->db->pdo()->prepare('INSERT INTO report_observations (review_id, activity_id, text) VALUES (:r, :a, :t)')
            ->execute(['r' => $reviewId, 'a' => $activityId, 't' => $text]);
    }

    /**
     * @return list<array{uuid: string, version: int, decision: string, comment: ?string, reviewer: string, created_at: DateTimeImmutable,
     *     observations: list<array{activity_uuid: ?string, activity_title: ?string, text: string}>}>
     */
    public function reviews(int $reportId): array
    {
        $reviews = [];
        $observations = [];
        foreach ($this->db->fetchAll(
            'SELECT rv.id, rv.uuid, rv.version, rv.decision, rv.comment, rv.created_at, u.first_name, u.last_name
             FROM report_reviews rv JOIN users u ON u.id = rv.reviewer_id WHERE rv.report_id = :id ORDER BY rv.created_at DESC, rv.id DESC',
            ['id' => $reportId],
        ) as $row) {
            $reviews[(int) $row['id']] = [
                'uuid' => (string) $row['uuid'],
                'version' => (int) $row['version'],
                'decision' => (string) $row['decision'],
                'comment' => $row['comment'] === null ? null : (string) $row['comment'],
                'reviewer' => trim($row['first_name'] . ' ' . $row['last_name']),
                'created_at' => DateTimes::fromDb((string) $row['created_at']),
            ];
        }
        if ($reviews !== []) {
            $ids = array_keys($reviews);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            foreach ($this->db->fetchAll(
                "SELECT o.review_id, o.text, a.uuid AS activity_uuid, a.title AS activity_title
                 FROM report_observations o LEFT JOIN activities a ON a.id = o.activity_id
                 WHERE o.review_id IN ({$placeholders}) ORDER BY o.id",
                $ids,
            ) as $row) {
                $observations[(int) $row['review_id']][] = [
                    'activity_uuid' => $row['activity_uuid'] === null ? null : (string) $row['activity_uuid'],
                    'activity_title' => $row['activity_title'] === null ? null : (string) $row['activity_title'],
                    'text' => (string) $row['text'],
                ];
            }
        }

        $result = [];
        foreach ($reviews as $id => $review) {
            $result[] = $review + ['observations' => $observations[$id] ?? []];
        }

        return $result;
    }

    /**
     * Avances declarados en el período, con la obligación a la que pertenecen (hasta 3 niveles).
     *
     * @return list<array{obligation_id: int, activity_title: string, previous: string, new: string, note: string, user: string, recorded_at: DateTimeImmutable}>
     */
    public function progressInPeriod(int $contractId, DateTimeImmutable $fromUtc, DateTimeImmutable $toUtc): array
    {
        return array_map(static fn (array $r) => [
            'obligation_id' => (int) $r['obligation_id'],
            'activity_title' => (string) $r['title'],
            'previous' => (string) $r['previous_progress'],
            'new' => (string) $r['new_progress'],
            'note' => (string) $r['note'],
            'user' => trim($r['first_name'] . ' ' . $r['last_name']),
            'recorded_at' => DateTimes::fromDb((string) $r['recorded_at']),
        ], $this->db->fetchAll(
            'SELECT COALESCE(gp.id, p.id, a.id) AS obligation_id, a.title, pu.previous_progress, pu.new_progress, pu.note,
                    pu.recorded_at, u.first_name, u.last_name
             FROM progress_updates pu
             JOIN activities a ON a.id = pu.activity_id
             LEFT JOIN activities p ON p.id = a.parent_id
             LEFT JOIN activities gp ON gp.id = p.parent_id
             JOIN users u ON u.id = pu.user_id
             WHERE a.contract_id = :contract AND pu.recorded_at >= :from AND pu.recorded_at < :to
             ORDER BY pu.recorded_at, pu.id',
            ['contract' => $contractId, 'from' => DateTimes::toDb($fromUtc), 'to' => DateTimes::toDb($toUtc)],
        ));
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Report
    {
        $date = static fn (mixed $v): DateTimeImmutable => new DateTimeImmutable((string) $v, new \DateTimeZone('UTC'));

        return new Report(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            contractId: (int) $row['contract_id'],
            contractUuid: (string) $row['contract_uuid'],
            contractNumber: (string) $row['contract_number'],
            contractorName: (string) $row['contractor_name'],
            number: (int) $row['number'],
            periodStart: $date($row['period_start']),
            periodEnd: $date($row['period_end']),
            status: ReportStatus::from((string) $row['status']),
            summary: $row['summary'] === null ? null : (string) $row['summary'],
            contractorNotes: $row['contractor_notes'] === null ? null : (string) $row['contractor_notes'],
            currentVersion: (int) $row['current_version'],
            approvedVersion: $row['approved_version'] === null ? null : (int) $row['approved_version'],
            approvedAt: DateTimes::fromDbNullable($row['approved_at'] === null ? null : (string) $row['approved_at']),
            approvedByName: $row['approved_by_name'] === null ? null : (string) $row['approved_by_name'],
            createdBy: (int) $row['created_by'],
            createdAt: DateTimes::fromDb((string) $row['created_at']),
            updatedAt: DateTimes::fromDb((string) $row['updated_at']),
        );
    }
}
