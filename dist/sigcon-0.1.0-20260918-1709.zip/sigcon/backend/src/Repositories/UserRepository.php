<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use PDO;
use Sigcon\Database\Database;
use Sigcon\DTOs\UserFilters;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\User;
use Sigcon\Models\UserStatus;

final class UserRepository
{
    private const COLUMNS = 'u.id, u.uuid, u.first_name, u.last_name, u.email, u.phone, u.status,
        u.must_change_password, u.last_login_at, u.created_at, u.updated_at,
        u.department_id, d.uuid AS department_uuid, d.code AS department_code, d.name AS department_name';

    private const FROM = 'users u LEFT JOIN departments d ON d.id = u.department_id';

    /** Claves de orden públicas => expresión SQL. */
    public const SORTABLE = [
        'name' => 'u.last_name, u.first_name',
        'email' => 'u.email',
        'created_at' => 'u.created_at',
        'last_login_at' => 'u.last_login_at',
    ];

    /** Columnas que UserRepository::update() puede modificar. */
    private const UPDATABLE = ['first_name', 'last_name', 'email', 'phone', 'department_id'];

    public function __construct(private readonly Database $db)
    {
    }

    public function findById(int $id): ?User
    {
        return $this->findOneWhere('u.id = :value', $id);
    }

    public function findByUuid(string $uuid): ?User
    {
        return $this->findOneWhere('u.uuid = :value', $uuid);
    }

    public function findByEmail(string $email): ?User
    {
        return $this->findOneWhere('u.email = :value', mb_strtolower($email));
    }

    public function findPasswordHash(int $id): ?string
    {
        $stmt = $this->db->pdo()->prepare('SELECT password_hash FROM users WHERE id = :id AND deleted_at IS NULL');
        $stmt->execute(['id' => $id]);
        $hash = $stmt->fetchColumn();

        return is_string($hash) ? $hash : null;
    }

    public function emailExists(string $email, ?int $exceptId = null): bool
    {
        $stmt = $this->db->pdo()->prepare('SELECT 1 FROM users WHERE email = :email AND (:except IS NULL OR id <> :except2)');
        $stmt->execute(['email' => $email, 'except' => $exceptId, 'except2' => $exceptId]);

        return $stmt->fetchColumn() !== false;
    }

    public function create(
        string $uuid,
        string $firstName,
        string $lastName,
        string $email,
        ?string $phone,
        string $passwordHash,
        bool $mustChangePassword,
        DateTimeImmutable $now,
        ?int $actorId,
        ?int $departmentId = null,
    ): int {
        $stmt = $this->db->pdo()->prepare(
            'INSERT INTO users (uuid, first_name, last_name, email, phone, department_id, password_hash, status, must_change_password,
                created_at, updated_at, created_by, updated_by)
             VALUES (:uuid, :first_name, :last_name, :email, :phone, :department, :hash, :status, :must_change, :now, :now2, :actor, :actor2)',
        );
        $stmt->execute([
            'department' => $departmentId,
            'uuid' => $uuid,
            'first_name' => $firstName,
            'last_name' => $lastName,
            'email' => $email,
            'phone' => $phone,
            'hash' => $passwordHash,
            'status' => UserStatus::Active->value,
            'must_change' => (int) $mustChangePassword,
            'now' => DateTimes::toDb($now),
            'now2' => DateTimes::toDb($now),
            'actor' => $actorId,
            'actor2' => $actorId,
        ]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    /**
     * @param array<string, string|int|null> $changes columna => valor (solo columnas de UPDATABLE)
     */
    public function update(int $id, array $changes, DateTimeImmutable $now, ?int $actorId): void
    {
        $sets = [];
        $params = ['id' => $id, 'now' => DateTimes::toDb($now), 'actor' => $actorId];
        foreach ($changes as $column => $value) {
            if (!in_array($column, self::UPDATABLE, true)) {
                throw new \InvalidArgumentException(sprintf('Columna no actualizable: %s', $column));
            }
            $sets[] = sprintf('%s = :%s', $column, $column);
            $params[$column] = $value;
        }
        if ($sets === []) {
            return;
        }
        $sql = sprintf('UPDATE users SET %s, updated_at = :now, updated_by = :actor WHERE id = :id', implode(', ', $sets));
        $this->db->pdo()->prepare($sql)->execute($params);
    }

    public function updatePassword(int $id, string $passwordHash, bool $mustChange, DateTimeImmutable $now, ?int $actorId): void
    {
        $this->db->pdo()->prepare(
            'UPDATE users SET password_hash = :hash, must_change_password = :must, password_changed_at = :now,
                updated_at = :now2, updated_by = :actor WHERE id = :id',
        )->execute([
            'hash' => $passwordHash,
            'must' => (int) $mustChange,
            'now' => DateTimes::toDb($now),
            'now2' => DateTimes::toDb($now),
            'actor' => $actorId,
            'id' => $id,
        ]);
    }

    /** Rehash transparente: no cambia password_changed_at ni la autoría. */
    public function replacePasswordHash(int $id, string $passwordHash): void
    {
        $this->db->pdo()->prepare('UPDATE users SET password_hash = :hash WHERE id = :id')
            ->execute(['hash' => $passwordHash, 'id' => $id]);
    }

    public function touchLastLogin(int $id, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE users SET last_login_at = :now WHERE id = :id')
            ->execute(['now' => DateTimes::toDb($now), 'id' => $id]);
    }

    public function setStatus(int $id, UserStatus $status, DateTimeImmutable $now, ?int $actorId): void
    {
        $this->db->pdo()->prepare('UPDATE users SET status = :status, updated_at = :now, updated_by = :actor WHERE id = :id')
            ->execute(['status' => $status->value, 'now' => DateTimes::toDb($now), 'actor' => $actorId, 'id' => $id]);
    }

    /** @return Page<User> */
    public function paginate(UserFilters $filters, PageRequest $page): Page
    {
        $where = ['u.deleted_at IS NULL'];
        $params = [];
        if ($filters->search !== null) {
            $where[] = '(u.first_name LIKE :s1 OR u.last_name LIKE :s2 OR u.email LIKE :s3)';
            $like = '%' . addcslashes($filters->search, '%_\\') . '%';
            $params += ['s1' => $like, 's2' => $like, 's3' => $like];
        }
        if ($filters->status !== null) {
            $where[] = 'u.status = :status';
            $params['status'] = $filters->status->value;
        }
        if ($filters->departmentUuid !== null) {
            $where[] = 'd.uuid = :department';
            $params['department'] = $filters->departmentUuid;
        }
        if ($filters->roleCode !== null) {
            $where[] = 'EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id AND r.code = :role)';
            $params['role'] = $filters->roleCode;
        }
        $whereSql = implode(' AND ', $where);

        $count = $this->db->pdo()->prepare('SELECT COUNT(*) FROM ' . self::FROM . " WHERE {$whereSql}");
        $count->execute($params);
        $total = (int) $count->fetchColumn();

        $sql = sprintf(
            'SELECT %s FROM %s WHERE %s ORDER BY %s LIMIT %d OFFSET %d',
            self::COLUMNS,
            self::FROM,
            $whereSql,
            $page->orderBy('u.id'),
            $page->perPage,
            $page->offset(),
        );
        return new Page(array_map($this->hydrate(...), $this->db->fetchAll($sql, $params)), $total, $page);
    }

    /** @return list<array{code: string, name: string}> */
    public function rolesFor(int $userId): array
    {
        return $this->rolesForUsers([$userId])[$userId] ?? [];
    }

    /**
     * Roles de varios usuarios en una sola consulta (evita N+1 en listados).
     *
     * @param list<int> $userIds
     * @return array<int, list<array{code: string, name: string}>>
     */
    public function rolesForUsers(array $userIds): array
    {
        if ($userIds === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        $stmt = $this->db->pdo()->prepare(
            "SELECT ur.user_id, r.code, r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id
             WHERE ur.user_id IN ({$placeholders}) ORDER BY r.name",
        );
        $stmt->execute($userIds);

        $result = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[(int) $row['user_id']][] = ['code' => (string) $row['code'], 'name' => (string) $row['name']];
        }

        return $result;
    }

    /** @return list<string> códigos de permiso efectivos (unión de todos sus roles) */
    public function permissionsFor(int $userId): array
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT DISTINCT p.code FROM user_roles ur
             JOIN role_permissions rp ON rp.role_id = ur.role_id
             JOIN permissions p ON p.id = rp.permission_id
             WHERE ur.user_id = :id ORDER BY p.code',
        );
        $stmt->execute(['id' => $userId]);

        return array_values(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN)));
    }

    /**
     * @param list<int> $roleIds
     */
    public function replaceRoles(int $userId, array $roleIds, DateTimeImmutable $now, ?int $actorId): void
    {
        $pdo = $this->db->pdo();
        $pdo->prepare('DELETE FROM user_roles WHERE user_id = :id')->execute(['id' => $userId]);
        $insert = $pdo->prepare('INSERT INTO user_roles (user_id, role_id, assigned_at, assigned_by) VALUES (:user, :role, :now, :actor)');
        foreach ($roleIds as $roleId) {
            $insert->execute(['user' => $userId, 'role' => $roleId, 'now' => DateTimes::toDb($now), 'actor' => $actorId]);
        }
    }

    /**
     * Cuenta usuarios activos con un rol. Con FOR UPDATE bloquea las filas leídas para que dos
     * operaciones concurrentes no dejen el sistema sin administradores.
     */
    public function countActiveWithRole(string $roleCode, ?int $excludingUserId = null): int
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT u.id FROM users u
             JOIN user_roles ur ON ur.user_id = u.id
             JOIN roles r ON r.id = ur.role_id
             WHERE r.code = :role AND u.status = :status AND u.deleted_at IS NULL
               AND (:except IS NULL OR u.id <> :except2)
             FOR UPDATE',
        );
        $stmt->execute([
            'role' => $roleCode,
            'status' => UserStatus::Active->value,
            'except' => $excludingUserId,
            'except2' => $excludingUserId,
        ]);

        return count($stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /**
     * Usuarios activos que tienen un permiso (a través de cualquiera de sus roles).
     *
     * @return list<User>
     */
    public function activeWithPermission(string $permissionCode): array
    {
        $rows = $this->db->fetchAll(sprintf(
            'SELECT DISTINCT %s FROM %s
             JOIN user_roles ur ON ur.user_id = u.id
             JOIN role_permissions rp ON rp.role_id = ur.role_id
             JOIN permissions p ON p.id = rp.permission_id
             WHERE p.code = :code AND u.status = :status AND u.deleted_at IS NULL
             ORDER BY u.last_name, u.first_name',
            self::COLUMNS,
            self::FROM,
        ), ['code' => $permissionCode, 'status' => UserStatus::Active->value]);

        return array_map($this->hydrate(...), $rows);
    }

    /** Bloquea la fila del usuario hasta el fin de la transacción (evita actualizaciones perdidas). */
    public function lockById(int $id): void
    {
        $this->db->pdo()->prepare('SELECT id FROM users WHERE id = :id FOR UPDATE')->execute(['id' => $id]);
    }

    private function findOneWhere(string $condition, int|string $value): ?User
    {
        $stmt = $this->db->pdo()->prepare(sprintf('SELECT %s FROM %s WHERE %s AND u.deleted_at IS NULL', self::COLUMNS, self::FROM, $condition));
        $stmt->execute(['value' => $value]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row) ? $this->hydrate($row) : null;
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): User
    {
        return new User(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            firstName: (string) $row['first_name'],
            lastName: (string) $row['last_name'],
            email: (string) $row['email'],
            phone: $row['phone'] === null ? null : (string) $row['phone'],
            status: UserStatus::from((string) $row['status']),
            mustChangePassword: (bool) $row['must_change_password'],
            lastLoginAt: DateTimes::fromDbNullable($row['last_login_at'] === null ? null : (string) $row['last_login_at']),
            createdAt: DateTimes::fromDb((string) $row['created_at']),
            updatedAt: DateTimes::fromDb((string) $row['updated_at']),
            departmentId: $row['department_id'] === null ? null : (int) $row['department_id'],
            departmentUuid: $row['department_uuid'] === null ? null : (string) $row['department_uuid'],
            departmentCode: $row['department_code'] === null ? null : (string) $row['department_code'],
            departmentName: $row['department_name'] === null ? null : (string) $row['department_name'],
        );
    }
}
