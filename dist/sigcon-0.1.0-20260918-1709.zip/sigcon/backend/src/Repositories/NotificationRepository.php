<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;

final class NotificationRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    public function insert(string $uuid, int $userId, string $type, string $title, ?string $body, ?string $link, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'INSERT INTO notifications (uuid, user_id, type, title, body, link_path, created_at) VALUES (:uuid, :user, :type, :title, :body, :link, :now)',
        )->execute(['uuid' => $uuid, 'user' => $userId, 'type' => $type, 'title' => $title, 'body' => $body, 'link' => $link, 'now' => DateTimes::toDb($now)]);
    }

    /**
     * @return Page<array{uuid: string, type: string, title: string, body: ?string, link_path: ?string, read_at: ?DateTimeImmutable, created_at: DateTimeImmutable}>
     */
    public function forUser(int $userId, bool $unreadOnly, PageRequest $page): Page
    {
        $where = 'user_id = :user' . ($unreadOnly ? ' AND read_at IS NULL' : '');
        $total = (int) ($this->db->fetchAll("SELECT COUNT(*) AS total FROM notifications WHERE {$where}", ['user' => $userId])[0]['total'] ?? 0);
        $rows = $this->db->fetchAll(
            sprintf('SELECT * FROM notifications WHERE %s ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d', $where, $page->perPage, $page->offset()),
            ['user' => $userId],
        );

        return new Page(array_map(static fn (array $r) => [
            'uuid' => (string) $r['uuid'],
            'type' => (string) $r['type'],
            'title' => (string) $r['title'],
            'body' => $r['body'] === null ? null : (string) $r['body'],
            'link_path' => $r['link_path'] === null ? null : (string) $r['link_path'],
            'read_at' => DateTimes::fromDbNullable($r['read_at'] === null ? null : (string) $r['read_at']),
            'created_at' => DateTimes::fromDb((string) $r['created_at']),
        ], $rows), $total, $page);
    }

    public function unreadCount(int $userId): int
    {
        return (int) ($this->db->fetchAll('SELECT COUNT(*) AS total FROM notifications WHERE user_id = :user AND read_at IS NULL', ['user' => $userId])[0]['total'] ?? 0);
    }

    /** Solo el destinatario puede marcarla (la condición incluye el usuario). */
    public function markRead(string $uuid, int $userId, DateTimeImmutable $now): bool
    {
        $statement = $this->db->pdo()->prepare('UPDATE notifications SET read_at = COALESCE(read_at, :now) WHERE uuid = :uuid AND user_id = :user');
        $statement->execute(['now' => DateTimes::toDb($now), 'uuid' => $uuid, 'user' => $userId]);

        return $statement->rowCount() === 1
            || $this->db->fetchAll('SELECT 1 FROM notifications WHERE uuid = :uuid AND user_id = :user', ['uuid' => $uuid, 'user' => $userId]) !== [];
    }

    public function markAllRead(int $userId, DateTimeImmutable $now): int
    {
        $statement = $this->db->pdo()->prepare('UPDATE notifications SET read_at = :now WHERE user_id = :user AND read_at IS NULL');
        $statement->execute(['now' => DateTimes::toDb($now), 'user' => $userId]);

        return $statement->rowCount();
    }

    public function deleteReadBefore(DateTimeImmutable $before): int
    {
        $statement = $this->db->pdo()->prepare('DELETE FROM notifications WHERE read_at IS NOT NULL AND read_at < :before');
        $statement->execute(['before' => DateTimes::toDb($before)]);

        return $statement->rowCount();
    }
}
