<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Models\ActiveStatus;
use Sigcon\Models\Department;

final class DepartmentRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    /**
     * Catálogo completo (es pequeño: no requiere paginación), con el número de contratos vigentes.
     *
     * @return list<Department>
     */
    public function all(?ActiveStatus $status = null): array
    {
        $sql = "SELECT d.id, d.uuid, d.code, d.name, d.status,
                (SELECT COUNT(*) FROM contracts c
                  WHERE c.department_id = d.id AND c.deleted_at IS NULL AND c.status IN ('active', 'suspended')) AS active_contracts
                FROM departments d";
        $params = [];
        if ($status !== null) {
            $sql .= ' WHERE d.status = :status';
            $params['status'] = $status->value;
        }

        return array_map($this->hydrate(...), $this->db->fetchAll($sql . ' ORDER BY d.name', $params));
    }

    public function findByUuid(string $uuid): ?Department
    {
        $rows = $this->db->fetchAll('SELECT id, uuid, code, name, status FROM departments WHERE uuid = :uuid', ['uuid' => $uuid]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    public function exists(string $column, string $value, ?int $exceptId = null): bool
    {
        if (!in_array($column, ['code', 'name'], true)) {
            throw new \InvalidArgumentException('Columna no permitida.');
        }
        $rows = $this->db->fetchAll(
            "SELECT 1 FROM departments WHERE {$column} = :value AND (:except IS NULL OR id <> :except2)",
            ['value' => $value, 'except' => $exceptId, 'except2' => $exceptId],
        );

        return $rows !== [];
    }

    public function create(string $uuid, string $code, string $name, DateTimeImmutable $now, ?int $actorId): int
    {
        $this->db->pdo()->prepare(
            'INSERT INTO departments (uuid, code, name, status, created_at, updated_at, created_by, updated_by)
             VALUES (:uuid, :code, :name, :status, :now, :now2, :actor, :actor2)',
        )->execute([
            'uuid' => $uuid,
            'code' => $code,
            'name' => $name,
            'status' => ActiveStatus::Active->value,
            'now' => DateTimes::toDb($now),
            'now2' => DateTimes::toDb($now),
            'actor' => $actorId,
            'actor2' => $actorId,
        ]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    public function update(int $id, string $code, string $name, DateTimeImmutable $now, ?int $actorId): void
    {
        $this->db->pdo()->prepare(
            'UPDATE departments SET code = :code, name = :name, updated_at = :now, updated_by = :actor WHERE id = :id',
        )->execute(['code' => $code, 'name' => $name, 'now' => DateTimes::toDb($now), 'actor' => $actorId, 'id' => $id]);
    }

    public function setStatus(int $id, ActiveStatus $status, DateTimeImmutable $now, ?int $actorId): void
    {
        $this->db->pdo()->prepare('UPDATE departments SET status = :status, updated_at = :now, updated_by = :actor WHERE id = :id')
            ->execute(['status' => $status->value, 'now' => DateTimes::toDb($now), 'actor' => $actorId, 'id' => $id]);
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Department
    {
        return new Department(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            code: (string) $row['code'],
            name: (string) $row['name'],
            status: ActiveStatus::from((string) $row['status']),
            activeContracts: (int) ($row['active_contracts'] ?? 0),
        );
    }
}
