<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Helpers\Money;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Payment;
use Sigcon\Models\PaymentStatus;

final class PaymentRepository
{
    private const SELECT = "SELECT p.*, c.uuid AS contract_uuid, c.contract_number, ct.name AS contractor_name,
        r.uuid AS report_uuid, r.number AS report_number, r.period_start, r.period_end,
        CONCAT(cb.first_name, ' ', cb.last_name) AS created_by_name,
        CONCAT(ab.first_name, ' ', ab.last_name) AS approved_by_name,
        CONCAT(pb.first_name, ' ', pb.last_name) AS paid_by_name
        FROM payments p
        JOIN contracts c ON c.id = p.contract_id
        JOIN contractors ct ON ct.id = c.contractor_id
        JOIN reports r ON r.id = p.report_id
        JOIN users cb ON cb.id = p.created_by
        LEFT JOIN users ab ON ab.id = p.approved_by
        LEFT JOIN users pb ON pb.id = p.paid_registered_by";

    public const SORTABLE = ['updated_at' => 'p.updated_at', 'created_at' => 'p.created_at', 'number' => 'p.number'];

    public function __construct(private readonly Database $db)
    {
    }

    public function findByUuid(string $uuid): ?Payment
    {
        $rows = $this->db->fetchAll(self::SELECT . ' WHERE p.uuid = :uuid', ['uuid' => $uuid]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    public function findById(int $id): ?Payment
    {
        $rows = $this->db->fetchAll(self::SELECT . ' WHERE p.id = :id', ['id' => $id]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    /** @return Page<Payment> */
    public function paginate(?PaymentStatus $status, ?string $contractUuid, PageRequest $page, ContractScope $scope): Page
    {
        [$scopeSql, $params] = $scope->toSql();
        $where = ['c.deleted_at IS NULL', $scopeSql];
        if ($status !== null) {
            $where[] = 'p.status = :status';
            $params['status'] = $status->value;
        }
        if ($contractUuid !== null) {
            $where[] = 'c.uuid = :contract';
            $params['contract'] = $contractUuid;
        }
        $whereSql = implode(' AND ', $where);
        $total = (int) ($this->db->fetchAll(
            "SELECT COUNT(*) AS total FROM payments p JOIN contracts c ON c.id = p.contract_id JOIN contractors ct ON ct.id = c.contractor_id WHERE {$whereSql}",
            $params,
        )[0]['total'] ?? 0);
        $rows = $this->db->fetchAll(sprintf('%s WHERE %s ORDER BY %s LIMIT %d OFFSET %d', self::SELECT, $whereSql, $page->orderBy('p.id'), $page->perPage, $page->offset()), $params);

        return new Page(array_map($this->hydrate(...), $rows), $total, $page);
    }

    public function nextNumber(int $contractId): int
    {
        return (int) ($this->db->fetchAll('SELECT COALESCE(MAX(number), 0) + 1 AS n FROM payments WHERE contract_id = :id', ['id' => $contractId])[0]['n'] ?? 1);
    }

    /**
     * Totales del contrato en centavos: comprometido (pagos no anulados) y pagado.
     *
     * @return array{committed: int, paid: int}
     */
    public function totals(int $contractId, ?int $exceptPaymentId = null): array
    {
        $rows = $this->db->fetchAll(
            'SELECT status, amount FROM payments WHERE contract_id = :id AND (:except IS NULL OR id <> :except2)',
            ['id' => $contractId, 'except' => $exceptPaymentId, 'except2' => $exceptPaymentId],
        );
        $committed = 0;
        $paid = 0;
        foreach ($rows as $row) {
            $status = PaymentStatus::from((string) $row['status']);
            $cents = Money::toCents((string) $row['amount']);
            if ($status->commitsBudget()) {
                $committed += $cents;
            }
            if ($status === PaymentStatus::Paid) {
                $paid += $cents;
            }
        }

        return ['committed' => $committed, 'paid' => $paid];
    }

    public function activeForReport(int $reportId): ?Payment
    {
        $rows = $this->db->fetchAll(self::SELECT . " WHERE p.report_id = :id AND p.status <> 'cancelled'", ['id' => $reportId]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    public function create(string $uuid, int $contractId, int $reportId, int $number, string $amount, ?string $notes, int $userId, DateTimeImmutable $now): int
    {
        $this->db->pdo()->prepare(
            'INSERT INTO payments (uuid, contract_id, report_id, number, amount, notes, status, created_by, created_at, updated_at)
             VALUES (:uuid, :contract, :report, :number, :amount, :notes, :status, :user, :now, :now2)',
        )->execute([
            'uuid' => $uuid, 'contract' => $contractId, 'report' => $reportId, 'number' => $number, 'amount' => $amount,
            'notes' => $notes, 'status' => PaymentStatus::Draft->value, 'user' => $userId,
            'now' => DateTimes::toDb($now), 'now2' => DateTimes::toDb($now),
        ]);

        return (int) $this->db->pdo()->lastInsertId();
    }

    /** Bloquea el pago y devuelve su estado actual (decisiones concurrentes seguras). */
    public function lockStatus(int $id): ?PaymentStatus
    {
        $rows = $this->db->fetchAll('SELECT status FROM payments WHERE id = :id FOR UPDATE', ['id' => $id]);

        return isset($rows[0]) ? PaymentStatus::from((string) $rows[0]['status']) : null;
    }

    public function updateDraft(int $id, string $amount, ?string $notes, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare('UPDATE payments SET amount = :amount, notes = :notes, updated_at = :now WHERE id = :id')
            ->execute(['amount' => $amount, 'notes' => $notes, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    private const TRANSITION_COLUMNS = ['submitted_by', 'submitted_at', 'approved_by', 'approved_at', 'payment_date', 'payment_reference',
        'paid_registered_by', 'paid_registered_at', 'cancelled_reason', 'cancelled_by', 'cancelled_at'];

    /** @param array<string, string|int|null> $fields columnas adicionales a actualizar (lista cerrada) */
    public function transition(int $id, PaymentStatus $status, DateTimeImmutable $now, array $fields = []): void
    {
        $set = ['status = :status', 'updated_at = :now'];
        $params = ['status' => $status->value, 'now' => DateTimes::toDb($now), 'id' => $id];
        foreach ($fields as $column => $value) {
            if (!in_array($column, self::TRANSITION_COLUMNS, true)) {
                throw new \InvalidArgumentException("Columna no permitida: {$column}");
            }
            $set[] = "{$column} = :f_{$column}";
            $params["f_{$column}"] = $value;
        }
        $this->db->pdo()->prepare('UPDATE payments SET ' . implode(', ', $set) . ' WHERE id = :id')->execute($params);
    }

    /** @param list<array<string, mixed>> $results */
    public function insertEvaluation(int $paymentId, bool $eligible, array $results, string $trigger, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'INSERT INTO payment_evaluations (payment_id, eligible, results, trigger_event, evaluated_by, evaluated_at)
             VALUES (:p, :e, :r, :t, :u, :now)',
        )->execute([
            'p' => $paymentId, 'e' => $eligible ? 1 : 0, 'r' => json_encode($results, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            't' => $trigger, 'u' => $userId, 'now' => DateTimes::toDb($now),
        ]);
        $this->db->pdo()->prepare('UPDATE payments SET last_eligible = :e, last_evaluated_at = :now WHERE id = :id')
            ->execute(['e' => $eligible ? 1 : 0, 'now' => DateTimes::toDb($now), 'id' => $paymentId]);
    }

    /** @return array{eligible: bool, results: list<array<string, mixed>>, trigger: string, evaluated_by: string, evaluated_at: DateTimeImmutable}|null */
    public function lastEvaluation(int $paymentId): ?array
    {
        $row = $this->db->fetchAll(
            "SELECT e.*, CONCAT(u.first_name, ' ', u.last_name) AS user_name FROM payment_evaluations e JOIN users u ON u.id = e.evaluated_by
             WHERE e.payment_id = :id ORDER BY e.evaluated_at DESC, e.id DESC LIMIT 1",
            ['id' => $paymentId],
        )[0] ?? null;
        if ($row === null) {
            return null;
        }
        $results = json_decode((string) $row['results'], true);

        return [
            'eligible' => (bool) $row['eligible'],
            'results' => is_array($results) ? array_values($results) : [],
            'trigger' => (string) $row['trigger_event'],
            'evaluated_by' => (string) $row['user_name'],
            'evaluated_at' => DateTimes::fromDb((string) $row['evaluated_at']),
        ];
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Payment
    {
        $nullable = static fn (mixed $v): ?string => $v === null ? null : (string) $v;
        $date = static fn (mixed $v): ?DateTimeImmutable => $v === null ? null : new DateTimeImmutable((string) $v, new \DateTimeZone('UTC'));

        return new Payment(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            contractId: (int) $row['contract_id'],
            contractUuid: (string) $row['contract_uuid'],
            contractNumber: (string) $row['contract_number'],
            contractorName: (string) $row['contractor_name'],
            reportId: (int) $row['report_id'],
            reportUuid: (string) $row['report_uuid'],
            reportNumber: (int) $row['report_number'],
            periodStart: new DateTimeImmutable((string) $row['period_start'], new \DateTimeZone('UTC')),
            periodEnd: new DateTimeImmutable((string) $row['period_end'], new \DateTimeZone('UTC')),
            number: (int) $row['number'],
            amount: (string) $row['amount'],
            notes: $nullable($row['notes']),
            status: PaymentStatus::from((string) $row['status']),
            lastEligible: $row['last_eligible'] === null ? null : (bool) $row['last_eligible'],
            lastEvaluatedAt: DateTimes::fromDbNullable($nullable($row['last_evaluated_at'])),
            createdBy: (int) $row['created_by'],
            createdByName: (string) $row['created_by_name'],
            createdAt: DateTimes::fromDb((string) $row['created_at']),
            updatedAt: DateTimes::fromDb((string) $row['updated_at']),
            submittedBy: $row['submitted_by'] === null ? null : (int) $row['submitted_by'],
            submittedAt: DateTimes::fromDbNullable($nullable($row['submitted_at'])),
            approvedByName: $nullable($row['approved_by_name']),
            approvedAt: DateTimes::fromDbNullable($nullable($row['approved_at'])),
            paymentDate: $date($row['payment_date']),
            paymentReference: $nullable($row['payment_reference']),
            paidRegisteredByName: $nullable($row['paid_by_name']),
            cancelledReason: $nullable($row['cancelled_reason']),
            cancelledAt: DateTimes::fromDbNullable($nullable($row['cancelled_at'])),
        );
    }
}
