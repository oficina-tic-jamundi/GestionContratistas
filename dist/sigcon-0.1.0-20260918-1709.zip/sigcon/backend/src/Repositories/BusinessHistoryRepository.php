<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Models\HistoryEntry;

/** Historial de negocio: solo inserción y consulta. */
final class BusinessHistoryRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    /** @param array<mixed>|null $metadata */
    public function insert(
        string $entityType,
        int $entityId,
        string $event,
        string $summary,
        ?string $comment,
        ?string $fromStatus,
        ?string $toStatus,
        ?int $userId,
        DateTimeImmutable $occurredAt,
        ?array $metadata,
    ): void {
        $this->db->pdo()->prepare(
            'INSERT INTO business_history (entity_type, entity_id, event, summary, comment, from_status, to_status, user_id, occurred_at, metadata)
             VALUES (:type, :id, :event, :summary, :comment, :from, :to, :user, :at, :meta)',
        )->execute([
            'type' => $entityType,
            'id' => $entityId,
            'event' => $event,
            'summary' => $summary,
            'comment' => $comment,
            'from' => $fromStatus,
            'to' => $toStatus,
            'user' => $userId,
            'at' => DateTimes::toDb($occurredAt),
            'meta' => $metadata === null ? null : json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
        ]);
    }

    /** @return list<HistoryEntry> del más reciente al más antiguo */
    public function forEntity(string $entityType, int $entityId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT h.id, h.event, h.summary, h.comment, h.from_status, h.to_status, h.occurred_at, h.metadata,
                CONCAT(u.first_name, ' ', u.last_name) AS user_name
             FROM business_history h LEFT JOIN users u ON u.id = h.user_id
             WHERE h.entity_type = :type AND h.entity_id = :id ORDER BY h.occurred_at DESC, h.id DESC",
            ['type' => $entityType, 'id' => $entityId],
        );

        return array_map(static function (array $row): HistoryEntry {
            $metadata = $row['metadata'] === null ? null : json_decode((string) $row['metadata'], true);

            return new HistoryEntry(
                id: (int) $row['id'],
                event: (string) $row['event'],
                summary: (string) $row['summary'],
                comment: $row['comment'] === null ? null : (string) $row['comment'],
                fromStatus: $row['from_status'] === null ? null : (string) $row['from_status'],
                toStatus: $row['to_status'] === null ? null : (string) $row['to_status'],
                userName: $row['user_name'] === null ? null : (string) $row['user_name'],
                occurredAt: DateTimes::fromDb((string) $row['occurred_at']),
                metadata: is_array($metadata) ? $metadata : null,
            );
        }, $rows);
    }
}
