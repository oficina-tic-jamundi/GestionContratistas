<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;
use Sigcon\Models\Document;

final class DocumentRepository
{
    private const SELECT = "SELECT d.id, d.uuid, d.entity_type, d.entity_id, t.code AS type_code, t.name AS type_name,
        d.description, d.original_name, d.extension, d.mime_type, d.size_bytes, d.sha256, d.storage_path, d.status,
        d.withdrawn_reason, d.withdrawn_at, d.uploaded_by, d.created_at,
        CONCAT(u.first_name, ' ', u.last_name) AS uploaded_by_name,
        CONCAT(w.first_name, ' ', w.last_name) AS withdrawn_by_name
        FROM documents d
        JOIN document_types t ON t.id = d.document_type_id
        JOIN users u ON u.id = d.uploaded_by
        LEFT JOIN users w ON w.id = d.withdrawn_by";

    public function __construct(private readonly Database $db)
    {
    }

    /** @return list<Document> vigentes primero, luego retirados; más recientes primero */
    public function forEntity(string $entityType, int $entityId): array
    {
        return array_map($this->hydrate(...), $this->db->fetchAll(
            self::SELECT . " WHERE d.entity_type = :type AND d.entity_id = :id ORDER BY d.status = 'active' DESC, d.created_at DESC, d.id DESC",
            ['type' => $entityType, 'id' => $entityId],
        ));
    }

    public function findByUuid(string $uuid): ?Document
    {
        $rows = $this->db->fetchAll(self::SELECT . ' WHERE d.uuid = :uuid', ['uuid' => $uuid]);

        return isset($rows[0]) ? $this->hydrate($rows[0]) : null;
    }

    /** @return list<array{code: string, name: string}> */
    public function types(string $entityType): array
    {
        return array_map(
            static fn (array $r) => ['code' => (string) $r['code'], 'name' => (string) $r['name']],
            $this->db->fetchAll('SELECT code, name FROM document_types WHERE entity_type = :type AND is_active = 1 ORDER BY position, name', ['type' => $entityType]),
        );
    }

    public function typeId(string $entityType, string $code): ?int
    {
        $rows = $this->db->fetchAll('SELECT id FROM document_types WHERE entity_type = :type AND code = :code AND is_active = 1', ['type' => $entityType, 'code' => $code]);

        return isset($rows[0]) ? (int) $rows[0]['id'] : null;
    }

    public function activeHashExists(string $entityType, int $entityId, string $sha256): bool
    {
        return $this->db->fetchAll(
            'SELECT 1 FROM documents WHERE entity_type = :type AND entity_id = :id AND active_sha256 = :hash',
            ['type' => $entityType, 'id' => $entityId, 'hash' => $sha256],
        ) !== [];
    }

    /**
     * @param array{extension: string, mime: string, size: int, sha256: string, original_name: string} $file
     */
    public function create(string $uuid, string $entityType, int $entityId, int $typeId, ?string $description, array $file, string $storagePath, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'INSERT INTO documents (uuid, entity_type, entity_id, document_type_id, description, original_name, extension, mime_type,
                size_bytes, sha256, storage_path, status, uploaded_by, created_at)
             VALUES (:uuid, :etype, :eid, :type, :description, :name, :ext, :mime, :size, :hash, :path, :status, :user, :now)',
        )->execute([
            'uuid' => $uuid,
            'etype' => $entityType,
            'eid' => $entityId,
            'type' => $typeId,
            'description' => $description,
            'name' => $file['original_name'],
            'ext' => $file['extension'],
            'mime' => $file['mime'],
            'size' => $file['size'],
            'hash' => $file['sha256'],
            'path' => $storagePath,
            'status' => 'active',
            'user' => $userId,
            'now' => DateTimes::toDb($now),
        ]);
    }

    public function withdraw(int $id, string $reason, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            "UPDATE documents SET status = 'withdrawn', withdrawn_reason = :reason, withdrawn_by = :user, withdrawn_at = :now
             WHERE id = :id AND status = 'active'",
        )->execute(['reason' => $reason, 'user' => $userId, 'now' => DateTimes::toDb($now), 'id' => $id]);
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Document
    {
        $nullable = static fn (mixed $v): ?string => $v === null ? null : (string) $v;

        return new Document(
            id: (int) $row['id'],
            uuid: (string) $row['uuid'],
            entityType: (string) $row['entity_type'],
            entityId: (int) $row['entity_id'],
            typeCode: (string) $row['type_code'],
            typeName: (string) $row['type_name'],
            description: $nullable($row['description']),
            originalName: (string) $row['original_name'],
            extension: (string) $row['extension'],
            mimeType: (string) $row['mime_type'],
            sizeBytes: (int) $row['size_bytes'],
            sha256: (string) $row['sha256'],
            storagePath: (string) $row['storage_path'],
            status: (string) $row['status'],
            withdrawnReason: $nullable($row['withdrawn_reason']),
            withdrawnAt: DateTimes::fromDbNullable($nullable($row['withdrawn_at'])),
            withdrawnByName: $nullable($row['withdrawn_by_name']),
            uploadedBy: (int) $row['uploaded_by'],
            uploadedByName: (string) $row['uploaded_by_name'],
            createdAt: DateTimes::fromDb((string) $row['created_at']),
        );
    }
}
