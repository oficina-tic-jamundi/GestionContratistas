<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\Helpers\DateTimes;

final class PaymentRuleSettingsRepository
{
    public function __construct(private readonly Database $db)
    {
    }

    /** @return array<string, array{enabled: bool, params: array<string, mixed>, updated_by: ?string, updated_at: DateTimeImmutable}> */
    public function all(): array
    {
        $result = [];
        foreach ($this->db->fetchAll(
            "SELECT s.*, CONCAT(u.first_name, ' ', u.last_name) AS user_name FROM payment_rule_settings s LEFT JOIN users u ON u.id = s.updated_by",
        ) as $row) {
            $params = json_decode((string) $row['params'], true);
            $result[(string) $row['code']] = [
                'enabled' => (bool) $row['enabled'],
                'params' => is_array($params) ? $params : [],
                'updated_by' => $row['user_name'] === null ? null : (string) $row['user_name'],
                'updated_at' => DateTimes::fromDb((string) $row['updated_at']),
            ];
        }

        return $result;
    }

    /** @param array<string, mixed> $params */
    public function save(string $code, bool $enabled, array $params, int $userId, DateTimeImmutable $now): void
    {
        $this->db->pdo()->prepare(
            'INSERT INTO payment_rule_settings (code, enabled, params, updated_by, updated_at) VALUES (:code, :enabled, :params, :user, :now)
             ON DUPLICATE KEY UPDATE enabled = VALUES(enabled), params = VALUES(params), updated_by = VALUES(updated_by), updated_at = VALUES(updated_at)',
        )->execute([
            'code' => $code,
            'enabled' => $enabled ? 1 : 0,
            'params' => json_encode((object) $params, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'user' => $userId,
            'now' => DateTimes::toDb($now),
        ]);
    }
}
