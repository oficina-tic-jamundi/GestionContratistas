<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;

/**
 * Alcance de visibilidad de contratos para el usuario actual (autorización por ALCANCE, no solo por permiso):
 *
 * - contracts.view_all       → todos los contratos.
 * - contracts.view_assigned  → contratos donde es supervisor.
 * - contracts.view_own       → contratos de su contratista vinculado, excepto borradores
 *                              (un borrador aún no está formalizado).
 *
 * Un usuario con varios perfiles ve la unión. Sin ninguno de estos permisos no ve nada.
 */
final class ContractScope
{
    private function __construct(
        public readonly bool $all,
        public readonly ?int $supervisorUserId,
        public readonly ?int $contractorUserId,
    ) {
    }

    public static function forUser(AuthContext $auth): self
    {
        if (!$auth->isAuthenticated()) {
            return new self(false, null, null);
        }

        return new self(
            $auth->can(Permission::ContractsViewAll),
            $auth->can(Permission::ContractsViewAssigned) ? $auth->userId() : null,
            $auth->can(Permission::ContractsViewOwn) ? $auth->userId() : null,
        );
    }

    /** Uso interno del sistema (consola, procesos): sin restricción. */
    public static function unrestricted(): self
    {
        return new self(true, null, null);
    }

    public function isEmpty(): bool
    {
        return !$this->all && $this->supervisorUserId === null && $this->contractorUserId === null;
    }

    /**
     * Condición SQL sobre los alias c (contracts) y ct (contractors).
     *
     * @return array{0: string, 1: array<string, int>}
     */
    public function toSql(): array
    {
        if ($this->all) {
            return ['1 = 1', []];
        }
        $conditions = [];
        $params = [];
        if ($this->supervisorUserId !== null) {
            $conditions[] = 'c.supervisor_user_id = :scope_supervisor';
            $params['scope_supervisor'] = $this->supervisorUserId;
        }
        if ($this->contractorUserId !== null) {
            $conditions[] = "(ct.user_id = :scope_contractor AND c.status <> 'draft')";
            $params['scope_contractor'] = $this->contractorUserId;
        }

        return $conditions === [] ? ['1 = 0', []] : ['(' . implode(' OR ', $conditions) . ')', $params];
    }
}
