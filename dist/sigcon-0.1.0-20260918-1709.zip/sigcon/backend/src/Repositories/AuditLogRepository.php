<?php

declare(strict_types=1);

namespace Sigcon\Repositories;

use DateTimeImmutable;
use Sigcon\Database\Database;
use Sigcon\DTOs\AuditFilters;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\AuditEntry;

/**
 * Acceso a audit_logs. Solo inserción y consulta: no existen métodos de actualización ni borrado.
 */
final class AuditLogRepository
{
    public const SORTABLE = ['occurred_at' => 'a.occurred_at'];

    public function __construct(private readonly Database $db)
    {
    }

    /** @param array<mixed>|null $metadata */
    public function insert(
        DateTimeImmutable $occurredAt,
        ?int $userId,
        string $action,
        ?string $entityType,
        ?string $entityId,
        ?string $ipAddress,
        ?string $userAgent,
        ?string $requestId,
        ?array $metadata,
    ): void {
        $this->db->pdo()->prepare(
            'INSERT INTO audit_logs (occurred_at, user_id, action, entity_type, entity_id, ip_address, user_agent, request_id, metadata)
             VALUES (:at, :user, :action, :etype, :eid, :ip, :ua, :rid, :meta)',
        )->execute([
            'at' => DateTimes::toDb($occurredAt),
            'user' => $userId,
            'action' => $action,
            'etype' => $entityType,
            'eid' => $entityId,
            'ip' => $ipAddress,
            'ua' => $userAgent,
            'rid' => $requestId,
            'meta' => $metadata === null ? null : json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
        ]);
    }

    /** @return Page<AuditEntry> */
    public function paginate(AuditFilters $filters, PageRequest $page): Page
    {
        $where = ['1 = 1'];
        $params = [];
        if ($filters->action !== null) {
            // Permite filtrar por prefijo: "user." devuelve todos los eventos de usuarios.
            $where[] = 'a.action LIKE :action';
            $params['action'] = addcslashes($filters->action, '%_\\') . '%';
        }
        if ($filters->entityType !== null) {
            $where[] = 'a.entity_type = :etype';
            $params['etype'] = $filters->entityType;
        }
        if ($filters->entityId !== null) {
            $where[] = 'a.entity_id = :eid';
            $params['eid'] = $filters->entityId;
        }
        if ($filters->userUuid !== null) {
            $where[] = 'u.uuid = :uuid';
            $params['uuid'] = $filters->userUuid;
        }
        if ($filters->from !== null) {
            $where[] = 'a.occurred_at >= :from';
            $params['from'] = DateTimes::toDb($filters->from);
        }
        if ($filters->to !== null) {
            $where[] = 'a.occurred_at < :to';
            $params['to'] = DateTimes::toDb($filters->to);
        }
        $whereSql = implode(' AND ', $where);
        $from = 'FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id';

        $count = $this->db->pdo()->prepare("SELECT COUNT(*) {$from} WHERE {$whereSql}");
        $count->execute($params);
        $total = (int) $count->fetchColumn();

        $rows = $this->db->fetchAll(sprintf(
            'SELECT a.id, a.occurred_at, a.action, a.entity_type, a.entity_id, a.ip_address, a.user_agent, a.request_id,
                a.metadata, u.uuid AS user_uuid, u.first_name, u.last_name, u.email
             %s WHERE %s ORDER BY %s LIMIT %d OFFSET %d',
            $from,
            $whereSql,
            $page->orderBy('a.id'),
            $page->perPage,
            $page->offset(),
        ), $params);

        $items = array_map(static function (array $row): AuditEntry {
            $nullableString = static fn (mixed $value): ?string => $value === null ? null : (string) $value;
            $metadata = $row['metadata'] === null ? null : json_decode((string) $row['metadata'], true);

            return new AuditEntry(
                id: (int) $row['id'],
                occurredAt: DateTimes::fromDb((string) $row['occurred_at']),
                action: (string) $row['action'],
                entityType: $nullableString($row['entity_type']),
                entityId: $nullableString($row['entity_id']),
                ipAddress: $nullableString($row['ip_address']),
                userAgent: $nullableString($row['user_agent']),
                requestId: $nullableString($row['request_id']),
                metadata: is_array($metadata) ? $metadata : null,
                userUuid: $nullableString($row['user_uuid']),
                userName: $row['user_uuid'] === null ? null : trim($row['first_name'] . ' ' . $row['last_name']),
                userEmail: $nullableString($row['email']),
            );
        }, $rows);

        return new Page($items, $total, $page);
    }
}
