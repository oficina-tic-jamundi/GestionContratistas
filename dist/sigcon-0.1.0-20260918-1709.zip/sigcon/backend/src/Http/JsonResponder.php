<?php

declare(strict_types=1);

namespace Sigcon\Http;

use Psr\Http\Message\ResponseInterface;

/**
 * Único punto que serializa respuestas JSON con el formato estándar de la API:
 * { success, data, message, errors, meta }.
 */
final class JsonResponder
{
    private const FLAGS = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR;

    /** @param array<string, mixed> $meta */
    public function success(
        ResponseInterface $response,
        mixed $data = null,
        ?string $message = null,
        int $status = 200,
        array $meta = [],
    ): ResponseInterface {
        return $this->write($response, [
            'success' => true,
            'data' => $data,
            'message' => $message,
            'errors' => [],
            'meta' => (object) $meta,
        ], $status);
    }

    /**
     * @param list<array{field: ?string, code: string, message: string}> $errors
     * @param array<string, mixed> $meta
     */
    public function error(
        ResponseInterface $response,
        string $message,
        int $status,
        string $code,
        array $errors = [],
        array $meta = [],
    ): ResponseInterface {
        return $this->write($response, [
            'success' => false,
            'data' => null,
            'message' => $message,
            'errors' => $errors,
            'meta' => (object) (['code' => $code] + $meta),
        ], $status);
    }

    /** @param array<string, mixed> $payload */
    private function write(ResponseInterface $response, array $payload, int $status): ResponseInterface
    {
        $response->getBody()->write(json_encode($payload, self::FLAGS));

        return $response
            ->withStatus($status)
            ->withHeader('Content-Type', 'application/json; charset=utf-8');
    }
}
