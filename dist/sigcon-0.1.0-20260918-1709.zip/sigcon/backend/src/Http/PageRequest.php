<?php

declare(strict_types=1);

namespace Sigcon\Http;

use Sigcon\Exceptions\ValidationException;

/**
 * Parámetros de paginación y orden validados (docs/api/conventions.md).
 *
 * El orden solo acepta claves de una lista blanca que se traducen a expresiones SQL fijas:
 * nunca se concatena al SQL un valor enviado por el cliente.
 */
final class PageRequest
{
    public const DEFAULT_PER_PAGE = 25;
    public const MAX_PER_PAGE = 100;

    private function __construct(
        public readonly int $page,
        public readonly int $perPage,
        public readonly string $sortKey,
        public readonly string $orderBySql,
        public readonly string $direction,
    ) {
    }

    /**
     * @param array<string, mixed> $query
     * @param array<string, string> $sortable clave pública => expresión SQL (sin dirección)
     */
    public static function fromQuery(array $query, array $sortable, string $defaultSort, string $defaultDirection = 'asc'): self
    {
        $errors = [];

        $page = self::positiveInt($query['page'] ?? null, 1);
        if ($page === null) {
            $errors[] = ['field' => 'page', 'code' => 'invalid', 'message' => 'La página debe ser un número entero mayor que cero.'];
        }

        $perPage = self::positiveInt($query['per_page'] ?? null, self::DEFAULT_PER_PAGE);
        if ($perPage === null || $perPage > self::MAX_PER_PAGE) {
            $errors[] = ['field' => 'per_page', 'code' => 'invalid', 'message' => sprintf('per_page debe estar entre 1 y %d.', self::MAX_PER_PAGE)];
        }

        $sort = $query['sort'] ?? $defaultSort;
        if (!is_string($sort) || !isset($sortable[$sort])) {
            $errors[] = ['field' => 'sort', 'code' => 'invalid', 'message' => 'Campo de orden no permitido.'];
            $sort = $defaultSort;
        }

        $direction = $query['direction'] ?? $defaultDirection;
        if (!in_array($direction, ['asc', 'desc'], true)) {
            $errors[] = ['field' => 'direction', 'code' => 'invalid', 'message' => 'La dirección debe ser asc o desc.'];
            $direction = $defaultDirection;
        }

        if ($errors !== []) {
            throw ValidationException::withErrors($errors);
        }

        /** @var int $page */
        /** @var int $perPage */
        return new self($page, $perPage, $sort, $sortable[$sort], $direction);
    }

    public function offset(): int
    {
        return ($this->page - 1) * $this->perPage;
    }

    /** Cláusula ORDER BY segura, con desempate por id para un orden estable. */
    public function orderBy(string $tieBreaker): string
    {
        $dir = strtoupper($this->direction);
        $columns = array_map(static fn (string $col) => trim($col) . ' ' . $dir, explode(',', $this->orderBySql));

        return implode(', ', $columns) . ', ' . $tieBreaker . ' ' . $dir;
    }

    private static function positiveInt(mixed $value, int $default): ?int
    {
        if ($value === null || $value === '') {
            return $default;
        }
        $int = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

        return $int === false ? null : $int;
    }
}
