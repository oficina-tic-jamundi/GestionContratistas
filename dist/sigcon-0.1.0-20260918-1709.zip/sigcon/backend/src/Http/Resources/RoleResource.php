<?php

declare(strict_types=1);

namespace Sigcon\Http\Resources;

use Sigcon\Models\PermissionDefinition;
use Sigcon\Models\Role;

final class RoleResource
{
    /** @return array<string, mixed> */
    public static function toArray(Role $role): array
    {
        return [
            'code' => $role->code,
            'name' => $role->name,
            'description' => $role->description,
            'is_system' => $role->isSystem,
            'permissions_editable' => $role->code !== Role::ADMIN,
            'permissions' => $role->permissions,
            'user_count' => $role->userCount,
        ];
    }

    /** @return array{code: string, module: string, description: string} */
    public static function permission(PermissionDefinition $permission): array
    {
        return ['code' => $permission->code, 'module' => $permission->module, 'description' => $permission->description];
    }
}
