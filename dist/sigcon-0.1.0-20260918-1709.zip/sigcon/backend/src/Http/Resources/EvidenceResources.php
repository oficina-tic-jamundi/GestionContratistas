<?php

declare(strict_types=1);

namespace Sigcon\Http\Resources;

use Sigcon\Helpers\DateTimes;
use Sigcon\Models\Evidence;

/** Representación pública de evidencias. Nunca incluye ids internos ni rutas físicas. */
final class EvidenceResources
{
    /** @return array<string, mixed> */
    public static function evidence(Evidence $e): array
    {
        return [
            'uuid' => $e->uuid,
            'activity' => [
                'uuid' => $e->activityUuid,
                'title' => $e->activityTitle,
                'level' => $e->activityLevel->value,
                'level_label' => $e->activityLevel->label(),
            ],
            'description' => $e->description,
            'width' => $e->width,
            'height' => $e->height,
            'original' => ['mime_type' => $e->originalMime, 'size_bytes' => $e->originalSizeBytes, 'sha256' => $e->originalSha256],
            'official_sha256' => $e->officialSha256,
            'location' => [
                'status' => $e->locationStatus->value,
                'label' => $e->locationStatus->label(),
                'latitude' => $e->latitude,
                'longitude' => $e->longitude,
                'accuracy_m' => $e->accuracyM,
                'altitude_m' => $e->altitudeM,
                'heading_deg' => $e->headingDeg,
                'speed_mps' => $e->speedMps,
                'captured_at' => DateTimes::toApi($e->locationCapturedAt),
            ],
            // Hora del servidor (oficial) y hora del dispositivo (informativa).
            'captured_at' => DateTimes::toApi($e->capturedAt),
            'device_captured_at' => DateTimes::toApi($e->deviceCapturedAt),
            'captured_by' => $e->capturedByName,
            'status' => $e->status,
            'withdrawn' => $e->isActive() ? null : [
                'reason' => $e->withdrawnReason,
                'by' => $e->withdrawnByName,
                'at' => DateTimes::toApi($e->withdrawnAt),
            ],
        ];
    }
}
