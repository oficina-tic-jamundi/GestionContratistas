<?php

declare(strict_types=1);

namespace Sigcon\Http\Resources;

use Sigcon\Helpers\DateTimes;
use Sigcon\Models\Payment;

/** Representación pública de pagos. Nunca incluye ids internos. */
final class PaymentResources
{
    /** @return array<string, mixed> */
    public static function summary(Payment $p): array
    {
        return [
            'uuid' => $p->uuid,
            'number' => $p->number,
            'contract' => ['uuid' => $p->contractUuid, 'contract_number' => $p->contractNumber, 'contractor' => $p->contractorName],
            'report' => ['uuid' => $p->reportUuid, 'number' => $p->reportNumber],
            'period_start' => $p->periodStart->format('Y-m-d'),
            'period_end' => $p->periodEnd->format('Y-m-d'),
            'amount' => $p->amount,
            'status' => $p->status->value,
            'status_label' => $p->status->label(),
            'last_eligible' => $p->lastEligible,
            'created_at' => DateTimes::toApi($p->createdAt),
            'updated_at' => DateTimes::toApi($p->updatedAt),
        ];
    }

    /**
     * @param array<string, mixed> $detail resultado de PaymentService::detail()
     * @return array<string, mixed>
     */
    public static function detail(array $detail): array
    {
        /** @var Payment $p */
        $p = $detail['payment'];
        /** @var array{eligible: bool, results: list<array<string, mixed>>, trigger: string, evaluated_by: string, evaluated_at: \DateTimeImmutable}|null $evaluation */
        $evaluation = $detail['evaluation'];

        return self::summary($p) + [
            'notes' => $p->notes,
            'created_by' => $p->createdByName,
            'submitted_at' => DateTimes::toApi($p->submittedAt),
            'approved_by' => $p->approvedByName,
            'approved_at' => DateTimes::toApi($p->approvedAt),
            'payment_date' => $p->paymentDate?->format('Y-m-d'),
            'payment_reference' => $p->paymentReference,
            'paid_registered_by' => $p->paidRegisteredByName,
            'cancelled_reason' => $p->cancelledReason,
            'cancelled_at' => DateTimes::toApi($p->cancelledAt),
            'budget' => $detail['budget'],
            'evaluation' => $evaluation === null ? null : [
                'eligible' => $evaluation['eligible'],
                'results' => $evaluation['results'],
                'trigger' => $evaluation['trigger'],
                'evaluated_by' => $evaluation['evaluated_by'],
                'evaluated_at' => DateTimes::toApi($evaluation['evaluated_at']),
            ],
            'can' => $detail['can'],
        ];
    }
}
