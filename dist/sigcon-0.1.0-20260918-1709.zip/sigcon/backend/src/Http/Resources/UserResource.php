<?php

declare(strict_types=1);

namespace Sigcon\Http\Resources;

use Sigcon\Helpers\DateTimes;
use Sigcon\Models\User;

/**
 * Representación pública de un usuario. Nunca incluye el id interno ni el hash de la contraseña.
 */
final class UserResource
{
    /**
     * @param list<array{code: string, name: string}> $roles
     * @return array<string, mixed>
     */
    public static function toArray(User $user, array $roles): array
    {
        return [
            'uuid' => $user->uuid,
            'first_name' => $user->firstName,
            'last_name' => $user->lastName,
            'full_name' => $user->fullName(),
            'email' => $user->email,
            'phone' => $user->phone,
            'status' => $user->status->value,
            'status_label' => $user->status->label(),
            'must_change_password' => $user->mustChangePassword,
            'roles' => $roles,
            'department' => $user->departmentUuid === null ? null : [
                'uuid' => $user->departmentUuid,
                'code' => $user->departmentCode,
                'name' => $user->departmentName,
            ],
            'last_login_at' => DateTimes::toApi($user->lastLoginAt),
            'created_at' => DateTimes::toApi($user->createdAt),
            'updated_at' => DateTimes::toApi($user->updatedAt),
        ];
    }
}
