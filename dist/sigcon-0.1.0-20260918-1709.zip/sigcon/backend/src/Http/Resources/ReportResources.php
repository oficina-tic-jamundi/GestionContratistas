<?php

declare(strict_types=1);

namespace Sigcon\Http\Resources;

use Sigcon\Helpers\DateTimes;
use Sigcon\Models\Report;

/** Representación pública de informes. Nunca incluye ids internos. */
final class ReportResources
{
    /** @return array<string, mixed> */
    public static function summary(Report $r): array
    {
        return [
            'uuid' => $r->uuid,
            'number' => $r->number,
            'contract' => ['uuid' => $r->contractUuid, 'contract_number' => $r->contractNumber, 'contractor' => $r->contractorName],
            'period_start' => $r->periodStart->format('Y-m-d'),
            'period_end' => $r->periodEnd->format('Y-m-d'),
            'status' => $r->status->value,
            'status_label' => $r->status->label(),
            'current_version' => $r->currentVersion,
            'approved_version' => $r->approvedVersion,
            'approved_at' => DateTimes::toApi($r->approvedAt),
            'approved_by' => $r->approvedByName,
            'created_at' => DateTimes::toApi($r->createdAt),
            'updated_at' => DateTimes::toApi($r->updatedAt),
        ];
    }

    /**
     * @param array<string, mixed> $detail resultado de ReportService::detail()
     * @return array<string, mixed>
     */
    public static function detail(array $detail): array
    {
        /** @var Report $report */
        $report = $detail['report'];
        /** @var list<array{version: int, content_hash: string, submitted_by: string, submitted_at: \DateTimeImmutable, pdf_status: string, pdf_sha256: ?string, pdf_size_bytes: ?int, pdf_generated_at: ?\DateTimeImmutable}> $versions */
        $versions = $detail['versions'];
        /** @var list<array{uuid: string, version: int, decision: string, comment: ?string, reviewer: string, created_at: \DateTimeImmutable, observations: list<array{activity_uuid: ?string, activity_title: ?string, text: string}>}> $reviews */
        $reviews = $detail['reviews'];

        return self::summary($report) + [
            'summary' => $report->summary,
            'contractor_notes' => $report->contractorNotes,
            'supervisor' => $detail['contract']->supervisorName,
            'can' => $detail['can'],
            'content' => $detail['content'],
            'versions' => array_map(static fn (array $v) => [
                'version' => $v['version'],
                'content_hash' => $v['content_hash'],
                'submitted_by' => $v['submitted_by'],
                'submitted_at' => DateTimes::toApi($v['submitted_at']),
                // Estado del PDF, independiente del estado del informe (§89).
                'pdf' => [
                    'status' => $v['pdf_status'],
                    'sha256' => $v['pdf_sha256'],
                    'size_bytes' => $v['pdf_size_bytes'],
                    'generated_at' => DateTimes::toApi($v['pdf_generated_at']),
                ],
            ], $versions),
            'reviews' => array_map(static fn (array $r) => [
                'uuid' => $r['uuid'],
                'version' => $r['version'],
                'decision' => $r['decision'],
                'comment' => $r['comment'],
                'reviewer' => $r['reviewer'],
                'created_at' => DateTimes::toApi($r['created_at']),
                'observations' => $r['observations'],
            ], $reviews),
        ];
    }
}
