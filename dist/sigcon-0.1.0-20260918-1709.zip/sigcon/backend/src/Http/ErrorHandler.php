<?php

declare(strict_types=1);

namespace Sigcon\Http;

use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Log\LoggerInterface;
use Sigcon\Exceptions\AppException;
use Sigcon\Exceptions\RateLimitException;
use Sigcon\Middleware\RequestContextMiddleware;
use Slim\Exception\HttpException;
use Slim\Exception\HttpMethodNotAllowedException;
use Slim\Exception\HttpNotFoundException;
use Throwable;

/**
 * Convierte cualquier excepción en una respuesta JSON estándar.
 *
 * - Errores controlados (AppException): mensaje público + errores por campo.
 * - Errores HTTP de Slim (404/405): mensaje genérico.
 * - Cualquier otro error: 500 genérico. Los detalles técnicos van SOLO al log,
 *   nunca a la respuesta, sin importar el entorno.
 */
final class ErrorHandler
{
    public function __construct(
        private readonly ResponseFactoryInterface $responseFactory,
        private readonly JsonResponder $responder,
        private readonly LoggerInterface $logger,
    ) {
    }

    public function __invoke(
        ServerRequestInterface $request,
        Throwable $exception,
        bool $displayErrorDetails,
        bool $logErrors,
        bool $logErrorDetails,
    ): ResponseInterface {
        $requestId = $request->getAttribute(RequestContextMiddleware::ATTRIBUTE);
        $meta = is_string($requestId) ? ['request_id' => $requestId] : [];
        $response = $this->responseFactory->createResponse();

        if ($exception instanceof AppException) {
            $this->logger->info('Error controlado', $this->context($request, $exception, $meta) + [
                'error_code' => $exception->errorCode(),
            ]);

            $response = $this->responder->error(
                $response,
                $exception->publicMessage(),
                $exception->statusCode(),
                $exception->errorCode(),
                $exception->errors(),
                $meta,
            );

            return $exception instanceof RateLimitException
                ? $response->withHeader('Retry-After', (string) $exception->retryAfterSeconds())
                : $response;
        }

        if ($exception instanceof HttpNotFoundException) {
            return $this->responder->error($response, 'El recurso solicitado no existe.', 404, 'not_found', [], $meta);
        }

        if ($exception instanceof HttpMethodNotAllowedException) {
            return $this->responder
                ->error($response, 'Método no permitido para este recurso.', 405, 'method_not_allowed', [], $meta)
                ->withHeader('Allow', implode(', ', $exception->getAllowedMethods()));
        }

        if ($exception instanceof HttpException && $exception->getCode() >= 400 && $exception->getCode() < 500) {
            return $this->responder->error($response, 'Solicitud no válida.', $exception->getCode(), 'bad_request', [], $meta);
        }

        $this->logger->error('Error no controlado', $this->context($request, $exception, $meta) + [
            'exception' => $exception,
        ]);

        return $this->responder->error(
            $response,
            'No fue posible procesar la solicitud. Si el problema persiste, contacte al administrador indicando el código de referencia.',
            500,
            'internal_error',
            [],
            $meta,
        );
    }

    /**
     * @param array<string, mixed> $meta
     * @return array<string, mixed>
     */
    private function context(ServerRequestInterface $request, Throwable $exception, array $meta): array
    {
        return $meta + [
            'method' => $request->getMethod(),
            'path' => $request->getUri()->getPath(),
            'exception_class' => $exception::class,
            'message' => $exception->getMessage(),
        ];
    }
}
