<?php

declare(strict_types=1);

namespace Sigcon\Http;

/**
 * Resultado paginado.
 *
 * @template T
 */
final class Page
{
    /**
     * @param list<T> $items
     */
    public function __construct(
        public readonly array $items,
        public readonly int $total,
        public readonly PageRequest $request,
    ) {
    }

    /**
     * @template U
     * @param callable(T): U $mapper
     * @return list<U>
     */
    public function map(callable $mapper): array
    {
        return array_map($mapper, $this->items);
    }

    /** @return array{pagination: array{page: int, per_page: int, total: int, total_pages: int}} */
    public function meta(): array
    {
        return ['pagination' => [
            'page' => $this->request->page,
            'per_page' => $this->request->perPage,
            'total' => $this->total,
            'total_pages' => (int) max(1, ceil($this->total / $this->request->perPage)),
        ]];
    }
}
