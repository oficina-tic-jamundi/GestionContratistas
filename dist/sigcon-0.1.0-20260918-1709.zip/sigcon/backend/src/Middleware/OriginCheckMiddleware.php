<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Log\LoggerInterface;
use Sigcon\Config\Settings;
use Sigcon\Exceptions\SecurityCheckException;
use Sigcon\Logging\LogChannel;
use Sigcon\Logging\LoggerFactory;

/**
 * Defensa CSRF en profundidad para TODAS las peticiones que modifican datos (incluido el login):
 * si el navegador declara un origen distinto al de la aplicación, la petición se rechaza.
 *
 * Los navegadores siempre envían Origin en peticiones POST/PUT/PATCH/DELETE hechas con fetch.
 * Clientes sin navegador (scripts, cron) no lo envían y no están expuestos a CSRF.
 */
final class OriginCheckMiddleware implements MiddlewareInterface
{
    private const SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS'];

    private readonly LoggerInterface $security;

    public function __construct(private readonly Settings $settings, LoggerFactory $loggers)
    {
        $this->security = $loggers->channel(LogChannel::Security);
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        if (!in_array($request->getMethod(), self::SAFE_METHODS, true)) {
            $origin = strtolower($request->getHeaderLine('Origin'));
            $fetchSite = strtolower($request->getHeaderLine('Sec-Fetch-Site'));

            if (($origin !== '' && $origin !== $this->settings->security->allowedOrigin) || $fetchSite === 'cross-site') {
                $this->security->warning('Petición rechazada por origen no permitido', [
                    'origin' => $origin,
                    'sec_fetch_site' => $fetchSite,
                    'path' => $request->getUri()->getPath(),
                ]);
                throw new SecurityCheckException('Origen de la solicitud no permitido.', SecurityCheckException::ORIGIN_NOT_ALLOWED);
            }
        }

        return $handler->handle($request);
    }
}
