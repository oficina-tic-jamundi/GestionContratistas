<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Sigcon\Exceptions\AuthorizationException;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;

/**
 * Exige AL MENOS UNO de los permisos. Se usa en recursos con alcance por perfil
 * (ej. contratos: todos / asignados / propios); el servicio filtra según el permiso que tenga.
 */
final class AuthorizeAnyMiddleware implements MiddlewareInterface
{
    /** @var list<Permission> */
    private readonly array $permissions;

    public function __construct(private readonly AuthContext $auth, Permission ...$permissions)
    {
        $this->permissions = array_values($permissions);
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        foreach ($this->permissions as $permission) {
            if ($this->auth->can($permission)) {
                return $handler->handle($request);
            }
        }

        throw new AuthorizationException('No tiene permiso para realizar esta acción.');
    }
}
