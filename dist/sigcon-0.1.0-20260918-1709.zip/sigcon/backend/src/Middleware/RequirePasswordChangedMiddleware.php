<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Sigcon\Exceptions\SecurityCheckException;
use Sigcon\Security\AuthContext;

/**
 * Un usuario con contraseña temporal solo puede consultar su perfil, cambiar la contraseña
 * y cerrar sesión. Se aplica a todas las rutas protegidas salvo /auth/*.
 */
final class RequirePasswordChangedMiddleware implements MiddlewareInterface
{
    public function __construct(private readonly AuthContext $auth)
    {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        if ($this->auth->user()->mustChangePassword) {
            throw new SecurityCheckException(
                'Debe cambiar su contraseña temporal antes de continuar.',
                SecurityCheckException::PASSWORD_CHANGE_REQUIRED,
            );
        }

        return $handler->handle($request);
    }
}
