<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;

/**
 * Exige uno o más permisos para una ruta. Se declara en routes/api.php junto a cada ruta,
 * de modo que la matriz de permisos es visible en un solo archivo.
 *
 * Verifica el PERMISO. El ALCANCE (si un contrato pertenece al usuario) lo verifican los servicios.
 */
final class AuthorizeMiddleware implements MiddlewareInterface
{
    /** @var list<Permission> */
    private readonly array $permissions;

    public function __construct(private readonly AuthContext $auth, Permission ...$permissions)
    {
        $this->permissions = array_values($permissions);
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $this->auth->require(...$this->permissions);

        return $handler->handle($request);
    }
}
