<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Sigcon\Logging\RequestContext;

/**
 * Inicia el contexto de la solicitud: identificador único, IP y user agent.
 *
 * El ID se devuelve en la cabecera X-Request-Id y en los errores, y se adjunta a logs y
 * auditoría, para que un usuario pueda reportar un problema con un código rastreable.
 *
 * La IP es REMOTE_ADDR. No se confía en X-Forwarded-For: en cPanel la conexión llega directa
 * a Apache. Si en el futuro se usa un proxy (ej. Cloudflare) se configurará explícitamente.
 */
final class RequestContextMiddleware implements MiddlewareInterface
{
    public const ATTRIBUTE = 'request_id';
    public const HEADER = 'X-Request-Id';

    public function __construct(private readonly RequestContext $context)
    {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        // Se genera siempre en el servidor: no se confía en un ID enviado por el cliente.
        $requestId = bin2hex(random_bytes(8));
        $server = $request->getServerParams();
        $ip = isset($server['REMOTE_ADDR']) && is_string($server['REMOTE_ADDR'])
            && filter_var($server['REMOTE_ADDR'], FILTER_VALIDATE_IP) !== false ? $server['REMOTE_ADDR'] : null;
        $userAgent = $request->getHeaderLine('User-Agent');

        $this->context->start($requestId, $ip, $userAgent === '' ? null : $userAgent);

        $response = $handler->handle($request->withAttribute(self::ATTRIBUTE, $requestId));

        return $response->withHeader(self::HEADER, $requestId);
    }
}
