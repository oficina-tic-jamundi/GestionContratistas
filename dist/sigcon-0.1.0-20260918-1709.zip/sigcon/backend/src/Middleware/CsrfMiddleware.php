<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Sigcon\Exceptions\SecurityCheckException;
use Sigcon\Security\AuthContext;
use Sigcon\Security\CsrfTokens;

/**
 * Exige la cabecera X-CSRF-Token válida en peticiones autenticadas que modifican datos.
 * Debe ejecutarse DESPUÉS de AuthenticateMiddleware.
 */
final class CsrfMiddleware implements MiddlewareInterface
{
    private const SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS'];

    public function __construct(
        private readonly CsrfTokens $csrf,
        private readonly AuthContext $auth,
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        if (!in_array($request->getMethod(), self::SAFE_METHODS, true)
            && !$this->csrf->isValid($this->auth->sessionToken(), $request->getHeaderLine(CsrfTokens::HEADER))) {
            throw new SecurityCheckException(
                'No fue posible verificar la solicitud. Recargue la página e intente nuevamente.',
                SecurityCheckException::CSRF_INVALID,
            );
        }

        return $handler->handle($request);
    }
}
