<?php

declare(strict_types=1);

namespace Sigcon\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Sigcon\Exceptions\AuthenticationException;
use Sigcon\Repositories\UserRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\SessionCookie;
use Sigcon\Services\Auth\SessionService;

/**
 * Exige una sesión válida y carga el usuario, sus roles y permisos en AuthContext.
 * Los permisos se leen en cada petición: un cambio de roles aplica de inmediato.
 */
final class AuthenticateMiddleware implements MiddlewareInterface
{
    public const SESSION_EXPIRED = 'Su sesión expiró o no es válida. Inicie sesión nuevamente.';

    public function __construct(
        private readonly SessionCookie $cookie,
        private readonly SessionService $sessions,
        private readonly UserRepository $users,
        private readonly AuthContext $auth,
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $token = $this->cookie->read($request) ?? throw new AuthenticationException('Debe iniciar sesión.');
        $session = $this->sessions->resolve($token) ?? throw new AuthenticationException(self::SESSION_EXPIRED);

        $user = $this->users->findById($session->userId);
        if ($user === null || !$user->isActive()) {
            $this->sessions->revoke($session, 'user_inactive');
            throw new AuthenticationException(self::SESSION_EXPIRED);
        }

        $this->auth->authenticate(
            $user,
            $session,
            $token,
            array_column($this->users->rolesFor($user->id), 'code'),
            $this->users->permissionsFor($user->id),
        );

        return $handler->handle($request);
    }
}
