<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\ContractData;
use Sigcon\DTOs\ContractFilters;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Http\Resources\ContractResources;
use Sigcon\Models\Contract;
use Sigcon\Models\ContractStatus;
use Sigcon\Models\HistoryEntry;
use Sigcon\Models\User;
use Sigcon\Repositories\ContractRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Contracts\ContractService;
use Sigcon\Validators\Validator;

final class ContractController
{
    public function __construct(
        private readonly ContractService $contracts,
        private readonly AuthContext $auth,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $page = $this->contracts->list(
            ContractFilters::fromQuery($query),
            PageRequest::fromQuery($query, ContractRepository::SORTABLE, 'start_date', 'desc'),
        );

        return $this->responder->success($response, $page->map($this->present(...)), meta: $page->meta());
    }

    /** @param array{uuid: string} $args */
    public function show(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, $this->present($this->contracts->get($args['uuid'])));
    }

    /** @param array{uuid: string} $args */
    public function history(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, array_map(
            static fn (HistoryEntry $h) => ContractResources::history($h),
            $this->contracts->history($args['uuid']),
        ));
    }

    public function store(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $contract = $this->contracts->create(ContractData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, $this->present($contract), 'Contrato registrado en borrador.', 201);
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $contract = $this->contracts->update($args['uuid'], ContractData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, $this->present($contract), 'Borrador actualizado.');
    }

    /** @param array{uuid: string} $args */
    public function transition(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $status = $v->enum('status', ContractStatus::class);
        $comment = $v->string('comment', 2000, required: false);
        $v->throwIfInvalid();

        $contract = $this->contracts->transition($args['uuid'], Validator::present($status), $comment);

        return $this->responder->success($response, $this->present($contract), sprintf('Estado del contrato: %s.', $contract->status->label()));
    }

    /** @param array{uuid: string} $args */
    public function changeSupervisor(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $supervisor = $v->uuid('supervisor');
        $comment = $v->string('comment', 2000, required: false);
        $v->throwIfInvalid();

        $contract = $this->contracts->changeSupervisor($args['uuid'], Validator::present($supervisor), $comment);

        return $this->responder->success($response, $this->present($contract), 'Supervisor actualizado.');
    }

    /** @param array{uuid: string} $args */
    public function destroy(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $this->contracts->deleteDraft($args['uuid']);

        return $this->responder->success($response, null, 'Borrador descartado.');
    }

    public function supervisors(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, array_map(
            static fn (User $u) => ContractResources::supervisor($u),
            $this->contracts->supervisorCandidates(),
        ));
    }

    /** @return array<string, mixed> */
    private function present(Contract $contract): array
    {
        return ContractResources::contract($contract, $this->auth->can(Permission::ContractsManage));
    }
}
