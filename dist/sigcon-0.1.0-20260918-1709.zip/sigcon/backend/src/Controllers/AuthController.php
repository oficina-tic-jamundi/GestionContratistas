<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\Resources\UserResource;
use Sigcon\Security\AuthContext;
use Sigcon\Security\CsrfTokens;
use Sigcon\Security\SessionCookie;
use Sigcon\Services\Auth\AuthService;
use Sigcon\Validators\Validator;

final class AuthController
{
    public function __construct(
        private readonly AuthService $authService,
        private readonly AuthContext $auth,
        private readonly SessionCookie $cookie,
        private readonly CsrfTokens $csrf,
        private readonly JsonResponder $responder,
    ) {
    }

    public function login(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $email = $v->string('email', 191);
        $password = $v->password('password');
        $v->throwIfInvalid();

        $result = $this->authService->login(Validator::present($email), Validator::present($password));

        return $this->cookie->attach(
            $this->responder->success($response, $this->profile($result->user->id, $result->sessionToken), 'Sesión iniciada.'),
            $result->sessionToken,
        );
    }

    public function me(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, $this->profile($this->auth->user()->id, $this->auth->sessionToken()));
    }

    public function logout(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $this->authService->logout();

        return $this->cookie->clear($this->responder->success($response, null, 'Sesión cerrada.'));
    }

    public function changePassword(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $current = $v->password('current_password');
        $new = $v->password('new_password');
        $v->throwIfInvalid();

        $result = $this->authService->changePassword(Validator::present($current), Validator::present($new));

        return $this->cookie->attach(
            $this->responder->success($response, $this->profile($result->user->id, $result->sessionToken), 'Contraseña actualizada.'),
            $result->sessionToken,
        );
    }

    /** @return array<string, mixed> */
    private function profile(int $userId, string $sessionToken): array
    {
        $access = $this->authService->accessOf($userId);

        return [
            'user' => UserResource::toArray($access['user'], $access['roles']),
            'permissions' => $access['permissions'],
            'csrf_token' => $this->csrf->forSession($sessionToken),
        ];
    }
}
