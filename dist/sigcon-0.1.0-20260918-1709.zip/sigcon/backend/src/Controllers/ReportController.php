<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Http\Resources\ContractResources;
use Sigcon\Http\Resources\ReportResources;
use Sigcon\Models\HistoryEntry;
use Sigcon\Models\Report;
use Sigcon\Models\ReportStatus;
use Sigcon\Repositories\ReportRepository;
use Sigcon\Services\Reports\ReportService;
use Sigcon\Validators\Validator;

final class ReportController
{
    private const MAX_ITEM_TEXT = 5000;
    private const MAX_OBSERVATIONS = 50;

    public function __construct(
        private readonly ReportService $reports,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $status = is_string($query['status'] ?? null) ? $query['status'] : '';
        // "pending_review": todo lo que espera una acción del supervisor.
        $statuses = $status === 'pending_review'
            ? [ReportStatus::Submitted, ReportStatus::Resubmitted, ReportStatus::InReview]
            : (ReportStatus::tryFrom($status) === null ? [] : [ReportStatus::from($status)]);
        $contract = is_string($query['contract'] ?? null) && Uuid::isValid($query['contract']) ? $query['contract'] : null;
        $page = $this->reports->list($statuses, $contract, PageRequest::fromQuery($query, ReportRepository::SORTABLE, 'updated_at', 'desc'));

        return $this->responder->success($response, $page->map(static fn (Report $r) => ReportResources::summary($r)), meta: $page->meta());
    }

    /** @param array{uuid: string} $args */
    public function store(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $start = $v->date('period_start');
        $end = $v->date('period_end');
        if ($start !== null && $end !== null && $end < $start) {
            $v->add('period_end', 'before_start', 'La fecha final no puede ser anterior a la inicial.');
        }
        $v->throwIfInvalid();

        $report = $this->reports->create($args['uuid'], Validator::present($start), Validator::present($end));

        return $this->responder->success($response, ReportResources::summary($report), 'Informe creado en borrador.', 201);
    }

    /** @param array{uuid: string} $args */
    public function show(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, ReportResources::detail($this->reports->detail($args['uuid'])));
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $body = $request->getParsedBody();
        $v = Validator::fromBody($body);
        $summary = $v->string('summary', 10000, required: false);
        $notes = $v->string('contractor_notes', 5000, required: false);
        $items = [];
        $raw = is_array($body) ? ($body['items'] ?? []) : [];
        if (!is_array($raw) || !array_is_list($raw)) {
            $v->add('items', 'invalid_type', 'Debe ser una lista.');
        } else {
            foreach ($raw as $item) {
                $obligation = is_array($item) ? ($item['obligation'] ?? null) : null;
                $description = is_array($item) ? ($item['description'] ?? '') : null;
                if (!is_string($obligation) || !Uuid::isValid($obligation) || !is_string($description)) {
                    $v->add('items', 'invalid_value', 'Cada elemento debe indicar la obligación y la descripción.');
                    break;
                }
                if (mb_strlen($description) > self::MAX_ITEM_TEXT) {
                    $v->add('items', 'too_long', sprintf('Cada descripción admite hasta %d caracteres.', self::MAX_ITEM_TEXT));
                    break;
                }
                $items[$obligation] = $description;
            }
        }
        $v->throwIfInvalid();

        $report = $this->reports->updateContent($args['uuid'], $summary, $notes, $items);

        return $this->responder->success($response, ReportResources::summary($report), 'Informe guardado.');
    }

    /** @param array{uuid: string} $args */
    public function submit(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $report = $this->reports->submit($args['uuid']);

        return $this->responder->success($response, ReportResources::summary($report), sprintf('Informe enviado al supervisor (versión %d).', $report->currentVersion));
    }

    /** @param array{uuid: string} $args */
    public function startReview(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, ReportResources::summary($this->reports->startReview($args['uuid'])), 'Revisión iniciada.');
    }

    /** @param array{uuid: string} $args */
    public function observe(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $body = $request->getParsedBody();
        $v = Validator::fromBody($body);
        $comment = $v->string('comment', 5000, required: false);
        $observations = [];
        $raw = is_array($body) ? ($body['observations'] ?? []) : [];
        if (!is_array($raw) || !array_is_list($raw) || count($raw) > self::MAX_OBSERVATIONS) {
            $v->add('observations', 'invalid_type', sprintf('Debe ser una lista de hasta %d observaciones.', self::MAX_OBSERVATIONS));
        } else {
            foreach ($raw as $item) {
                $obligation = is_array($item) ? ($item['obligation'] ?? null) : null;
                $text = is_array($item) && is_string($item['text'] ?? null) ? trim($item['text']) : '';
                if (($obligation !== null && (!is_string($obligation) || !Uuid::isValid($obligation))) || $text === '' || mb_strlen($text) > self::MAX_ITEM_TEXT) {
                    $v->add('observations', 'invalid_value', 'Cada observación necesita un texto (y, si aplica, una obligación válida).');
                    break;
                }
                $observations[] = ['activity' => $obligation, 'text' => $text];
            }
        }
        $v->throwIfInvalid();

        return $this->responder->success($response, ReportResources::summary($this->reports->observe($args['uuid'], $comment, $observations)), 'Observaciones enviadas al contratista.');
    }

    /** @param array{uuid: string} $args */
    public function approve(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $comment = $v->string('comment', 5000, required: false);
        $v->throwIfInvalid();

        return $this->responder->success($response, ReportResources::summary($this->reports->approve($args['uuid'], $comment)), 'Informe aprobado.');
    }

    /** @param array{uuid: string} $args */
    public function reject(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $comment = $v->string('comment', 5000, 10);
        $v->throwIfInvalid();

        return $this->responder->success($response, ReportResources::summary($this->reports->reject($args['uuid'], Validator::present($comment))), 'Informe rechazado.');
    }

    /** @param array{uuid: string} $args */
    public function reopen(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $reason = $v->string('reason', 2000, 10);
        $v->throwIfInvalid();

        return $this->responder->success($response, ReportResources::summary($this->reports->reopen($args['uuid'], Validator::present($reason))), 'Informe reabierto.');
    }

    /** @param array{uuid: string, version: string} $args */
    public function version(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $version = ctype_digit($args['version']) ? (int) $args['version'] : 0;
        if ($version < 1) {
            throw ValidationException::field('version', 'invalid', 'Versión inválida.');
        }

        return $this->responder->success($response, $this->reports->version($args['uuid'], $version) + [
            'version' => $version,
            'changes' => $this->reports->changes($args['uuid'], $version),
        ]);
    }

    /** @param array{uuid: string, version: string} $args */
    public function pdf(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $version = ctype_digit($args['version']) ? (int) $args['version'] : 0;
        if ($version < 1) {
            throw ValidationException::field('version', 'invalid', 'Versión inválida.');
        }
        $pdf = $this->reports->pdf($args['uuid'], $version);

        return $response
            ->withBody($pdf['stream'])
            ->withHeader('Content-Type', 'application/pdf')
            ->withHeader('Content-Length', (string) $pdf['size'])
            ->withHeader('Content-Disposition', DocumentController::disposition('attachment', $pdf['name']))
            ->withHeader('Cache-Control', 'private, no-store')
            ->withHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'; sandbox")
            ->withHeader('X-Content-Type-Options', 'nosniff');
    }

    /** @param array{uuid: string} $args */
    public function history(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, array_map(
            static fn (HistoryEntry $h) => ContractResources::history($h),
            $this->reports->history($args['uuid']),
        ));
    }
}
