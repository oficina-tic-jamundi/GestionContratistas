<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Http\JsonResponder;
use Sigcon\Services\HealthService;

final class HealthController
{
    public function __construct(
        private readonly HealthService $health,
        private readonly JsonResponder $responder,
    ) {
    }

    public function show(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $result = $this->health->check();

        // 503 cuando está degradado, para que un monitor externo lo detecte.
        return $this->responder->success($response, $result, status: $result['status'] === 'ok' ? 200 : 503);
    }
}
