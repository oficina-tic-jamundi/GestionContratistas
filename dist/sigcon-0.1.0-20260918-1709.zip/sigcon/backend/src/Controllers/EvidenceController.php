<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use DateTimeImmutable;
use DateTimeZone;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UploadedFileInterface;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\Resources\EvidenceResources;
use Sigcon\Models\Evidence;
use Sigcon\Models\LocationStatus;
use Sigcon\Services\Evidence\CaptureLocation;
use Sigcon\Services\Evidence\EvidenceService;
use Sigcon\Validators\Validator;

final class EvidenceController
{
    private const ISO_DATETIME = '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?(Z|[+-]\d{2}:\d{2})$/';

    public function __construct(
        private readonly EvidenceService $evidences,
        private readonly JsonResponder $responder,
    ) {
    }

    /** @param array{uuid: string} $args */
    public function index(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $activity = $request->getQueryParams()['activity'] ?? null;
        $result = $this->evidences->forContract($args['uuid'], is_string($activity) && $activity !== '' ? $activity : null);

        return $this->responder->success($response, [
            'can_capture' => $result['can_capture'],
            'can_view_original' => $result['can_view_original'],
            'max_mb' => $result['max_mb'],
            'items' => array_map(
                static fn (Evidence $e) => EvidenceResources::evidence($e) + ['can_withdraw' => in_array($e->uuid, $result['withdrawable'], true)],
                $result['evidences'],
            ),
        ]);
    }

    /** @param array{uuid: string} $args */
    public function store(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $body = $request->getParsedBody();
        $data = is_array($body) ? $body : [];
        $v = Validator::fromBody($data);
        $description = $v->string('description', 500, required: false);
        $location = $this->location($data, $v);
        $deviceTime = $this->dateTime($data, 'device_captured_at', $v);
        $v->throwIfInvalid();

        $photo = $request->getUploadedFiles()['photo'] ?? null;
        $evidence = $this->evidences->capture(
            $args['uuid'],
            $photo instanceof UploadedFileInterface ? $photo : null,
            $description,
            Validator::present($location),
            $deviceTime,
        );

        return $this->responder->success($response, EvidenceResources::evidence($evidence), 'Evidencia registrada.', 201);
    }

    /** @param array{uuid: string} $args */
    public function image(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $variant = $request->getQueryParams()['variant'] ?? 'official';
        if (!is_string($variant) || !in_array($variant, EvidenceService::VARIANTS, true)) {
            throw ValidationException::field('variant', 'invalid', 'Variante no válida (official, thumbnail u original).');
        }
        $result = $this->evidences->image($args['uuid'], $variant);
        $download = ($request->getQueryParams()['download'] ?? '') === '1';
        $extension = $variant === 'original' ? (string) (explode('/', $result['mime'])[1] ?? 'jpg') : 'jpg';
        $name = sprintf('evidencia-%s%s.%s', substr($result['evidence']->uuid, 0, 8), $variant === 'original' ? '-original' : '', $extension === 'jpeg' ? 'jpg' : $extension);

        return $response
            ->withBody($result['stream'])
            ->withHeader('Content-Type', $result['mime'])
            ->withHeader('Content-Disposition', DocumentController::disposition($download ? 'attachment' : 'inline', $name))
            // Las imágenes de una evidencia no cambian (uuid inmutable); el original no se guarda en caché.
            ->withHeader('Cache-Control', $variant === 'original' ? 'private, no-store' : 'private, max-age=600')
            ->withHeader('Content-Security-Policy', "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; frame-ancestors 'none'; sandbox")
            ->withHeader('X-Content-Type-Options', 'nosniff');
    }

    /** @param array{uuid: string} $args */
    public function withdraw(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $reason = $v->string('reason', 500, 5);
        $v->throwIfInvalid();

        $evidence = $this->evidences->withdraw($args['uuid'], Validator::present($reason));

        return $this->responder->success($response, EvidenceResources::evidence($evidence), 'Evidencia retirada.');
    }

    /**
     * Ubicación reportada por el dispositivo. Con `location_status=ok` las coordenadas son
     * obligatorias; con un estado de falla no se aceptan coordenadas (nunca se inventan).
     *
     * @param array<string, mixed> $data
     */
    private function location(array $data, Validator $v): ?CaptureLocation
    {
        $status = $v->enum('location_status', LocationStatus::class);
        if (!$status instanceof LocationStatus) {
            return null;
        }
        if ($status === LocationStatus::LowAccuracy) {
            $v->add('location_status', 'invalid', 'Envíe "ok" con las coordenadas; el servidor determina la precisión.');

            return null;
        }
        $fields = ['latitude', 'longitude', 'accuracy', 'altitude', 'heading', 'speed'];
        if ($status !== LocationStatus::Ok) {
            foreach ($fields as $field) {
                if (($data[$field] ?? '') !== '' && ($data[$field] ?? null) !== null) {
                    $v->add($field, 'unexpected', 'No se envían coordenadas cuando la ubicación no está disponible.');
                }
            }

            return new CaptureLocation($status);
        }

        $latitude = $this->number($data, 'latitude', -90, 90, true, $v);
        $longitude = $this->number($data, 'longitude', -180, 180, true, $v);
        $accuracy = $this->number($data, 'accuracy', 0, 100000, true, $v);
        $altitude = $this->number($data, 'altitude', -500, 9000, false, $v);
        $heading = $this->number($data, 'heading', 0, 360, false, $v);
        $speed = $this->number($data, 'speed', 0, 1000, false, $v);
        $capturedAt = $this->dateTime($data, 'location_captured_at', $v);
        if ($accuracy !== null && $accuracy <= 0) {
            $v->add('accuracy', 'out_of_range', 'La precisión debe ser mayor que cero.');
        }

        return new CaptureLocation($status, $latitude, $longitude, $accuracy, $altitude, $heading, $speed, $capturedAt);
    }

    /** @param array<string, mixed> $data */
    private function number(array $data, string $field, float $min, float $max, bool $required, Validator $v): ?float
    {
        $value = $data[$field] ?? null;
        if ($value === null || $value === '') {
            if ($required) {
                $v->add($field, 'required', 'Este campo es obligatorio.');
            }

            return null;
        }
        if (!is_numeric($value)) {
            $v->add($field, 'invalid', 'Debe ser un número.');

            return null;
        }
        $number = (float) $value;
        if (!is_finite($number) || $number < $min || $number > $max) {
            $v->add($field, 'out_of_range', sprintf('Debe estar entre %s y %s.', $min, $max));

            return null;
        }

        return $number;
    }

    /** @param array<string, mixed> $data */
    private function dateTime(array $data, string $field, Validator $v): ?DateTimeImmutable
    {
        $value = $data[$field] ?? null;
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_string($value) || preg_match(self::ISO_DATETIME, $value) !== 1) {
            $v->add($field, 'invalid', 'Fecha y hora en formato ISO 8601 con zona horaria.');

            return null;
        }
        try {
            return (new DateTimeImmutable($value))->setTimezone(new DateTimeZone('UTC'));
        } catch (\Exception) {
            $v->add($field, 'invalid', 'Fecha y hora no válida.');

            return null;
        }
    }
}
