<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Helpers\DateTimes;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Http\Resources\ContractResources;
use Sigcon\Http\Resources\PaymentResources;
use Sigcon\Models\HistoryEntry;
use Sigcon\Models\Payment;
use Sigcon\Models\PaymentStatus;
use Sigcon\Repositories\PaymentRepository;
use Sigcon\Services\Contracts\ContractService;
use Sigcon\Services\Payments\PaymentEligibilityService;
use Sigcon\Services\Payments\PaymentService;
use Sigcon\Validators\Validator;

final class PaymentController
{
    public function __construct(
        private readonly PaymentService $payments,
        private readonly PaymentEligibilityService $eligibility,
        private readonly ContractService $contracts,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $status = PaymentStatus::tryFrom(is_string($query['status'] ?? null) ? $query['status'] : '');
        $contract = is_string($query['contract'] ?? null) && Uuid::isValid($query['contract']) ? $query['contract'] : null;
        $page = $this->payments->list($status, $contract, PageRequest::fromQuery($query, PaymentRepository::SORTABLE, 'updated_at', 'desc'));

        return $this->responder->success($response, $page->map(static fn (Payment $p) => PaymentResources::summary($p)), meta: $page->meta());
    }

    /**
     * Valor, comprometido, pagado y disponible del contrato.
     *
     * @param array{uuid: string} $args
     */
    public function budget(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, $this->payments->budget($this->contracts->get($args['uuid'])));
    }

    public function store(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $report = $v->uuid('report');
        $amount = $v->money('amount');
        $notes = $v->string('notes', 1000, required: false);
        $v->throwIfInvalid();

        $payment = $this->payments->create(Validator::present($report), Validator::present($amount), $notes);

        return $this->responder->success($response, PaymentResources::summary($payment), sprintf('Pago N.° %d registrado.', $payment->number), 201);
    }

    /** @param array{uuid: string} $args */
    public function show(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, PaymentResources::detail($this->payments->detail($args['uuid'])));
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $amount = $v->money('amount');
        $notes = $v->string('notes', 1000, required: false);
        $v->throwIfInvalid();

        return $this->responder->success($response, PaymentResources::summary($this->payments->update($args['uuid'], Validator::present($amount), $notes)), 'Pago actualizado.');
    }

    /** @param array{uuid: string} $args */
    public function evaluate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $result = $this->payments->evaluate($args['uuid']);

        return $this->responder->success($response, $result, $result['eligible'] ? 'El pago es elegible.' : 'El pago no es elegible todavía.');
    }

    /** @param array{uuid: string} $args */
    public function submit(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, PaymentResources::summary($this->payments->submit($args['uuid'])), 'Pago enviado a aprobación.');
    }

    /** @param array{uuid: string} $args */
    public function approve(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, PaymentResources::summary($this->payments->approve($args['uuid'])), 'Pago aprobado.');
    }

    /** @param array{uuid: string} $args */
    public function returnToDraft(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $reason = $v->string('reason', 1000, 10);
        $v->throwIfInvalid();

        return $this->responder->success($response, PaymentResources::summary($this->payments->returnToDraft($args['uuid'], Validator::present($reason))), 'Pago devuelto para ajustes.');
    }

    /** @param array{uuid: string} $args */
    public function registerPaid(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $date = $v->date('payment_date');
        $reference = $v->string('payment_reference', 100, 3);
        $v->throwIfInvalid();

        return $this->responder->success($response, PaymentResources::summary($this->payments->registerPaid($args['uuid'], Validator::present($date), Validator::present($reference))), 'Pago registrado como pagado.');
    }

    /** @param array{uuid: string} $args */
    public function cancel(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $reason = $v->string('reason', 1000, 10);
        $v->throwIfInvalid();

        return $this->responder->success($response, PaymentResources::summary($this->payments->cancel($args['uuid'], Validator::present($reason))), 'Pago anulado.');
    }

    /** @param array{uuid: string} $args */
    public function history(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, array_map(
            static fn (HistoryEntry $h) => ContractResources::history($h),
            $this->payments->history($args['uuid']),
        ));
    }

    public function rules(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, array_map(static function (array $rule): array {
            $rule['updated_at'] = $rule['updated_at'] instanceof \DateTimeImmutable ? DateTimes::toApi($rule['updated_at']) : null;

            return $rule;
        }, $this->eligibility->rules()));
    }

    /** @param array{code: string} $args */
    public function configureRule(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $body = $request->getParsedBody();
        $data = is_array($body) ? $body : [];
        $v = Validator::fromBody($data);
        if (!is_bool($data['enabled'] ?? null)) {
            $v->add('enabled', 'required', 'Indique si la regla está activa.');
        }
        $params = $data['params'] ?? [];
        if (!is_array($params)) {
            $v->add('params', 'invalid_type', 'Los parámetros deben ser un objeto.');
        }
        $v->throwIfInvalid();

        $this->eligibility->configure($args['code'], (bool) $data['enabled'], is_array($params) ? $params : []);

        return $this->responder->success($response, null, 'Regla actualizada.');
    }
}
