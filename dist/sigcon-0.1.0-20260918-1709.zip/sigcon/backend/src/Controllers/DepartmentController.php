<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\DepartmentData;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\Resources\ContractResources;
use Sigcon\Models\ActiveStatus;
use Sigcon\Models\Department;
use Sigcon\Services\Departments\DepartmentService;
use Sigcon\Validators\Validator;

final class DepartmentController
{
    public function __construct(
        private readonly DepartmentService $departments,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $v = new Validator($request->getQueryParams());
        $status = $v->enum('status', ActiveStatus::class, required: false);
        $v->throwIfInvalid();

        return $this->responder->success($response, array_map(
            static fn (Department $d) => ContractResources::department($d),
            $this->departments->list($status instanceof ActiveStatus ? $status : null),
        ));
    }

    public function store(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $department = $this->departments->create(DepartmentData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, ContractResources::department($department), 'Dependencia creada.', 201);
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $department = $this->departments->update($args['uuid'], DepartmentData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, ContractResources::department($department), 'Dependencia actualizada.');
    }

    /** @param array{uuid: string} $args */
    public function activate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, ContractResources::department($this->departments->setActive($args['uuid'], true)), 'Dependencia activada.');
    }

    /** @param array{uuid: string} $args */
    public function deactivate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success(
            $response,
            ContractResources::department($this->departments->setActive($args['uuid'], false)),
            'Dependencia desactivada. No podrá asignarse a contratos ni usuarios nuevos.',
        );
    }
}
