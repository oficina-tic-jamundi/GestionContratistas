<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Http\JsonResponder;
use Sigcon\Models\PaymentStatus;
use Sigcon\Services\Dashboard\DashboardService;
use Sigcon\Services\Exports\ExportService;

final class DashboardController
{
    public function __construct(
        private readonly DashboardService $dashboard,
        private readonly ExportService $exports,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, $this->dashboard->build());
    }

    public function exportContracts(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->csv($response, $this->exports->contracts());
    }

    public function exportPayments(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $status = $request->getQueryParams()['status'] ?? null;

        return $this->csv($response, $this->exports->payments(PaymentStatus::tryFrom(is_string($status) ? $status : '')));
    }

    /** @param array{name: string, content: string} $file */
    private function csv(ResponseInterface $response, array $file): ResponseInterface
    {
        $response->getBody()->write($file['content']);

        return $response
            ->withHeader('Content-Type', 'text/csv; charset=utf-8')
            ->withHeader('Content-Disposition', DocumentController::disposition('attachment', $file['name']))
            ->withHeader('Cache-Control', 'private, no-store')
            ->withHeader('X-Content-Type-Options', 'nosniff');
    }
}
