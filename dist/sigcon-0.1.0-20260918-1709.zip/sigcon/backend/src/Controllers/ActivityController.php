<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\ActivityData;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\JsonResponder;
use Sigcon\Models\Activity;
use Sigcon\Services\Activities\ActivityService;
use Sigcon\Validators\Validator;

final class ActivityController
{
    public function __construct(
        private readonly ActivityService $activities,
        private readonly JsonResponder $responder,
    ) {
    }

    /** @param array{uuid: string} $args */
    public function tree(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $tree = $this->activities->tree($args['uuid']);

        return $this->responder->success($response, [
            'progress' => $tree['progress'],
            'can' => $tree['can'],
            'items' => $this->nest($tree['activities']),
        ]);
    }

    /** @param array{uuid: string} $args */
    public function createObligation(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $activity = $this->activities->createObligation($args['uuid'], ActivityData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, self::present($activity), 'Obligación registrada.', 201);
    }

    /** @param array{uuid: string} $args */
    public function createChild(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $activity = $this->activities->createChild($args['uuid'], ActivityData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, self::present($activity), sprintf('%s registrada.', $activity->level->label()), 201);
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $activity = $this->activities->update($args['uuid'], ActivityData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, self::present($activity), 'Cambios guardados.');
    }

    /** @param array{uuid: string} $args */
    public function destroy(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $this->activities->delete($args['uuid']);

        return $this->responder->success($response, null, 'Elemento eliminado.');
    }

    /** @param array{uuid: string} $args */
    public function recordProgress(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $v = Validator::fromBody($request->getParsedBody());
        $body = $request->getParsedBody();
        $raw = is_array($body) ? ($body['progress'] ?? null) : null;
        $progress = filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 100]]);
        if ($progress === false) {
            $v->add('progress', 'invalid', 'Indique un porcentaje entero entre 0 y 100.');
        }
        $note = $v->string('note', 2000, 10);
        $v->throwIfInvalid();

        $activity = $this->activities->recordProgress($args['uuid'], (int) $progress, Validator::present($note));

        return $this->responder->success($response, self::present($activity), 'Avance registrado.');
    }

    /** @param array{uuid: string} $args */
    public function progressHistory(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $result = $this->activities->progressHistory($args['uuid']);

        return $this->responder->success($response, [
            'activity' => self::present($result['activity']),
            'history' => array_map(static fn (array $h) => [
                'uuid' => $h['uuid'],
                'previous_progress' => $h['previous_progress'],
                'new_progress' => $h['new_progress'],
                'note' => $h['note'],
                'user' => $h['user'],
                'recorded_at' => DateTimes::toApi($h['recorded_at']),
            ], $result['history']),
        ]);
    }

    /** @return array<string, mixed> */
    private static function present(Activity $a): array
    {
        return [
            'uuid' => $a->uuid,
            'level' => $a->level->value,
            'level_label' => $a->level->label(),
            'position' => $a->position,
            'title' => $a->title,
            'description' => $a->description,
            'weight' => $a->weight,
            'progress' => $a->progress,
            // Hoja = recibe avances declarados; si tiene hijos, el avance es calculado.
            'progress_is_computed' => !$a->isLeaf(),
            'due_date' => $a->dueDate?->format('Y-m-d'),
            'has_progress_updates' => $a->updateCount > 0,
            'updated_at' => DateTimes::toApi($a->updatedAt),
        ];
    }

    /**
     * Convierte la lista plana en árbol (obligación → tareas → subtareas).
     *
     * @param list<Activity> $activities
     * @return list<array<string, mixed>>
     */
    private function nest(array $activities): array
    {
        $byParent = [];
        foreach ($activities as $activity) {
            $byParent[$activity->parentId ?? 0][] = $activity;
        }
        $build = static function (int $parentId) use (&$build, $byParent): array {
            return array_map(
                static fn (Activity $a) => self::present($a) + ['children' => $build($a->id)],
                $byParent[$parentId] ?? [],
            );
        };

        return $build(0);
    }
}
