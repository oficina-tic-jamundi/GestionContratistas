<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Services\Notifications\NotificationService;

final class NotificationController
{
    public function __construct(
        private readonly NotificationService $notifications,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $page = $this->notifications->mine(($query['unread'] ?? '') === '1', PageRequest::fromQuery($query, ['created_at' => 'created_at'], 'created_at', 'desc'));

        return $this->responder->success($response, $page->map(static fn (array $n) => [
            'uuid' => $n['uuid'],
            'type' => $n['type'],
            'title' => $n['title'],
            'body' => $n['body'],
            'link' => $n['link_path'],
            'read' => $n['read_at'] !== null,
            'created_at' => DateTimes::toApi($n['created_at']),
        ]), meta: $page->meta());
    }

    public function unreadCount(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, ['unread' => $this->notifications->unreadCount()]);
    }

    /** @param array{uuid: string} $args */
    public function markRead(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $this->notifications->markRead($args['uuid']);

        return $this->responder->success($response, null);
    }

    public function markAllRead(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, ['marked' => $this->notifications->markAllRead()], 'Notificaciones marcadas como leídas.');
    }
}
