<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\ContractorData;
use Sigcon\DTOs\ContractorFilters;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Http\Resources\ContractResources;
use Sigcon\Models\Contractor;
use Sigcon\Repositories\ContractorRepository;
use Sigcon\Services\Contractors\ContractorService;

final class ContractorController
{
    public function __construct(
        private readonly ContractorService $contractors,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $page = $this->contractors->list(
            ContractorFilters::fromQuery($query),
            PageRequest::fromQuery($query, ContractorRepository::SORTABLE, 'name'),
        );

        return $this->responder->success(
            $response,
            $page->map(static fn (Contractor $c) => ContractResources::contractor($c)),
            meta: $page->meta(),
        );
    }

    /** @param array{uuid: string} $args */
    public function show(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, ContractResources::contractor($this->contractors->get($args['uuid'])));
    }

    public function store(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $contractor = $this->contractors->create(ContractorData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, ContractResources::contractor($contractor), 'Contratista registrado.', 201);
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $contractor = $this->contractors->update($args['uuid'], ContractorData::fromBody($request->getParsedBody()));

        return $this->responder->success($response, ContractResources::contractor($contractor), 'Contratista actualizado.');
    }

    /** @param array{uuid: string} $args */
    public function activate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $result = $this->contractors->setActive($args['uuid'], true);

        return $this->responder->success($response, ContractResources::contractor($result['contractor']), 'Contratista activado.');
    }

    /** @param array{uuid: string} $args */
    public function deactivate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $result = $this->contractors->setActive($args['uuid'], false);
        $message = $result['active_contracts'] > 0
            ? sprintf('Contratista desactivado. Tiene %d contrato(s) en ejecución que no se modificaron.', $result['active_contracts'])
            : 'Contratista desactivado.';

        return $this->responder->success($response, ContractResources::contractor($result['contractor']), $message);
    }
}
