<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\CreateUserData;
use Sigcon\DTOs\UpdateUserData;
use Sigcon\DTOs\UserFilters;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Http\Resources\UserResource;
use Sigcon\Models\User;
use Sigcon\Repositories\UserRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Users\UserService;

final class UserController
{
    public function __construct(
        private readonly UserService $users,
        private readonly AuthContext $auth,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $result = $this->users->list(
            UserFilters::fromQuery($query),
            PageRequest::fromQuery($query, UserRepository::SORTABLE, 'name'),
        );
        $page = $result['page'];

        return $this->responder->success(
            $response,
            $page->map(static fn (User $u) => UserResource::toArray($u, $result['roles'][$u->id] ?? [])),
            meta: $page->meta(),
        );
    }

    /** @param array{uuid: string} $args */
    public function show(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $user = $this->users->get($args['uuid']);

        return $this->responder->success($response, UserResource::toArray($user, $this->users->rolesOf($user)));
    }

    public function store(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $data = CreateUserData::fromBody($request->getParsedBody());
        if ($data->roles !== []) {
            $this->auth->require(Permission::UsersAssignRoles);
        }
        $result = $this->users->create($data);

        return $this->responder->success($response, [
            'user' => UserResource::toArray($result['user'], $this->users->rolesOf($result['user'])),
            // Se muestra UNA sola vez; el sistema no la guarda en claro ni la envía por otro medio.
            'temporary_password' => $result['temporary_password'],
        ], 'Usuario creado. Entregue la contraseña temporal por un canal seguro.', 201);
    }

    /** @param array{uuid: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $data = UpdateUserData::fromBody($request->getParsedBody());
        if ($data->fields !== [] || $data->departmentProvided) {
            $this->auth->require(Permission::UsersUpdate);
        }
        if ($data->roles !== null) {
            $this->auth->require(Permission::UsersAssignRoles);
        }
        $user = $this->users->update($args['uuid'], $data);

        return $this->responder->success($response, UserResource::toArray($user, $this->users->rolesOf($user)), 'Usuario actualizado.');
    }

    /** @param array{uuid: string} $args */
    public function activate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $user = $this->users->activate($args['uuid']);

        return $this->responder->success($response, UserResource::toArray($user, $this->users->rolesOf($user)), 'Usuario activado.');
    }

    /** @param array{uuid: string} $args */
    public function deactivate(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $user = $this->users->deactivate($args['uuid']);

        return $this->responder->success($response, UserResource::toArray($user, $this->users->rolesOf($user)), 'Usuario desactivado. Sus sesiones fueron cerradas.');
    }

    /** @param array{uuid: string} $args */
    public function resetPassword(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $result = $this->users->resetPassword($args['uuid']);

        return $this->responder->success($response, [
            'user' => UserResource::toArray($result['user'], $this->users->rolesOf($result['user'])),
            'temporary_password' => $result['temporary_password'],
        ], 'Contraseña restablecida. Entregue la contraseña temporal por un canal seguro.');
    }
}
