<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\AuditFilters;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Repositories\AuditLogRepository;
use Sigcon\Services\Audit\AuditQueryService;

final class AuditLogController
{
    public function __construct(
        private readonly AuditQueryService $audit,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $result = $this->audit->search(
            AuditFilters::fromQuery($query),
            PageRequest::fromQuery($query, AuditLogRepository::SORTABLE, 'occurred_at', 'desc'),
        );

        return $this->responder->success($response, $result['items'], meta: $result['meta']);
    }

    public function actions(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, $this->audit->actions());
    }
}
