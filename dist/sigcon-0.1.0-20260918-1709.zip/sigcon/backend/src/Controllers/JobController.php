<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Job;
use Sigcon\Models\JobStatus;
use Sigcon\Repositories\JobRepository;
use Sigcon\Services\Jobs\JobAdminService;

final class JobController
{
    /** Nombres legibles de los tipos de trabajo (los tipos nuevos se agregan aquí). */
    private const TYPE_LABELS = ['report.pdf' => 'PDF de informe'];

    public function __construct(
        private readonly JobAdminService $jobs,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $status = JobStatus::tryFrom(is_string($query['status'] ?? null) ? $query['status'] : '');
        $page = $this->jobs->list($status, PageRequest::fromQuery($query, JobRepository::SORTABLE, 'created_at', 'desc'));

        return $this->responder->success($response, $page->map(self::present(...)), meta: $page->meta());
    }

    public function status(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $status = $this->jobs->status();

        return $this->responder->success($response, [
            'counts' => $status['counts'],
            'stale' => $status['stale'],
            'stale_after_minutes' => $status['stale_after_minutes'],
            'last_run' => $status['last_run'] === null ? null : [
                'started_at' => DateTimes::toApi($status['last_run']['started_at']),
                'finished_at' => DateTimes::toApi($status['last_run']['finished_at']),
                'processed' => $status['last_run']['processed'],
                'failed' => $status['last_run']['failed'],
            ],
        ]);
    }

    /** @param array{uuid: string} $args */
    public function retry(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->responder->success($response, self::present($this->jobs->retry($args['uuid'])), 'La tarea se volverá a ejecutar en la próxima pasada del procesador.');
    }

    /** @return array<string, mixed> Sin el contenido del payload: solo metadatos. */
    private static function present(Job $job): array
    {
        return [
            'uuid' => $job->uuid,
            'type' => $job->type,
            'type_label' => self::TYPE_LABELS[$job->type] ?? $job->type,
            'status' => $job->status->value,
            'status_label' => $job->status->label(),
            'attempts' => $job->attempts,
            'max_attempts' => $job->maxAttempts,
            'available_at' => DateTimes::toApi($job->availableAt),
            'last_error' => $job->lastError,
            'created_at' => DateTimes::toApi($job->createdAt),
            'updated_at' => DateTimes::toApi($job->updatedAt),
            'completed_at' => DateTimes::toApi($job->completedAt),
            'failed_at' => DateTimes::toApi($job->failedAt),
        ];
    }
}
