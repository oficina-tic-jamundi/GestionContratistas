<?php

declare(strict_types=1);

namespace Sigcon\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\DTOs\RoleData;
use Sigcon\Http\JsonResponder;
use Sigcon\Http\Resources\RoleResource;
use Sigcon\Models\PermissionDefinition;
use Sigcon\Models\Role;
use Sigcon\Services\Roles\RoleService;

final class RoleController
{
    public function __construct(
        private readonly RoleService $roles,
        private readonly JsonResponder $responder,
    ) {
    }

    public function index(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, array_map(
            static fn (Role $r) => RoleResource::toArray($r),
            $this->roles->list(),
        ));
    }

    public function permissions(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->responder->success($response, array_map(
            static fn (PermissionDefinition $p) => RoleResource::permission($p),
            $this->roles->permissions(),
        ));
    }

    public function store(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $role = $this->roles->create(RoleData::fromBody($request->getParsedBody(), withCode: true));

        return $this->responder->success($response, RoleResource::toArray($role), 'Rol creado.', 201);
    }

    /** @param array{code: string} $args */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $role = $this->roles->update($args['code'], RoleData::fromBody($request->getParsedBody(), withCode: false));

        return $this->responder->success($response, RoleResource::toArray($role), 'Rol actualizado.');
    }

    /** @param array{code: string} $args */
    public function destroy(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $this->roles->delete($args['code']);

        return $this->responder->success($response, null, 'Rol eliminado.');
    }
}
