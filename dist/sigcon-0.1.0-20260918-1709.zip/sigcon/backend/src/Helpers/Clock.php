<?php

declare(strict_types=1);

namespace Sigcon\Helpers;

use DateTimeImmutable;

/**
 * Fuente única de "ahora". Se inyecta para que las reglas dependientes del tiempo
 * (expiración de sesiones, bloqueos) puedan probarse de forma determinista.
 */
interface Clock
{
    /** Instante actual en UTC. */
    public function now(): DateTimeImmutable;
}
