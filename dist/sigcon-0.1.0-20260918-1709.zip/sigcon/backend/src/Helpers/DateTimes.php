<?php

declare(strict_types=1);

namespace Sigcon\Helpers;

use DateTimeImmutable;
use DateTimeZone;

/**
 * Conversión de fechas entre base de datos (UTC, ADR-010) y API (ISO 8601 en la zona institucional).
 */
final class DateTimes
{
    private const DB_FORMAT = 'Y-m-d H:i:s';

    public static function toDb(DateTimeImmutable $value): string
    {
        return $value->setTimezone(new DateTimeZone('UTC'))->format(self::DB_FORMAT);
    }

    public static function fromDb(string $value): DateTimeImmutable
    {
        $parsed = DateTimeImmutable::createFromFormat(self::DB_FORMAT, $value, new DateTimeZone('UTC'));
        if ($parsed === false) {
            throw new \UnexpectedValueException(sprintf('Fecha de base de datos inválida: %s', $value));
        }

        return $parsed;
    }

    public static function fromDbNullable(?string $value): ?DateTimeImmutable
    {
        return $value === null ? null : self::fromDb($value);
    }

    /** ISO 8601 con desfase en la zona horaria de la aplicación (date_default_timezone_get). */
    public static function toApi(?DateTimeImmutable $value): ?string
    {
        return $value?->setTimezone(new DateTimeZone(date_default_timezone_get()))->format(DATE_ATOM);
    }
}
