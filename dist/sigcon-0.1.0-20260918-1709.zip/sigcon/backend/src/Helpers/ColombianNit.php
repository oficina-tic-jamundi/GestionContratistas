<?php

declare(strict_types=1);

namespace Sigcon\Helpers;

/**
 * Dígito de verificación del NIT según el algoritmo de la DIAN (módulo 11 con pesos primos).
 */
final class ColombianNit
{
    private const WEIGHTS = [3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71];

    public static function verificationDigit(string $nit): int
    {
        if (preg_match('/^[0-9]{1,15}$/', $nit) !== 1) {
            throw new \InvalidArgumentException('El NIT debe contener solo dígitos (máximo 15).');
        }

        $sum = 0;
        $digits = strrev($nit);
        for ($i = 0, $n = strlen($digits); $i < $n; $i++) {
            $sum += (int) $digits[$i] * self::WEIGHTS[$i];
        }
        $remainder = $sum % 11;

        return $remainder > 1 ? 11 - $remainder : $remainder;
    }
}
