<?php

declare(strict_types=1);

namespace Sigcon\Helpers;

use InvalidArgumentException;

/**
 * Valores en pesos como centavos enteros: sin errores de punto flotante.
 * Entrada y salida como texto decimal con punto ("1234567.89"), igual que la API y MySQL.
 */
final class Money
{
    public static function toCents(string $value): int
    {
        if (preg_match('/^(\d{1,13})(?:\.(\d{1,2}))?$/', trim($value), $m) !== 1) {
            throw new InvalidArgumentException('Valor monetario no válido.');
        }

        return (int) $m[1] * 100 + (int) str_pad($m[2] ?? '0', 2, '0');
    }

    /** Formato colombiano para textos legibles: "$1.500.000" o "$1.500.000,50". */
    public static function format(string $value): string
    {
        $cents = self::toCents($value);
        $pesos = number_format(intdiv($cents, 100), 0, ',', '.');

        return '$' . $pesos . ($cents % 100 === 0 ? '' : sprintf(',%02d', $cents % 100));
    }

    public static function fromCents(int $cents): string
    {
        $sign = $cents < 0 ? '-' : '';
        $cents = abs($cents);

        return sprintf('%s%d.%02d', $sign, intdiv($cents, 100), $cents % 100);
    }
}
