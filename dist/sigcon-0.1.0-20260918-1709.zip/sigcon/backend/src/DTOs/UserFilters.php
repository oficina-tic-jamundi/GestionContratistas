<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Models\UserStatus;
use Sigcon\Validators\Validator;

final class UserFilters
{
    public function __construct(
        public readonly ?string $search = null,
        public readonly ?UserStatus $status = null,
        public readonly ?string $roleCode = null,
        public readonly ?string $departmentUuid = null,
    ) {
    }

    /** @param array<string, mixed> $query */
    public static function fromQuery(array $query): self
    {
        $v = new Validator($query);
        $search = $v->string('search', 100, required: false);
        $statusRaw = $v->string('status', 20, required: false);
        $role = $v->string('role', 50, required: false);
        $department = $v->uuid('department', required: false);

        $status = null;
        if ($statusRaw !== null) {
            $status = UserStatus::tryFrom($statusRaw);
            if ($status === null) {
                $v->add('status', 'invalid_value', 'Estado no válido.');
            }
        }
        $v->throwIfInvalid();

        return new self($search, $status, $role, $department);
    }
}
