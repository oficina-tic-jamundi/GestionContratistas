<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use DateTimeImmutable;
use Sigcon\Validators\Validator;

final class ActivityData
{
    public function __construct(
        public readonly string $title,
        public readonly ?string $description,
        /** Decimal como texto con 2 decimales ("1.00"). */
        public readonly string $weight,
        public readonly ?DateTimeImmutable $dueDate,
    ) {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        $v = Validator::fromBody($body);
        $title = $v->string('title', 255, 3);
        $description = $v->string('description', 5000, required: false);
        $dueDate = $v->date('due_date', required: false);

        $weight = '1.00';
        $raw = is_array($body) ? ($body['weight'] ?? null) : null;
        if ($raw !== null && $raw !== '') {
            $raw = is_int($raw) || is_float($raw) ? (string) $raw : $raw;
            if (!is_string($raw) || preg_match('/^(\d{1,4})(?:\.(\d{1,2}))?$/', $raw, $m) !== 1 || ((int) $m[1] === 0 && (int) ($m[2] ?? 0) === 0) || (int) $m[1] > 1000) {
                $v->add('weight', 'invalid', 'El peso debe ser un número mayor que 0 y hasta 1000, con máximo 2 decimales.');
            } else {
                $weight = $m[1] . '.' . str_pad($m[2] ?? '', 2, '0');
            }
        }
        $v->throwIfInvalid();

        return new self(Validator::present($title), $description, $weight, $dueDate);
    }
}
