<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use DateTimeImmutable;
use Sigcon\Validators\Validator;

/** Datos de un contrato en borrador (crear o modificar). */
final class ContractData
{
    public function __construct(
        public readonly string $contractNumber,
        public readonly string $object,
        public readonly string $contractorUuid,
        public readonly string $departmentUuid,
        public readonly ?string $supervisorUuid,
        public readonly ?DateTimeImmutable $signedAt,
        public readonly DateTimeImmutable $startDate,
        public readonly DateTimeImmutable $endDate,
        public readonly string $totalValue,
        public readonly ?string $secopUrl,
    ) {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        $v = Validator::fromBody($body);
        $number = $v->string('contract_number', 50, 3);
        $object = $v->string('object', 5000, 10);
        $contractor = $v->uuid('contractor');
        $department = $v->uuid('department');
        $supervisor = $v->uuid('supervisor', required: false);
        $signedAt = $v->date('signed_at', required: false);
        $start = $v->date('start_date');
        $end = $v->date('end_date');
        $value = $v->money('total_value');
        $secop = $v->httpsUrl('secop_url');

        if ($start !== null && $end !== null && $end < $start) {
            $v->add('end_date', 'before_start', 'La fecha de terminación no puede ser anterior a la de inicio.');
        }
        if ($signedAt !== null && $start !== null && $signedAt > $start) {
            $v->add('signed_at', 'after_start', 'La fecha de suscripción no puede ser posterior a la fecha de inicio.');
        }
        $v->throwIfInvalid();

        return new self(
            Validator::present($number),
            Validator::present($object),
            Validator::present($contractor),
            Validator::present($department),
            $supervisor,
            $signedAt,
            Validator::present($start),
            Validator::present($end),
            Validator::present($value),
            $secop,
        );
    }
}
