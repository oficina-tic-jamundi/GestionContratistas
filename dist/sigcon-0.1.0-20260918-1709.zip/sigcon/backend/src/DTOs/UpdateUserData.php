<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Validators\Validator;

/**
 * Actualización parcial (PATCH): solo se modifican los campos presentes en el cuerpo.
 */
final class UpdateUserData
{
    /**
     * @param array<string, string|null> $fields columna => valor
     * @param list<string>|null $roles null = no modificar roles
     */
    public function __construct(
        public readonly array $fields,
        public readonly ?array $roles,
        /** true si el cuerpo incluye "department" (puede ser null para quitarla). */
        public readonly bool $departmentProvided = false,
        public readonly ?string $departmentUuid = null,
    ) {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        $v = Validator::fromBody($body);
        $fields = [];
        if ($v->has('first_name')) {
            $fields['first_name'] = $v->string('first_name', 100);
        }
        if ($v->has('last_name')) {
            $fields['last_name'] = $v->string('last_name', 100);
        }
        if ($v->has('email')) {
            $fields['email'] = $v->email('email');
        }
        if ($v->has('phone')) {
            $fields['phone'] = $v->phone('phone');
        }
        $roles = $v->has('roles') ? $v->stringList('roles') : null;
        $department = $v->has('department') ? $v->uuid('department', required: false) : null;
        if ($fields === [] && !$v->has('roles') && !$v->has('department')) {
            $v->add('body', 'empty', 'No se envió ningún campo para actualizar.');
        }
        $v->throwIfInvalid();

        return new self($fields, $roles, $v->has('department'), $department);
    }
}
