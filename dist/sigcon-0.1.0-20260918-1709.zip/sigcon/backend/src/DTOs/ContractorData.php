<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Helpers\ColombianNit;
use Sigcon\Models\DocumentType;
use Sigcon\Models\PersonType;
use Sigcon\Validators\Validator;

final class ContractorData
{
    public function __construct(
        public readonly PersonType $personType,
        public readonly DocumentType $documentType,
        public readonly string $documentNumber,
        public readonly ?int $verificationDigit,
        public readonly string $name,
        public readonly ?string $email,
        public readonly ?string $phone,
        public readonly ?string $address,
        /** UUID de la cuenta de usuario a vincular; null = sin cuenta. */
        public readonly ?string $userUuid,
    ) {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        $v = Validator::fromBody($body);
        $personType = $v->enum('person_type', PersonType::class);
        $documentType = $v->enum('document_type', DocumentType::class);
        $rawNumber = $v->string('document_number', 30, 3);
        $name = $v->string('name', 200, 3);
        $email = $v->email('email', required: false);
        $phone = $v->phone('phone');
        $address = $v->string('address', 200, required: false);
        $userUuid = $v->uuid('user', required: false);

        $number = null;
        $dv = null;
        if ($personType instanceof PersonType && $documentType instanceof DocumentType) {
            if (!in_array($documentType, $personType->allowedDocumentTypes(), true)) {
                $v->add('document_type', 'not_allowed', sprintf('Tipo de documento no válido para %s.', mb_strtolower($personType->label())));
            }
        }
        if ($documentType instanceof DocumentType && $rawNumber !== null) {
            // Se aceptan puntos, espacios y guiones al digitar; se guardan sin ellos.
            $number = strtoupper((string) preg_replace('/[\s.\-]/', '', $rawNumber));
            if (preg_match($documentType->pattern(), $number) !== 1) {
                $v->add('document_number', 'invalid_format', $documentType->formatHint());
                $number = null;
            }
            if ($documentType === DocumentType::NIT) {
                $dv = self::verificationDigit($v, $body, $number);
            } elseif (is_array($body) && ($body['verification_digit'] ?? null) !== null && $body['verification_digit'] !== '') {
                $v->add('verification_digit', 'not_allowed', 'El dígito de verificación solo aplica al NIT.');
            }
        }
        $v->throwIfInvalid();

        return new self(
            Validator::present($personType),
            Validator::present($documentType),
            Validator::present($number),
            $dv,
            Validator::present($name),
            $email,
            $phone,
            $address,
            $userUuid,
        );
    }

    /** @param array<mixed>|object|null $body */
    private static function verificationDigit(Validator $v, array|object|null $body, ?string $nit): ?int
    {
        $raw = is_array($body) ? ($body['verification_digit'] ?? null) : null;
        if ($raw === null || $raw === '' || filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 9]]) === false) {
            $v->add('verification_digit', 'required', 'Ingrese el dígito de verificación del NIT (0 a 9).');

            return null;
        }
        $dv = (int) $raw;
        if ($nit !== null && ColombianNit::verificationDigit($nit) !== $dv) {
            $v->add('verification_digit', 'mismatch', 'El dígito de verificación no corresponde al NIT. Verifique el número.');

            return null;
        }

        return $dv;
    }
}
