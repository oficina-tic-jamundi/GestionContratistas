<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use DateTimeImmutable;
use DateTimeZone;
use Sigcon\Helpers\Uuid;
use Sigcon\Validators\Validator;

final class AuditFilters
{
    public function __construct(
        public readonly ?string $action = null,
        public readonly ?string $entityType = null,
        public readonly ?string $entityId = null,
        public readonly ?string $userUuid = null,
        public readonly ?DateTimeImmutable $from = null,
        public readonly ?DateTimeImmutable $to = null,
    ) {
    }

    /**
     * Las fechas `from` y `to` son días (AAAA-MM-DD) en la zona horaria institucional; `to` es inclusivo.
     *
     * @param array<string, mixed> $query
     */
    public static function fromQuery(array $query): self
    {
        $v = new Validator($query);
        $action = $v->string('action', 100, required: false);
        $entityType = $v->string('entity_type', 50, required: false);
        $entityId = $v->string('entity_id', 64, required: false);
        $user = $v->string('user', 36, required: false);
        if ($user !== null && !Uuid::isValid($user)) {
            $v->add('user', 'invalid', 'Identificador de usuario no válido.');
        }
        $from = self::day($v, 'from');
        $to = self::day($v, 'to')?->modify('+1 day');
        if ($from !== null && $to !== null && $from >= $to) {
            $v->add('to', 'invalid_range', 'La fecha final debe ser igual o posterior a la inicial.');
        }
        $v->throwIfInvalid();

        return new self($action, $entityType, $entityId, $user, $from, $to);
    }

    private static function day(Validator $v, string $field): ?DateTimeImmutable
    {
        $raw = $v->string($field, 10, required: false);
        if ($raw === null) {
            return null;
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $raw, new DateTimeZone(date_default_timezone_get()));
        if ($date === false || $date->format('Y-m-d') !== $raw) {
            $v->add($field, 'invalid_date', 'Use el formato AAAA-MM-DD.');

            return null;
        }

        return $date;
    }
}
