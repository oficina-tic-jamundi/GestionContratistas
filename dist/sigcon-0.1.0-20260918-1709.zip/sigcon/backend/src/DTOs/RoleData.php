<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Validators\Validator;

final class RoleData
{
    /** @param list<string> $permissions */
    public function __construct(
        public readonly ?string $code,
        public readonly string $name,
        public readonly ?string $description,
        public readonly array $permissions,
    ) {
    }

    /**
     * @param array<mixed>|object|null $body
     * @param bool $withCode true al crear (el código es inmutable después)
     */
    public static function fromBody(array|object|null $body, bool $withCode): self
    {
        $v = Validator::fromBody($body);
        $code = $withCode ? $v->code('code') : null;
        $name = $v->string('name', 100, 3);
        $description = $v->string('description', 255, required: false);
        $permissions = $v->stringList('permissions');
        $v->throwIfInvalid();

        return new self($code, Validator::present($name), $description, Validator::present($permissions));
    }
}
