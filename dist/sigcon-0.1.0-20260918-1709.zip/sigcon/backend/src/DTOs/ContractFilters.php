<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use DateTimeImmutable;
use Sigcon\Models\ContractStatus;
use Sigcon\Validators\Validator;

final class ContractFilters
{
    public function __construct(
        public readonly ?string $search = null,
        public readonly ?ContractStatus $status = null,
        public readonly ?string $departmentUuid = null,
        public readonly ?string $contractorUuid = null,
        public readonly ?string $supervisorUuid = null,
        public readonly ?DateTimeImmutable $endingBefore = null,
    ) {
    }

    /** @param array<string, mixed> $query */
    public static function fromQuery(array $query): self
    {
        $v = new Validator($query);
        $search = $v->string('search', 100, required: false);
        $status = $v->enum('status', ContractStatus::class, required: false);
        $department = $v->uuid('department', required: false);
        $contractor = $v->uuid('contractor', required: false);
        $supervisor = $v->uuid('supervisor', required: false);
        $ending = $v->date('ending_before', required: false);
        $v->throwIfInvalid();

        return new self(
            $search,
            $status instanceof ContractStatus ? $status : null,
            $department,
            $contractor,
            $supervisor,
            $ending,
        );
    }
}
