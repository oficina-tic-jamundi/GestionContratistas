<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Models\ActiveStatus;
use Sigcon\Validators\Validator;

final class ContractorFilters
{
    public function __construct(
        public readonly ?string $search = null,
        public readonly ?ActiveStatus $status = null,
    ) {
    }

    /** @param array<string, mixed> $query */
    public static function fromQuery(array $query): self
    {
        $v = new Validator($query);
        $search = $v->string('search', 100, required: false);
        $status = $v->enum('status', ActiveStatus::class, required: false);
        $v->throwIfInvalid();

        return new self($search, $status instanceof ActiveStatus ? $status : null);
    }
}
