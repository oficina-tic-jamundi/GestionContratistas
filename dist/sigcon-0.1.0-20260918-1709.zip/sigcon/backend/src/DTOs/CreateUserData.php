<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Validators\Validator;

final class CreateUserData
{
    /** @param list<string> $roles */
    public function __construct(
        public readonly string $firstName,
        public readonly string $lastName,
        public readonly string $email,
        public readonly ?string $phone,
        public readonly array $roles,
        /** UUID de la dependencia; null = sin dependencia. */
        public readonly ?string $departmentUuid = null,
    ) {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        $v = Validator::fromBody($body);
        $firstName = $v->string('first_name', 100);
        $lastName = $v->string('last_name', 100);
        $email = $v->email('email');
        $phone = $v->phone('phone');
        $roles = $v->has('roles') ? $v->stringList('roles') : [];
        $department = $v->uuid('department', required: false);
        $v->throwIfInvalid();

        return new self(
            Validator::present($firstName),
            Validator::present($lastName),
            Validator::present($email),
            $phone,
            $roles ?? [],
            $department,
        );
    }
}
