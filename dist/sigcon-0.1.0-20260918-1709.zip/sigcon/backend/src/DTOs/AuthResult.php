<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Models\User;

/** Resultado de un inicio de sesión o rotación de sesión. El token nunca va en el cuerpo de la respuesta. */
final class AuthResult
{
    public function __construct(
        public readonly User $user,
        #[\SensitiveParameter]
        public readonly string $sessionToken,
    ) {
    }
}
