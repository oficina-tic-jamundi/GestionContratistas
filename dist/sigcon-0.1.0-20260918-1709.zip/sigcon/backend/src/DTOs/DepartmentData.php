<?php

declare(strict_types=1);

namespace Sigcon\DTOs;

use Sigcon\Validators\Validator;

final class DepartmentData
{
    public function __construct(
        public readonly string $code,
        public readonly string $name,
    ) {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        $v = Validator::fromBody($body);
        $code = $v->string('code', 20, 2);
        if ($code !== null) {
            $code = strtoupper($code);
            if (preg_match('/^[A-Z0-9][A-Z0-9_-]{1,19}$/', $code) !== 1) {
                $v->add('code', 'invalid_format', 'Use letras, números, guion o guion bajo (ej. SPLAN).');
            }
        }
        $name = $v->string('name', 150, 3);
        $v->throwIfInvalid();

        return new self(Validator::present($code), Validator::present($name));
    }
}
