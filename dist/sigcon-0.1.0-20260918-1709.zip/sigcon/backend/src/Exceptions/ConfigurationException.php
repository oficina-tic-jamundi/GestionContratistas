<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

use RuntimeException;

/**
 * Configuración inválida o incompleta. Es un error del despliegue, no del usuario:
 * se registra en logs y al cliente solo se le muestra un error genérico.
 */
final class ConfigurationException extends RuntimeException
{
}
