<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** Datos de entrada inválidos. Incluye la lista de errores por campo. */
final class ValidationException extends AppException
{
    /**
     * @param list<array{field: ?string, code: string, message: string}> $errors
     */
    public static function withErrors(array $errors): self
    {
        return new self('Los datos enviados no son válidos.', $errors);
    }

    public static function field(string $field, string $code, string $message): self
    {
        return self::withErrors([['field' => $field, 'code' => $code, 'message' => $message]]);
    }

    public function statusCode(): int
    {
        return 422;
    }

    public function errorCode(): string
    {
        return 'validation_error';
    }
}
