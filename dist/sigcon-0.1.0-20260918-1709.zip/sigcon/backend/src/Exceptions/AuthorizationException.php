<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** El usuario está autenticado pero no tiene permiso para la acción o el recurso. */
final class AuthorizationException extends AppException
{
    public function statusCode(): int
    {
        return 403;
    }

    public function errorCode(): string
    {
        return 'forbidden';
    }
}
