<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** El usuario no está autenticado o su sesión expiró. */
final class AuthenticationException extends AppException
{
    public function statusCode(): int
    {
        return 401;
    }

    public function errorCode(): string
    {
        return 'authentication_required';
    }
}
