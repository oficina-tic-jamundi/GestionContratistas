<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** La operación viola una regla de negocio (ej. aprobar un informe que no está en revisión). */
final class BusinessRuleException extends AppException
{
    public function statusCode(): int
    {
        return 409;
    }

    public function errorCode(): string
    {
        return 'business_rule_violation';
    }
}
