<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

use RuntimeException;
use Throwable;

/**
 * Base de todos los errores controlados del sistema.
 *
 * El mensaje público se muestra al usuario final; el mensaje interno (getMessage)
 * solo se registra en logs. Nunca incluir datos sensibles en el mensaje público.
 */
abstract class AppException extends RuntimeException
{
    /**
     * @param list<array{field: ?string, code: string, message: string}> $errors
     */
    public function __construct(
        private readonly string $publicMessage,
        private readonly array $errors = [],
        string $internalMessage = '',
        ?Throwable $previous = null,
    ) {
        parent::__construct($internalMessage !== '' ? $internalMessage : $publicMessage, 0, $previous);
    }

    abstract public function statusCode(): int;

    /** Código estable, legible por máquina (ej. "validation_error"). */
    abstract public function errorCode(): string;

    public function publicMessage(): string
    {
        return $this->publicMessage;
    }

    /** @return list<array{field: ?string, code: string, message: string}> */
    public function errors(): array
    {
        return $this->errors;
    }
}
