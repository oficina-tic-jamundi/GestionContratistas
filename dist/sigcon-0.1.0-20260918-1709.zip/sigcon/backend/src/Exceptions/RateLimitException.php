<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** Se superó el límite de solicitudes permitido. */
final class RateLimitException extends AppException
{
    public function __construct(string $publicMessage, private readonly int $retryAfterSeconds)
    {
        parent::__construct($publicMessage);
    }

    public function retryAfterSeconds(): int
    {
        return $this->retryAfterSeconds;
    }

    public function statusCode(): int
    {
        return 429;
    }

    public function errorCode(): string
    {
        return 'too_many_requests';
    }
}
