<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** Un servicio externo (Google Drive, geocodificación, etc.) no respondió correctamente. */
final class IntegrationException extends AppException
{
    public function statusCode(): int
    {
        return 503;
    }

    public function errorCode(): string
    {
        return 'integration_unavailable';
    }
}
