<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/**
 * Solicitud rechazada por un control de seguridad (CSRF, origen, cambio de contraseña pendiente).
 * Cada caso tiene su propio código para que el frontend reaccione correctamente.
 */
final class SecurityCheckException extends AppException
{
    public const CSRF_INVALID = 'csrf_token_invalid';
    public const ORIGIN_NOT_ALLOWED = 'origin_not_allowed';
    public const PASSWORD_CHANGE_REQUIRED = 'password_change_required';

    public function __construct(string $publicMessage, private readonly string $securityCode)
    {
        parent::__construct($publicMessage);
    }

    public function statusCode(): int
    {
        return 403;
    }

    public function errorCode(): string
    {
        return $this->securityCode;
    }
}
