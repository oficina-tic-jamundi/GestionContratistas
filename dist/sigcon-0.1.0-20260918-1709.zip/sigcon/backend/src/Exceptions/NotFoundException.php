<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** El recurso no existe o el usuario no puede saber que existe. */
final class NotFoundException extends AppException
{
    public function statusCode(): int
    {
        return 404;
    }

    public function errorCode(): string
    {
        return 'not_found';
    }
}
