<?php

declare(strict_types=1);

namespace Sigcon\Exceptions;

/** Archivo rechazado: tipo, tamaño o contenido no permitido. */
final class FileException extends AppException
{
    public function statusCode(): int
    {
        return 422;
    }

    public function errorCode(): string
    {
        return 'invalid_file';
    }
}
