<?php

declare(strict_types=1);

namespace Sigcon\Validators;

use Sigcon\Exceptions\ValidationException;

/**
 * Validador de entrada con acumulación de errores por campo.
 *
 * Uso:
 *   $v = new Validator($body);
 *   $email = $v->email('email');
 *   $name  = $v->string('first_name', max: 100);
 *   $v->throwIfInvalid();
 *
 * Cada regla devuelve el valor ya normalizado (recortado, tipado) o null si falló,
 * y registra el error. Los campos desconocidos se ignoran.
 */
final class Validator
{
    /** @var list<array{field: ?string, code: string, message: string}> */
    private array $errors = [];

    /** @param array<string, mixed> $data */
    public function __construct(private readonly array $data)
    {
    }

    /** @param array<mixed>|object|null $body */
    public static function fromBody(array|object|null $body): self
    {
        return new self(is_array($body) ? $body : []);
    }

    public function has(string $field): bool
    {
        return array_key_exists($field, $this->data);
    }

    public function string(string $field, int $max, int $min = 1, bool $required = true): ?string
    {
        $value = $this->data[$field] ?? null;
        if ($value === null || (is_string($value) && trim($value) === '')) {
            if ($required) {
                $this->add($field, 'required', 'Este campo es obligatorio.');
            }

            return null;
        }
        if (!is_string($value)) {
            $this->add($field, 'invalid_type', 'Debe ser un texto.');

            return null;
        }
        $value = trim($value);
        $length = mb_strlen($value);
        if ($length < $min) {
            $this->add($field, 'too_short', sprintf('Debe tener al menos %d caracteres.', $min));

            return null;
        }
        if ($length > $max) {
            $this->add($field, 'too_long', sprintf('No puede superar %d caracteres.', $max));

            return null;
        }

        return $value;
    }

    /** Contraseñas: no se recortan espacios (son parte del secreto). */
    public function password(string $field): ?string
    {
        $value = $this->data[$field] ?? null;
        if (!is_string($value) || $value === '') {
            $this->add($field, 'required', 'Este campo es obligatorio.');

            return null;
        }

        return $value;
    }

    public function email(string $field, bool $required = true): ?string
    {
        $value = $this->string($field, 191, 3, $required);
        if ($value === null) {
            return null;
        }
        $value = mb_strtolower($value);
        if (filter_var($value, FILTER_VALIDATE_EMAIL) === false) {
            $this->add($field, 'invalid_email', 'El correo electrónico no es válido.');

            return null;
        }

        return $value;
    }

    public function phone(string $field): ?string
    {
        $value = $this->string($field, 30, 7, required: false);
        if ($value !== null && preg_match('/^\+?[0-9 ()-]{7,30}$/', $value) !== 1) {
            $this->add($field, 'invalid_phone', 'El teléfono solo puede contener números, espacios, +, ( ) y -.');

            return null;
        }

        return $value;
    }

    /**
     * Código en minúsculas (ej. código de rol).
     */
    public function code(string $field, int $max = 50): ?string
    {
        $value = $this->string($field, $max, 2);
        if ($value !== null && preg_match('/^[a-z][a-z0-9_]*$/', $value) !== 1) {
            $this->add($field, 'invalid_format', 'Solo letras minúsculas, números y guion bajo; debe iniciar con letra.');

            return null;
        }

        return $value;
    }

    /**
     * Lista de textos sin duplicados.
     *
     * @param list<string>|null $allowed valores permitidos (null = cualquiera)
     * @return list<string>|null
     */
    public function stringList(string $field, ?array $allowed = null, bool $required = true): ?array
    {
        if (!$this->has($field)) {
            if ($required) {
                $this->add($field, 'required', 'Este campo es obligatorio.');
            }

            return null;
        }
        $value = $this->data[$field];
        if (!is_array($value) || !array_is_list($value)) {
            $this->add($field, 'invalid_type', 'Debe ser una lista.');

            return null;
        }
        $result = [];
        foreach ($value as $item) {
            if (!is_string($item) || ($allowed !== null && !in_array($item, $allowed, true))) {
                $this->add($field, 'invalid_value', sprintf('Valor no permitido: %s', is_scalar($item) ? (string) $item : '?'));

                return null;
            }
            $result[$item] = $item;
        }

        return array_values($result);
    }

    /** Fecha sin hora en formato AAAA-MM-DD (ej. fechas de contrato; ver ADR-010). */
    public function date(string $field, bool $required = true): ?\DateTimeImmutable
    {
        $raw = $this->string($field, 10, required: $required);
        if ($raw === null) {
            return null;
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $raw, new \DateTimeZone('UTC'));
        if ($date === false || $date->format('Y-m-d') !== $raw) {
            $this->add($field, 'invalid_date', 'Use el formato AAAA-MM-DD con una fecha válida.');

            return null;
        }

        return $date;
    }

    /**
     * Valor monetario positivo como texto decimal ("12500000" o "12500000.50"). Se conserva como
     * string para no perder precisión (docs/api/conventions.md). Devuelve el valor normalizado a 2 decimales.
     */
    public function money(string $field, int $maxIntegerDigits = 13): ?string
    {
        $value = $this->data[$field] ?? null;
        if (is_int($value)) {
            $value = (string) $value;
        }
        if ($value === null || $value === '') {
            $this->add($field, 'required', 'Este campo es obligatorio.');

            return null;
        }
        if (!is_string($value) || preg_match('/^(0|[1-9][0-9]{0,' . ($maxIntegerDigits - 1) . '})(\.[0-9]{1,2})?$/', $value) !== 1) {
            $this->add($field, 'invalid_amount', 'Ingrese un valor en pesos sin separadores de miles, con máximo 2 decimales (ej. 12500000 o 12500000.50).');

            return null;
        }
        [$integer, $decimals] = array_pad(explode('.', $value), 2, '');
        if ((int) $integer === 0 && trim($decimals, '0') === '') {
            $this->add($field, 'invalid_amount', 'El valor debe ser mayor que cero.');

            return null;
        }

        return $integer . '.' . str_pad($decimals, 2, '0');
    }

    public function uuid(string $field, bool $required = true): ?string
    {
        $value = $this->string($field, 36, required: $required);
        if ($value !== null && !\Sigcon\Helpers\Uuid::isValid(strtolower($value))) {
            $this->add($field, 'invalid', 'Identificador no válido.');

            return null;
        }

        return $value === null ? null : strtolower($value);
    }

    /** URL https opcional (ej. enlace a SECOP II). */
    public function httpsUrl(string $field, int $max = 500): ?string
    {
        $value = $this->string($field, $max, required: false);
        if ($value !== null && (filter_var($value, FILTER_VALIDATE_URL) === false || !str_starts_with(strtolower($value), 'https://'))) {
            $this->add($field, 'invalid_url', 'Ingrese una dirección web válida que inicie con https://.');

            return null;
        }

        return $value;
    }

    /**
     * Valor de un enum respaldado por string.
     *
     * @template T of \BackedEnum
     * @param class-string<T> $enum
     * @return T|null
     */
    public function enum(string $field, string $enum, bool $required = true): ?\BackedEnum
    {
        $raw = $this->string($field, 50, required: $required);
        if ($raw === null) {
            return null;
        }
        $value = $enum::tryFrom($raw);
        if ($value === null) {
            $this->add($field, 'invalid_value', 'Valor no permitido.');
        }

        return $value;
    }

    /**
     * Extrae un valor ya validado. Solo debe llamarse después de throwIfInvalid(): si el valor
     * falta en ese punto es un error de programación, no de entrada.
     *
     * @template T
     * @param T|null $value
     * @return T
     */
    public static function present(mixed $value): mixed
    {
        return $value ?? throw new \LogicException('Se esperaba un valor validado.');
    }

    public function add(string $field, string $code, string $message): void
    {
        $this->errors[] = ['field' => $field, 'code' => $code, 'message' => $message];
    }

    public function isValid(): bool
    {
        return $this->errors === [];
    }

    public function throwIfInvalid(): void
    {
        if ($this->errors !== []) {
            throw ValidationException::withErrors($this->errors);
        }
    }
}
