<?php

declare(strict_types=1);

namespace Sigcon\Bootstrap;

use DI\ContainerBuilder;
use Dotenv\Dotenv;
use Psr\Container\ContainerInterface;
use Sigcon\Config\Env;
use Sigcon\Config\Settings;
use Sigcon\Http\ErrorHandler;
use Sigcon\Logging\LogChannel;
use Sigcon\Logging\LoggerFactory;
use Sigcon\Middleware\OriginCheckMiddleware;
use Sigcon\Middleware\RequestContextMiddleware;
use Sigcon\Middleware\SecurityHeadersMiddleware;
use Slim\App;
use Slim\Factory\AppFactory;

/**
 * Punto único de arranque, compartido por HTTP (public/index.php) y consola (bin/console).
 */
final class Kernel
{
    /**
     * @param string $rootPath Directorio backend/.
     * @param array<string, mixed>|null $env Variables explícitas (pruebas). Si es null se leen de .env y del entorno.
     * @param array<string, mixed> $overrides Definiciones que reemplazan las de config/container.php (solo pruebas).
     */
    public static function container(string $rootPath, ?array $env = null, array $overrides = []): ContainerInterface
    {
        if ($env === null) {
            // SIGCON_ENV_DIR permite ubicar el .env fuera del directorio del código (recomendado en cPanel).
            $envDir = getenv('SIGCON_ENV_DIR') ?: $rootPath;
            Dotenv::createImmutable($envDir)->safeLoad();
            $settings = Settings::fromEnv(Env::fromGlobals(), $rootPath);
        } else {
            $settings = Settings::fromEnv(new Env($env), $rootPath);
        }

        date_default_timezone_set($settings->timezone);

        $builder = new ContainerBuilder();
        $builder->useAutowiring(true);
        $builder->addDefinitions([Settings::class => $settings]);
        $builder->addDefinitions($rootPath . '/config/container.php');
        if ($overrides !== []) {
            $builder->addDefinitions($overrides);
        }

        return $builder->build();
    }

    /** @return App<ContainerInterface> */
    public static function http(ContainerInterface $container): App
    {
        /** @var Settings $settings */
        $settings = $container->get(Settings::class);

        $app = AppFactory::createFromContainer($container);
        $app->setBasePath($settings->basePath);

        // Slim ejecuta el middleware en orden inverso al registro (LIFO):
        // el último agregado es el más externo.
        $app->addBodyParsingMiddleware();
        $app->addRoutingMiddleware();
        $app->add(OriginCheckMiddleware::class);

        /** @var LoggerFactory $loggers */
        $loggers = $container->get(LoggerFactory::class);
        $errorMiddleware = $app->addErrorMiddleware(false, true, true, $loggers->channel(LogChannel::Application));
        $errorMiddleware->setDefaultErrorHandler($container->get(ErrorHandler::class));

        // Por fuera del manejo de errores, para que también las respuestas de error lleven
        // cabeceras de seguridad e ID de solicitud.
        $app->add(SecurityHeadersMiddleware::class);
        $app->add(RequestContextMiddleware::class);

        (require $settings->rootPath . '/routes/api.php')($app);

        return $app;
    }
}
