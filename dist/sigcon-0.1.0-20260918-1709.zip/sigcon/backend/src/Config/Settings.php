<?php

declare(strict_types=1);

namespace Sigcon\Config;

use Sigcon\Exceptions\ConfigurationException;

/**
 * Configuración inmutable de la aplicación, construida una sola vez desde el entorno.
 */
final class Settings
{
    public const VERSION = '0.1.0';

    public function __construct(
        public readonly string $rootPath,
        public readonly AppEnvironment $environment,
        public readonly bool $debug,
        public readonly string $appUrl,
        public readonly string $basePath,
        public readonly string $timezone,
        public readonly DatabaseSettings $database,
        public readonly SecuritySettings $security,
        public readonly string $storagePath,
        public readonly string $logPath,
        public readonly string $logLevel,
        public readonly int $uploadMaxBytes,
        public readonly EvidenceSettings $evidence,
        public readonly JobSettings $jobs,
        public readonly BackupSettings $backup,
        /** Proveedor de IA. Solo "disabled" hasta que un ADR institucional habilite otro (ADR-008). */
        public readonly string $aiProvider,
        public readonly string $migrationsPath,
    ) {
    }

    public static function fromEnv(Env $env, string $rootPath): self
    {
        $environment = AppEnvironment::tryFrom($env->string('APP_ENV', 'production'))
            ?? throw new ConfigurationException('APP_ENV debe ser development, testing o production.');

        $debug = $env->bool('APP_DEBUG', false);
        if ($debug && $environment->isProduction()) {
            throw new ConfigurationException('APP_DEBUG no puede estar activo en producción.');
        }

        $logLevel = strtolower($env->string('LOG_LEVEL', 'info'));
        if (!in_array($logLevel, ['debug', 'info', 'notice', 'warning', 'error'], true)) {
            throw new ConfigurationException('LOG_LEVEL no es válido.');
        }

        $appUrl = rtrim($env->string('APP_URL', 'http://localhost:5173'), '/');

        return new self(
            rootPath: $rootPath,
            environment: $environment,
            debug: $debug,
            appUrl: $appUrl,
            basePath: self::normalizeBasePath($env->string('APP_BASE_PATH', '/api')),
            timezone: $env->string('APP_TIMEZONE', 'America/Bogota'),
            database: DatabaseSettings::fromEnv($env),
            security: SecuritySettings::fromEnv($env, $environment, $appUrl),
            storagePath: self::resolvePath($rootPath, $env->string('STORAGE_PATH', 'storage/app')),
            logPath: self::resolvePath($rootPath, $env->string('LOG_PATH', 'storage/logs')),
            logLevel: $logLevel,
            uploadMaxBytes: $env->int('UPLOAD_MAX_SIZE_MB', 15) * 1024 * 1024,
            evidence: EvidenceSettings::fromEnv($env, $rootPath),
            jobs: JobSettings::fromEnv($env),
            backup: BackupSettings::fromEnv($env, self::resolvePath($rootPath, 'storage/backups')),
            aiProvider: self::aiProvider($env->string('AI_PROVIDER', 'disabled')),
            migrationsPath: self::resolvePath($rootPath, $env->string('MIGRATIONS_PATH', '../database/migrations')),
        );
    }

    private static function aiProvider(string $value): string
    {
        if ($value !== 'disabled') {
            throw new ConfigurationException('AI_PROVIDER solo admite "disabled": habilitar un proveedor de IA requiere una decisión institucional (ADR-008).');
        }

        return $value;
    }

    private static function normalizeBasePath(string $path): string
    {
        $path = '/' . trim($path, '/');

        return $path === '/' ? '' : $path;
    }

    private static function resolvePath(string $rootPath, string $path): string
    {
        $isAbsolute = str_starts_with($path, '/') || preg_match('/^[A-Za-z]:[\\\\\/]/', $path) === 1;

        return rtrim($isAbsolute ? $path : $rootPath . DIRECTORY_SEPARATOR . $path, '/\\');
    }
}
