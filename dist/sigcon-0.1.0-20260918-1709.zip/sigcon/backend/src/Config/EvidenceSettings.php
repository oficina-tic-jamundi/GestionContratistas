<?php

declare(strict_types=1);

namespace Sigcon\Config;

use Sigcon\Exceptions\ConfigurationException;

/**
 * Parámetros de las evidencias fotográficas (ADR-006, ADR-016).
 */
final class EvidenceSettings
{
    public function __construct(
        /** Tamaño máximo de la foto original. */
        public readonly int $maxBytes,
        /** Resolución máxima aceptada (limita la memoria que usa GD al decodificar). */
        public readonly int $maxMegapixels,
        /** Lado mayor de la versión oficial con marca de agua (el original no se redimensiona). */
        public readonly int $officialMaxSide,
        public readonly int $jpegQuality,
        public readonly int $thumbnailSide,
        /** Por encima de esta precisión (metros) la ubicación se marca como de baja precisión. */
        public readonly int $lowAccuracyMeters,
        public readonly string $fontPath,
        public readonly string $boldFontPath,
    ) {
    }

    public static function fromEnv(Env $env, string $rootPath): self
    {
        $settings = new self(
            maxBytes: $env->int('EVIDENCE_MAX_SIZE_MB', 20) * 1024 * 1024,
            maxMegapixels: $env->int('EVIDENCE_MAX_MEGAPIXELS', 50),
            officialMaxSide: $env->int('EVIDENCE_OFFICIAL_MAX_SIDE', 2560),
            jpegQuality: $env->int('EVIDENCE_JPEG_QUALITY', 85),
            thumbnailSide: $env->int('EVIDENCE_THUMBNAIL_SIDE', 480),
            lowAccuracyMeters: $env->int('EVIDENCE_LOW_ACCURACY_METERS', 100),
            fontPath: $rootPath . '/resources/fonts/DejaVuSans.ttf',
            boldFontPath: $rootPath . '/resources/fonts/DejaVuSans-Bold.ttf',
        );
        if ($settings->maxBytes < 1024 * 1024 || $settings->maxMegapixels < 1 || $settings->officialMaxSide < 640
            || $settings->jpegQuality < 50 || $settings->jpegQuality > 95 || $settings->thumbnailSide < 120
            || $settings->lowAccuracyMeters < 1) {
            throw new ConfigurationException('La configuración de evidencias (EVIDENCE_*) no es válida.');
        }

        return $settings;
    }
}
