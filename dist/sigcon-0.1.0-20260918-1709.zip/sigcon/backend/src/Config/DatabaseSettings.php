<?php

declare(strict_types=1);

namespace Sigcon\Config;

final class DatabaseSettings
{
    public function __construct(
        public readonly string $host,
        public readonly int $port,
        public readonly string $database,
        public readonly string $username,
        #[\SensitiveParameter]
        public readonly string $password,
        public readonly string $charset,
    ) {
    }

    public static function fromEnv(Env $env): self
    {
        return new self(
            host: $env->string('DB_HOST', '127.0.0.1'),
            port: $env->int('DB_PORT', 3306),
            database: $env->string('DB_DATABASE', 'sigcon'),
            username: $env->string('DB_USERNAME', 'sigcon'),
            password: $env->nullableString('DB_PASSWORD') ?? '',
            charset: $env->string('DB_CHARSET', 'utf8mb4'),
        );
    }

    public function dsn(): string
    {
        return sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $this->host,
            $this->port,
            $this->database,
            $this->charset,
        );
    }

    /**
     * Evita que la contraseña aparezca en var_dump(), logs o trazas.
     *
     * @return array<string, mixed>
     */
    public function __debugInfo(): array
    {
        return ['host' => $this->host, 'port' => $this->port, 'database' => $this->database, 'password' => '***'];
    }
}
