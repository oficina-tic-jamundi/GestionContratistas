<?php

declare(strict_types=1);

namespace Sigcon\Config;

use Sigcon\Exceptions\ConfigurationException;

/**
 * Lectura tipada de variables de entorno.
 * Único punto del sistema que accede a $_ENV / $_SERVER / getenv().
 */
final class Env
{
    /** @param array<string, mixed> $source */
    public function __construct(private readonly array $source)
    {
    }

    public static function fromGlobals(): self
    {
        $values = getenv();

        return new self(array_merge($values, $_SERVER, $_ENV));
    }

    public function string(string $key, ?string $default = null): string
    {
        $value = $this->raw($key);
        if ($value === null) {
            if ($default === null) {
                throw new ConfigurationException(sprintf('Falta la variable de entorno requerida "%s".', $key));
            }

            return $default;
        }

        return $value;
    }

    public function nullableString(string $key): ?string
    {
        return $this->raw($key);
    }

    public function int(string $key, int $default): int
    {
        $value = $this->raw($key);
        if ($value === null) {
            return $default;
        }
        if (filter_var($value, FILTER_VALIDATE_INT) === false) {
            throw new ConfigurationException(sprintf('La variable "%s" debe ser un número entero.', $key));
        }

        return (int) $value;
    }

    public function bool(string $key, bool $default): bool
    {
        $value = $this->raw($key);
        if ($value === null) {
            return $default;
        }
        $parsed = filter_var($value, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
        if ($parsed === null) {
            throw new ConfigurationException(sprintf('La variable "%s" debe ser booleana (true/false).', $key));
        }

        return $parsed;
    }

    /**
     * Devuelve null si la variable no existe o está vacía.
     */
    private function raw(string $key): ?string
    {
        $value = $this->source[$key] ?? null;
        if (!is_scalar($value)) {
            return null;
        }
        $value = trim((string) $value);

        return $value === '' ? null : $value;
    }
}
