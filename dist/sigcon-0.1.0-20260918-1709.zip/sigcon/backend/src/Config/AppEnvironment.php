<?php

declare(strict_types=1);

namespace Sigcon\Config;

enum AppEnvironment: string
{
    case Development = 'development';
    case Testing = 'testing';
    case Production = 'production';

    public function isProduction(): bool
    {
        return $this === self::Production;
    }
}
