<?php

declare(strict_types=1);

namespace Sigcon\Config;

use Sigcon\Exceptions\ConfigurationException;

/** Parámetros de la cola de trabajos (ADR-005, ADR-017). */
final class JobSettings
{
    /** Espera antes de cada reintento, en minutos (1.º, 2.º, …); el último valor se repite. */
    public const BACKOFF_MINUTES = [1, 5, 15, 60, 240];

    public function __construct(
        /** Tiempo máximo de una ejecución de `jobs:run` (menor que el intervalo del Cron). */
        public readonly int $maxRuntimeSeconds,
        /** Bloqueo de un trabajo en proceso; si el proceso muere, se libera al vencer. */
        public readonly int $lockSeconds,
        public readonly int $maxAttempts,
        /** Minutos sin ejecuciones del procesador para considerar que el Cron no está corriendo. */
        public readonly int $staleAfterMinutes,
    ) {
    }

    public static function fromEnv(Env $env): self
    {
        $settings = new self(
            maxRuntimeSeconds: $env->int('JOBS_MAX_RUNTIME_SECONDS', 50),
            lockSeconds: $env->int('JOBS_LOCK_SECONDS', 300),
            maxAttempts: $env->int('JOBS_MAX_ATTEMPTS', 5),
            staleAfterMinutes: $env->int('JOBS_STALE_AFTER_MINUTES', 15),
        );
        if ($settings->maxRuntimeSeconds < 5 || $settings->lockSeconds <= $settings->maxRuntimeSeconds
            || $settings->maxAttempts < 1 || $settings->maxAttempts > 20 || $settings->staleAfterMinutes < 5) {
            throw new ConfigurationException('La configuración de la cola (JOBS_*) no es válida: JOBS_LOCK_SECONDS debe ser mayor que JOBS_MAX_RUNTIME_SECONDS.');
        }

        return $settings;
    }

    public function backoffMinutes(int $attempt): int
    {
        return self::BACKOFF_MINUTES[min(max($attempt, 1), count(self::BACKOFF_MINUTES)) - 1];
    }
}
