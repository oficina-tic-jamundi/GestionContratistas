<?php

declare(strict_types=1);

namespace Sigcon\Config;

use Sigcon\Exceptions\ConfigurationException;

/**
 * Parámetros de sesión y seguridad (ADR-002).
 */
final class SecuritySettings
{
    private const MIN_SECRET_BYTES = 32;

    public function __construct(
        #[\SensitiveParameter]
        private readonly ?string $authSecret,
        public readonly int $sessionIdleMinutes,
        public readonly int $sessionAbsoluteHours,
        public readonly bool $cookieSecure,
        public readonly string $allowedOrigin,
    ) {
    }

    public static function fromEnv(Env $env, AppEnvironment $environment, string $appUrl): self
    {
        $secret = $env->nullableString('AUTH_SECRET');
        $cookieSecure = $env->bool('SESSION_COOKIE_SECURE', true);

        if ($environment->isProduction()) {
            if ($secret === null) {
                throw new ConfigurationException('AUTH_SECRET es obligatorio en producción.');
            }
            if (!$cookieSecure) {
                throw new ConfigurationException('SESSION_COOKIE_SECURE debe ser true en producción.');
            }
        }

        $idle = $env->int('SESSION_IDLE_MINUTES', 30);
        $absolute = $env->int('SESSION_ABSOLUTE_HOURS', 10);
        if ($idle < 5 || $absolute < 1 || $idle > $absolute * 60) {
            throw new ConfigurationException('Los tiempos de sesión no son válidos.');
        }

        return new self($secret, $idle, $absolute, $cookieSecure, self::originOf($appUrl));
    }

    /**
     * Clave binaria para HMAC. Se valida al usarla para que las rutas que no la necesitan
     * (ej. /health) funcionen aunque falte en desarrollo.
     */
    public function authSecret(): string
    {
        if ($this->authSecret === null) {
            throw new ConfigurationException('AUTH_SECRET no está configurado. Genérelo con: php bin/console key:generate');
        }
        $decoded = base64_decode($this->authSecret, true);
        if ($decoded === false || strlen($decoded) < self::MIN_SECRET_BYTES) {
            throw new ConfigurationException('AUTH_SECRET debe ser base64 de al menos 32 bytes.');
        }

        return $decoded;
    }

    private static function originOf(string $url): string
    {
        $parts = parse_url($url);
        if (!is_array($parts) || !isset($parts['scheme'], $parts['host'])) {
            throw new ConfigurationException('APP_URL no es una URL válida.');
        }
        $origin = strtolower($parts['scheme'] . '://' . $parts['host']);

        return isset($parts['port']) ? $origin . ':' . $parts['port'] : $origin;
    }

    /** @return array<string, mixed> */
    public function __debugInfo(): array
    {
        return ['authSecret' => '***', 'allowedOrigin' => $this->allowedOrigin];
    }
}
