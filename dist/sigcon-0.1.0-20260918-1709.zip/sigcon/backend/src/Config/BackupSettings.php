<?php

declare(strict_types=1);

namespace Sigcon\Config;

use Sigcon\Exceptions\ConfigurationException;

/** Parámetros de los backups de la base de datos (docs/deployment/backups.md). */
final class BackupSettings
{
    public function __construct(
        public readonly string $path,
        #[\SensitiveParameter]
        private readonly ?string $key,
        public readonly string $mysqldump,
        public readonly int $keepDaily,
        public readonly int $keepMonthly,
    ) {
    }

    public static function fromEnv(Env $env, string $defaultPath): self
    {
        $settings = new self(
            path: $env->string('BACKUP_PATH', $defaultPath),
            key: $env->nullableString('BACKUP_KEY'),
            mysqldump: $env->string('BACKUP_MYSQLDUMP_PATH', 'mysqldump'),
            keepDaily: $env->int('BACKUP_KEEP_DAILY', 30),
            keepMonthly: $env->int('BACKUP_KEEP_MONTHLY', 12),
        );
        if ($settings->keepDaily < 1 || $settings->keepMonthly < 0) {
            throw new ConfigurationException('BACKUP_KEEP_DAILY debe ser al menos 1 y BACKUP_KEEP_MONTHLY no puede ser negativo.');
        }

        return $settings;
    }

    /** Clave binaria de 32 bytes. Se valida al usarla: sin clave no se generan backups sin cifrar. */
    public function key(): string
    {
        if ($this->key === null) {
            throw new ConfigurationException('BACKUP_KEY no está configurada. Genérela con: php bin/console backup:key');
        }
        $decoded = base64_decode($this->key, true);
        if ($decoded === false || strlen($decoded) !== SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES) {
            throw new ConfigurationException('BACKUP_KEY debe ser base64 de exactamente 32 bytes.');
        }

        return $decoded;
    }
}
