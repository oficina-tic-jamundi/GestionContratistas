<?php

declare(strict_types=1);

namespace Sigcon\Security;

use Sigcon\Exceptions\AuthenticationException;
use Sigcon\Exceptions\AuthorizationException;
use Sigcon\Models\Session;
use Sigcon\Models\User;

/**
 * Usuario autenticado de la solicitud actual. Lo llena AuthenticateMiddleware.
 * PHP atiende una solicitud por proceso, así que una instancia compartida es segura.
 */
final class AuthContext
{
    private ?User $user = null;
    private ?Session $session = null;
    private ?string $sessionToken = null;

    /** @var array<string, true> */
    private array $permissions = [];

    /** @var list<string> */
    private array $roles = [];

    /**
     * @param list<string> $roles
     * @param list<string> $permissions
     */
    public function authenticate(
        User $user,
        Session $session,
        #[\SensitiveParameter] string $sessionToken,
        array $roles,
        array $permissions,
    ): void {
        $this->user = $user;
        $this->session = $session;
        $this->sessionToken = $sessionToken;
        $this->roles = $roles;
        $this->permissions = array_fill_keys($permissions, true);
    }

    public function isAuthenticated(): bool
    {
        return $this->user !== null;
    }

    public function user(): User
    {
        return $this->user ?? throw new AuthenticationException('Debe iniciar sesión.');
    }

    public function userId(): ?int
    {
        return $this->user?->id;
    }

    public function session(): Session
    {
        return $this->session ?? throw new AuthenticationException('Debe iniciar sesión.');
    }

    public function sessionToken(): string
    {
        return $this->sessionToken ?? throw new AuthenticationException('Debe iniciar sesión.');
    }

    /** @return list<string> */
    public function roles(): array
    {
        return $this->roles;
    }

    /** @return list<string> */
    public function permissions(): array
    {
        return array_keys($this->permissions);
    }

    public function can(Permission $permission): bool
    {
        return isset($this->permissions[$permission->value]);
    }

    public function require(Permission ...$permissions): void
    {
        foreach ($permissions as $permission) {
            if (!$this->can($permission)) {
                throw new AuthorizationException('No tiene permiso para realizar esta acción.', [], sprintf('Falta el permiso %s', $permission->value));
            }
        }
    }
}
