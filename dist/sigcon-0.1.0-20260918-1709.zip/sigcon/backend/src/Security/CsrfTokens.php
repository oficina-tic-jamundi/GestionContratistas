<?php

declare(strict_types=1);

namespace Sigcon\Security;

use Sigcon\Config\SecuritySettings;

/**
 * Token CSRF derivado de la sesión: HMAC-SHA256(AUTH_SECRET, token de sesión).
 *
 * No se almacena: se recalcula en cada petición y cambia cuando cambia la sesión.
 * Un sitio externo no puede leerlo (Same-Origin Policy) ni calcularlo (no conoce el secreto
 * ni el token de sesión, que es HttpOnly).
 */
final class CsrfTokens
{
    public const HEADER = 'X-CSRF-Token';

    public function __construct(private readonly SecuritySettings $settings)
    {
    }

    public function forSession(#[\SensitiveParameter] string $sessionToken): string
    {
        return hash_hmac('sha256', 'csrf|' . $sessionToken, $this->settings->authSecret());
    }

    public function isValid(#[\SensitiveParameter] string $sessionToken, #[\SensitiveParameter] string $provided): bool
    {
        return $provided !== '' && hash_equals($this->forSession($sessionToken), $provided);
    }
}
