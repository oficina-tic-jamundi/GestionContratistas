<?php

declare(strict_types=1);

namespace Sigcon\Security;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Sigcon\Config\SecuritySettings;

/**
 * Cookie de sesión (ADR-002).
 *
 * Con HTTPS usa el prefijo __Host- (exige Secure, Path=/ y sin Domain: un subdominio no
 * puede sobrescribirla). En desarrollo sobre http://localhost se usa un nombre sin prefijo.
 */
final class SessionCookie
{
    public function __construct(private readonly SecuritySettings $settings)
    {
    }

    public function name(): string
    {
        return $this->settings->cookieSecure ? '__Host-sigcon_session' : 'sigcon_session';
    }

    public function read(ServerRequestInterface $request): ?string
    {
        $value = $request->getCookieParams()[$this->name()] ?? null;

        // El token es hexadecimal de 64 caracteres; cualquier otra cosa se ignora.
        return is_string($value) && preg_match('/^[a-f0-9]{64}$/', $value) === 1 ? $value : null;
    }

    public function attach(ResponseInterface $response, #[\SensitiveParameter] string $token): ResponseInterface
    {
        return $response->withAddedHeader(
            'Set-Cookie',
            $this->build($token, $this->settings->sessionAbsoluteHours * 3600),
        );
    }

    public function clear(ResponseInterface $response): ResponseInterface
    {
        return $response->withAddedHeader('Set-Cookie', $this->build('', 0));
    }

    private function build(string $value, int $maxAge): string
    {
        $parts = [
            $this->name() . '=' . $value,
            'Path=/',
            'Max-Age=' . $maxAge,
            'HttpOnly',
            'SameSite=Lax',
        ];
        if ($this->settings->cookieSecure) {
            $parts[] = 'Secure';
        }

        return implode('; ', $parts);
    }
}
