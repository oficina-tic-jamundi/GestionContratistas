<?php

declare(strict_types=1);

namespace Sigcon\Security;

/**
 * Hash de contraseñas: Argon2id si el PHP del servidor lo soporta, bcrypt (costo 12) si no.
 *
 * Parámetros Argon2id: mínimo recomendado por OWASP (m=19 MiB, t=2, p=1). Los valores por
 * defecto de PHP (64 MiB, t=4) tardan ~0,5 s por intento: en hosting compartido eso agota
 * memoria/CPU y facilita la denegación de servicio con intentos de login masivos.
 * Si se cambian, los hashes existentes se actualizan solos al iniciar sesión (needsRehash).
 */
final class PasswordHasher
{
    /**
     * Hashes de una contraseña aleatoria descartada. Se verifican cuando el usuario no existe
     * para que el tiempo de respuesta no revele si una cuenta existe (anti-enumeración).
     */
    private const DUMMY_ARGON2ID = '$argon2id$v=19$m=19456,t=2,p=1$dTl0TWxZWTZaVk9hVnBuaw$BKYvLvPBDPpuTSwueVAF7y/FfS+ADZXEULYTgOo+sh4';
    private const DUMMY_BCRYPT = '$2y$12$kwWKoVQ9Ai/1WJo9qHOtx.Y5aYSlCmvDFU5CsLr4Deq8AtT.dw.t2';

    private readonly string $algorithm;

    /** @var array<string, int> */
    private readonly array $options;

    public function __construct()
    {
        if (defined('PASSWORD_ARGON2ID')) {
            $this->algorithm = PASSWORD_ARGON2ID;
            $this->options = ['memory_cost' => 19456, 'time_cost' => 2, 'threads' => 1];
        } else {
            $this->algorithm = PASSWORD_BCRYPT;
            $this->options = ['cost' => 12];
        }
    }

    public function hash(#[\SensitiveParameter] string $password): string
    {
        return password_hash($password, $this->algorithm, $this->options);
    }

    public function verify(#[\SensitiveParameter] string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    public function needsRehash(string $hash): bool
    {
        return password_needs_rehash($hash, $this->algorithm, $this->options);
    }

    /** Consume un tiempo equivalente a una verificación real. Siempre devuelve false. */
    public function verifyAgainstDummy(#[\SensitiveParameter] string $password): bool
    {
        password_verify($password, $this->algorithm === PASSWORD_BCRYPT ? self::DUMMY_BCRYPT : self::DUMMY_ARGON2ID);

        return false;
    }
}
