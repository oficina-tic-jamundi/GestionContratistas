<?php

declare(strict_types=1);

namespace Sigcon\Security;

/**
 * Política de contraseñas, alineada con NIST SP 800-63B: se prioriza la longitud y se
 * rechazan contraseñas comunes o derivadas del correo, en lugar de exigir combinaciones
 * arbitrarias de símbolos.
 */
final class PasswordPolicy
{
    public const MIN_LENGTH = 12;
    public const MAX_LENGTH = 128;

    /** Contraseñas y patrones frecuentes (en minúsculas). Lista corta, sin dependencia externa. */
    private const COMMON = [
        '123456789012', '1234567890123', 'qwertyuiopas', 'contrasena123', 'contraseña123',
        'password1234', 'password12345', 'passwordpassword', 'administrador', 'administrador1',
        'alcaldiajamundi', 'jamundi123456', 'jamundi2026', 'sigcon123456', 'sigcon2026',
        'colombia12345', 'colombia2026', 'bienvenido123', 'bienvenido2026', 'cambiar123456',
        'temporal123456', 'aaaaaaaaaaaa', '111111111111', '000000000000', 'abcdefghijkl',
        'iloveyou1234', 'qwerty123456', 'abc123456789', 'contrasenasegura', 'passw0rd1234',
    ];

    /**
     * @return list<string> Mensajes de incumplimiento (vacío si la contraseña es aceptable).
     */
    public function violations(#[\SensitiveParameter] string $password, ?string $email = null): array
    {
        $violations = [];
        $length = mb_strlen($password);

        if ($length < self::MIN_LENGTH) {
            $violations[] = sprintf('La contraseña debe tener al menos %d caracteres.', self::MIN_LENGTH);
        }
        if ($length > self::MAX_LENGTH) {
            $violations[] = sprintf('La contraseña no puede superar %d caracteres.', self::MAX_LENGTH);
        }

        $normalized = mb_strtolower($password);
        if (in_array($normalized, self::COMMON, true) || preg_match('/^(.)\1+$/u', $password) === 1) {
            $violations[] = 'La contraseña es demasiado común. Use una frase o combinación menos predecible.';
        }

        if ($email !== null) {
            $localPart = mb_strtolower(explode('@', $email)[0]);
            if (mb_strlen($localPart) >= 4 && str_contains($normalized, $localPart)) {
                $violations[] = 'La contraseña no debe contener su usuario de correo.';
            }
        }

        return $violations;
    }

    /**
     * Contraseña temporal aleatoria (asignada por un administrador). Evita caracteres
     * ambiguos (0/O, 1/l/I) para que pueda dictarse o transcribirse sin errores.
     */
    public function generateTemporary(int $length = 16): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
        $max = strlen($alphabet) - 1;
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $password .= $alphabet[random_int(0, $max)];
        }

        return $password;
    }
}
