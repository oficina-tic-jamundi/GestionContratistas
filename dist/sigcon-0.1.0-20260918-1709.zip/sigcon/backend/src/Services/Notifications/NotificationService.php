<?php

declare(strict_types=1);

namespace Sigcon\Services\Notifications;

use Sigcon\Exceptions\NotFoundException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\User;
use Sigcon\Repositories\NotificationRepository;
use Sigcon\Repositories\UserRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;

/**
 * Notificaciones dentro de SIGCON (ADR-019).
 *
 * - Se crean en la MISMA transacción del evento: existen si y solo si el cambio se confirmó.
 * - Quien realiza la acción no se notifica a sí mismo.
 * - El enlace es siempre una ruta interna; el contenido no incluye datos sensibles.
 * - Cada usuario solo ve y marca sus propias notificaciones.
 */
final class NotificationService
{
    public function __construct(
        private readonly NotificationRepository $notifications,
        private readonly UserRepository $users,
        private readonly AuthContext $auth,
        private readonly Clock $clock,
    ) {
    }

    /** @param list<int|null> $userIds */
    public function notify(array $userIds, string $type, string $title, ?string $body, ?string $link): void
    {
        if ($link !== null && (!str_starts_with($link, '/') || str_starts_with($link, '//'))) {
            throw new \InvalidArgumentException('El enlace de una notificación debe ser una ruta interna.');
        }
        $actor = $this->auth->userId();
        $now = $this->clock->now();
        foreach (array_unique(array_filter($userIds, static fn (?int $id) => $id !== null)) as $userId) {
            if ($userId === $actor) {
                continue;
            }
            $this->notifications->insert(Uuid::v4(), $userId, $type, mb_substr($title, 0, 200), $body === null ? null : mb_substr($body, 0, 1000), $link, $now);
        }
    }

    /** Notifica a todos los usuarios activos con el permiso (p. ej. quienes aprueban pagos). */
    public function notifyPermission(Permission $permission, string $type, string $title, ?string $body, ?string $link): void
    {
        $this->notify(
            array_map(static fn (User $u) => $u->id, $this->users->activeWithPermission($permission->value)),
            $type,
            $title,
            $body,
            $link,
        );
    }

    /**
     * @return Page<array{uuid: string, type: string, title: string, body: ?string, link_path: ?string, read_at: ?\DateTimeImmutable, created_at: \DateTimeImmutable}>
     */
    public function mine(bool $unreadOnly, PageRequest $page): Page
    {
        return $this->notifications->forUser($this->userId(), $unreadOnly, $page);
    }

    public function unreadCount(): int
    {
        return $this->notifications->unreadCount($this->userId());
    }

    public function markRead(string $uuid): void
    {
        if (!Uuid::isValid($uuid) || !$this->notifications->markRead($uuid, $this->userId(), $this->clock->now())) {
            throw new NotFoundException('La notificación no existe.');
        }
    }

    public function markAllRead(): int
    {
        return $this->notifications->markAllRead($this->userId(), $this->clock->now());
    }

    private function userId(): int
    {
        return (int) $this->auth->userId();
    }
}
