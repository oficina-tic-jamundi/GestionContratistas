<?php

declare(strict_types=1);

namespace Sigcon\Services\History;

use Sigcon\Helpers\Clock;
use Sigcon\Repositories\BusinessHistoryRepository;
use Sigcon\Security\AuthContext;

/**
 * Registra eventos del historial de negocio (§42). Usa la misma conexión que los servicios:
 * dentro de una transacción, el evento se confirma o revierte junto con el cambio.
 */
final class HistoryRecorder
{
    public const CONTRACT = 'contract';

    public function __construct(
        private readonly BusinessHistoryRepository $repository,
        private readonly AuthContext $auth,
        private readonly Clock $clock,
    ) {
    }

    /** @param array<string, mixed> $metadata */
    public function record(
        string $entityType,
        int $entityId,
        string $event,
        string $summary,
        ?string $comment = null,
        ?string $fromStatus = null,
        ?string $toStatus = null,
        array $metadata = [],
    ): void {
        $this->repository->insert(
            $entityType,
            $entityId,
            $event,
            $summary,
            $comment,
            $fromStatus,
            $toStatus,
            $this->auth->userId(),
            $this->clock->now(),
            $metadata === [] ? null : $metadata,
        );
    }
}
