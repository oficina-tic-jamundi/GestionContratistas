<?php

declare(strict_types=1);

namespace Sigcon\Services\Activities;

/**
 * Promedio ponderado del avance (ADR-013), con aritmética entera en centésimas:
 * sin errores de coma flotante y sin depender de la extensión bcmath.
 *
 *   avance_padre = Σ(avance_hijo × peso_hijo) / Σ(peso_hijo)
 */
final class ProgressCalculator
{
    /**
     * @param list<array{progress: string, weight: string}> $children valores decimales como texto
     * @return string avance con 2 decimales ("0.00" si no hay hijos)
     */
    public static function weightedAverage(array $children): string
    {
        $sumWeights = 0;
        $sumProduct = 0;
        foreach ($children as $child) {
            $weight = self::toHundredths($child['weight']);
            $sumWeights += $weight;
            $sumProduct += self::toHundredths($child['progress']) * $weight;
        }
        if ($sumWeights === 0) {
            return '0.00';
        }
        // Redondeo "mitad hacia arriba" en centésimas.
        $result = intdiv(2 * $sumProduct + $sumWeights, 2 * $sumWeights);

        return self::fromHundredths(min(10000, max(0, $result)));
    }

    public static function toHundredths(string $decimal): int
    {
        if (preg_match('/^(\d+)(?:\.(\d{1,2}))?$/', $decimal, $m) !== 1) {
            throw new \InvalidArgumentException(sprintf('Decimal no válido: %s', $decimal));
        }

        return (int) $m[1] * 100 + (int) str_pad($m[2] ?? '', 2, '0');
    }

    public static function fromHundredths(int $value): string
    {
        return sprintf('%d.%02d', intdiv($value, 100), $value % 100);
    }
}
