<?php

declare(strict_types=1);

namespace Sigcon\Services\Exports;

use DateTimeZone;
use Sigcon\Database\Database;
use Sigcon\Exceptions\AuthorizationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\DateTimes;
use Sigcon\Helpers\Money;
use Sigcon\Models\ContractStatus;
use Sigcon\Models\PaymentStatus;
use Sigcon\Repositories\ContractScope;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Activities\ProgressCalculator;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;

/**
 * Reportes exportables en CSV (ADR-019), siempre dentro del alcance del usuario.
 * Cada exportación se audita: es una salida masiva de información.
 */
final class ExportService
{
    public const MAX_ROWS = 20000;

    public function __construct(
        private readonly Database $db,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly Clock $clock,
    ) {
    }

    /** @return array{name: string, content: string} */
    public function contracts(): array
    {
        $this->authorize();
        [$scope, $params] = ContractScope::forUser($this->auth)->toSql();
        $rows = $this->db->fetchAll(sprintf(
            "SELECT c.id, c.contract_number, c.object, c.status, c.start_date, c.end_date, c.total_value,
                    ct.name AS contractor, ct.document_type, ct.document_number, d.name AS department,
                    CONCAT(s.first_name, ' ', s.last_name) AS supervisor,
                    COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.contract_id = c.id AND p.status <> 'cancelled'), 0) AS committed,
                    COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.contract_id = c.id AND p.status = 'paid'), 0) AS paid
             FROM contracts c
             JOIN contractors ct ON ct.id = c.contractor_id
             JOIN departments d ON d.id = c.department_id
             LEFT JOIN users s ON s.id = c.supervisor_user_id
             WHERE c.deleted_at IS NULL AND %s
             ORDER BY c.contract_number LIMIT %d",
            $scope,
            self::MAX_ROWS,
        ), $params);

        $progress = $this->progressByContract(array_map(static fn (array $r) => (int) $r['id'], $rows));
        $csv = CsvWriter::build(
            ['Número', 'Objeto', 'Contratista', 'Documento', 'Dependencia', 'Supervisor', 'Estado', 'Inicio', 'Terminación',
                'Valor', 'Comprometido', 'Pagado', 'Saldo', 'Avance (%)'],
            array_map(static function (array $r) use ($progress): array {
                $total = Money::toCents(self::decimal($r['total_value']));
                $committed = Money::toCents(self::decimal($r['committed']));

                return [
                    (string) $r['contract_number'],
                    (string) $r['object'],
                    (string) $r['contractor'],
                    $r['document_type'] . ' ' . $r['document_number'],
                    (string) $r['department'],
                    $r['supervisor'] === null ? '' : (string) $r['supervisor'],
                    ContractStatus::from((string) $r['status'])->label(),
                    self::date((string) $r['start_date']),
                    self::date((string) $r['end_date']),
                    self::number(self::decimal($r['total_value'])),
                    self::number(self::decimal($r['committed'])),
                    self::number(self::decimal($r['paid'])),
                    self::number(Money::fromCents($total - $committed)),
                    self::number($progress[(int) $r['id']] ?? '0.00'),
                ];
            }, $rows),
        );
        $this->audit->record(AuditAction::ExportGenerated, 'export', 'contracts', ['rows' => count($rows)]);

        return ['name' => $this->fileName('contratos'), 'content' => $csv];
    }

    /** @return array{name: string, content: string} */
    public function payments(?PaymentStatus $status): array
    {
        $this->authorize();
        [$scope, $params] = ContractScope::forUser($this->auth)->toSql();
        $filter = '';
        if ($status !== null) {
            $filter = ' AND p.status = :status';
            $params['status'] = $status->value;
        }
        $rows = $this->db->fetchAll(sprintf(
            'SELECT p.number, p.amount, p.status, p.approved_at, p.payment_date, p.payment_reference, p.created_at,
                    c.contract_number, ct.name AS contractor, r.number AS report_number, r.period_start, r.period_end
             FROM payments p
             JOIN contracts c ON c.id = p.contract_id
             JOIN contractors ct ON ct.id = c.contractor_id
             JOIN reports r ON r.id = p.report_id
             WHERE c.deleted_at IS NULL AND %s%s
             ORDER BY c.contract_number, p.number LIMIT %d',
            $scope,
            $filter,
            self::MAX_ROWS,
        ), $params);

        $tz = new DateTimeZone(date_default_timezone_get());
        $csv = CsvWriter::build(
            ['Contrato', 'Contratista', 'Pago N.°', 'Informe N.°', 'Período desde', 'Período hasta', 'Valor', 'Estado',
                'Registrado', 'Aprobado', 'Fecha de pago', 'Comprobante'],
            array_map(static fn (array $r) => [
                (string) $r['contract_number'],
                (string) $r['contractor'],
                (int) $r['number'],
                (int) $r['report_number'],
                self::date((string) $r['period_start']),
                self::date((string) $r['period_end']),
                self::number(self::decimal($r['amount'])),
                PaymentStatus::from((string) $r['status'])->label(),
                DateTimes::fromDb((string) $r['created_at'])->setTimezone($tz)->format('d/m/Y H:i'),
                $r['approved_at'] === null ? '' : DateTimes::fromDb((string) $r['approved_at'])->setTimezone($tz)->format('d/m/Y H:i'),
                $r['payment_date'] === null ? '' : self::date((string) $r['payment_date']),
                $r['payment_reference'] === null ? '' : (string) $r['payment_reference'],
            ], $rows),
        );
        $this->audit->record(AuditAction::ExportGenerated, 'export', 'payments', ['rows' => count($rows), 'status' => $status?->value]);

        return ['name' => $this->fileName('pagos'), 'content' => $csv];
    }

    private function authorize(): void
    {
        if (!$this->auth->can(Permission::ExportsRun)) {
            throw new AuthorizationException('No tiene permiso para exportar reportes.');
        }
    }

    /**
     * Avance global de cada contrato (promedio ponderado de sus obligaciones, ADR-013).
     *
     * @param list<int> $ids
     * @return array<int, string>
     */
    private function progressByContract(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        $values = [];
        foreach (array_chunk($ids, 500) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '?'));
            foreach ($this->db->fetchAll("SELECT contract_id, progress, weight FROM activities WHERE parent_id IS NULL AND contract_id IN ({$placeholders})", $chunk) as $row) {
                $values[(int) $row['contract_id']][] = ['progress' => (string) $row['progress'], 'weight' => (string) $row['weight']];
            }
        }

        return array_map(static fn (array $v) => ProgressCalculator::weightedAverage($v), $values);
    }

    private function fileName(string $what): string
    {
        return sprintf('sigcon-%s-%s.csv', $what, $this->clock->now()->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('Ymd-His'));
    }

    /** Valor decimal de MySQL normalizado a dos decimales ("2500000.00"). */
    private static function decimal(mixed $value): string
    {
        return Money::fromCents(Money::toCents((string) $value));
    }

    /** Número para Excel en español: coma decimal, sin separador de miles. */
    private static function number(string $decimal): string
    {
        return str_replace('.', ',', $decimal);
    }

    private static function date(string $ymd): string
    {
        return preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $ymd, $m) === 1 ? "{$m[3]}/{$m[2]}/{$m[1]}" : '';
    }
}
