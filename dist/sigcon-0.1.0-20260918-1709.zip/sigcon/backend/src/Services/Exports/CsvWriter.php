<?php

declare(strict_types=1);

namespace Sigcon\Services\Exports;

/**
 * CSV para Excel en español (Colombia): separador ";", UTF-8 con BOM y fin de línea CRLF.
 *
 * Protección contra inyección de fórmulas (CSV injection): una celda que empieza por
 * = + - @ o un carácter de control se antepone con un apóstrofo, de modo que Excel la muestra
 * como texto y no la ejecuta. Los valores numéricos puros no se alteran.
 */
final class CsvWriter
{
    /**
     * @param list<string> $header
     * @param iterable<list<string|int|null>> $rows
     */
    public static function build(array $header, iterable $rows): string
    {
        $out = "\xEF\xBB\xBF" . self::line($header);
        foreach ($rows as $row) {
            $out .= self::line($row);
        }

        return $out;
    }

    /** @param list<string|int|null> $cells */
    private static function line(array $cells): string
    {
        return implode(';', array_map(self::cell(...), $cells)) . "\r\n";
    }

    public static function cell(string|int|null $value): string
    {
        $text = (string) $value;
        if ($text !== '' && !is_numeric($text) && preg_match('/^[=+\-@\t\r]/', $text) === 1) {
            $text = "'" . $text;
        }
        if (preg_match('/[;"\r\n]/', $text) === 1) {
            $text = '"' . str_replace('"', '""', $text) . '"';
        }

        return $text;
    }
}
