<?php

declare(strict_types=1);

namespace Sigcon\Services\AI;

/**
 * Proveedor por defecto: la IA NO está habilitada (ADR-008). Nunca simula resultados:
 * responde explícitamente que la funcionalidad no está disponible.
 */
final class DisabledAIProvider implements AIProviderInterface
{
    public function isEnabled(): bool
    {
        return false;
    }

    public function complete(AiRequest $request): AiResponse
    {
        throw new FeatureDisabledException('La funcionalidad de inteligencia artificial no está habilitada en SIGCON. Su habilitación requiere una decisión institucional (ADR-008).');
    }
}
