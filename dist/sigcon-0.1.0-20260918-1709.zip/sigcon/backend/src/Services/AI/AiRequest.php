<?php

declare(strict_types=1);

namespace Sigcon\Services\AI;

/**
 * Solicitud a un proveedor de IA. El contenido debe llegar YA MINIMIZADO: sin documentos de
 * identidad, correos, teléfonos, direcciones ni coordenadas (ADR-008).
 */
final class AiRequest
{
    public function __construct(
        /** Propósito auditable, p. ej. "report.summary_review". */
        public readonly string $purpose,
        public readonly string $instructions,
        public readonly string $content,
        public readonly int $maxOutputTokens = 800,
    ) {
    }
}
