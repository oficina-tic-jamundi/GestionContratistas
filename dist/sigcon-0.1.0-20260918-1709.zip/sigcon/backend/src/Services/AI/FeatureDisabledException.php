<?php

declare(strict_types=1);

namespace Sigcon\Services\AI;

use Sigcon\Exceptions\AppException;

/** Funcionalidad no habilitada por decisión institucional (no es una falla técnica). */
final class FeatureDisabledException extends AppException
{
    public function statusCode(): int
    {
        return 503;
    }

    public function errorCode(): string
    {
        return 'feature_disabled';
    }
}
