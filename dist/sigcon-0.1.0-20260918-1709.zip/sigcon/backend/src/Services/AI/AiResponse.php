<?php

declare(strict_types=1);

namespace Sigcon\Services\AI;

final class AiResponse
{
    public function __construct(
        public readonly string $text,
        public readonly string $provider,
        public readonly string $model,
    ) {
    }
}
