<?php

declare(strict_types=1);

namespace Sigcon\Services\AI;

use Sigcon\Models\Contract;
use Sigcon\Models\Report;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;

/**
 * Servicio de dominio preparado para IA (ADR-008): revisión de redacción de un informe.
 *
 * Define la MINIMIZACIÓN de datos: solo se enviaría el texto del informe (resumen y
 * descripciones por obligación). Nunca el nombre ni el documento del contratista, correos,
 * coordenadas, fotografías, valores ni anexos. Mientras el proveedor esté deshabilitado,
 * no se construye ni se envía nada.
 */
final class ReportAssistant
{
    private const INSTRUCTIONS = 'Revise la redacción del siguiente informe de actividades de un contrato de prestación '
        . 'de servicios de una entidad pública colombiana. Señale ambigüedades y actividades sin resultado verificable. '
        . 'No invente información ni evalúe el cumplimiento contractual.';

    public function __construct(
        private readonly AIProviderInterface $provider,
        private readonly AuditLogger $audit,
    ) {
    }

    public function isAvailable(): bool
    {
        return $this->provider->isEnabled();
    }

    /**
     * @param array<string, mixed> $content contenido del informe (ReportService)
     */
    public function reviewWriting(Report $report, Contract $contract, array $content): AiResponse
    {
        if (!$this->provider->isEnabled()) {
            // Se delega al proveedor deshabilitado para que el mensaje sea el oficial.
            return $this->provider->complete(new AiRequest('report.writing_review', '', ''));
        }
        $request = new AiRequest('report.writing_review', self::INSTRUCTIONS, self::minimize($content));
        $this->audit->record(AuditAction::AiRequested, 'report', $report->uuid, [
            'purpose' => $request->purpose,
            'contract' => $contract->uuid,
            'characters' => mb_strlen($request->content),
        ]);

        return $this->provider->complete($request);
    }

    /**
     * Texto que se enviaría: resumen y descripciones, sin datos personales ni contractuales.
     *
     * @param array<string, mixed> $content
     */
    public static function minimize(array $content): string
    {
        $parts = ['Resumen: ' . (string) ($content['summary'] ?? '')];
        foreach ((array) ($content['items'] ?? []) as $i => $item) {
            if (is_array($item)) {
                $parts[] = sprintf('Obligación %d: %s. Lo realizado: %s', (int) $i + 1, (string) ($item['title'] ?? ''), (string) ($item['description'] ?? '(sin descripción)'));
            }
        }

        return implode("\n", $parts);
    }
}
