<?php

declare(strict_types=1);

namespace Sigcon\Services\AI;

/**
 * Proveedor de inteligencia artificial intercambiable (ADR-008).
 *
 * Hoy la única implementación es DisabledAIProvider. Habilitar un proveedor real exige un ADR
 * institucional (proveedor, base legal y tratamiento de datos personales según la Ley 1581 de
 * 2012, minimización, retención y quién puede usarlo) y registrar cada consulta en la auditoría.
 */
interface AIProviderInterface
{
    public function isEnabled(): bool;

    /**
     * @throws FeatureDisabledException si el proveedor no está habilitado
     */
    public function complete(AiRequest $request): AiResponse;
}
