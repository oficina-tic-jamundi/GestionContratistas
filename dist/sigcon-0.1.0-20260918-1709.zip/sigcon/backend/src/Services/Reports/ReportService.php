<?php

declare(strict_types=1);

namespace Sigcon\Services\Reports;

use DateTimeImmutable;
use DateTimeZone;
use Sigcon\Database\Database;
use Sigcon\Exceptions\AuthorizationException;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Activity;
use Sigcon\Models\ActivityLevel;
use Sigcon\Models\Contract;
use Sigcon\Models\Document;
use Sigcon\Models\Report;
use Sigcon\Models\ReportStatus;
use Sigcon\Models\HistoryEntry;
use Sigcon\Models\PaymentStatus;
use Sigcon\Repositories\ActivityRepository;
use Sigcon\Repositories\BusinessHistoryRepository;
use Sigcon\Repositories\ContractScope;
use Sigcon\Repositories\DocumentRepository;
use Sigcon\Repositories\EvidenceRepository;
use Sigcon\Repositories\PaymentRepository;
use Sigcon\Repositories\ReportRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Storage\FileStorage;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Contracts\ContractService;
use Sigcon\Services\History\HistoryRecorder;
use Sigcon\Services\Jobs\JobQueue;
use Sigcon\Services\Notifications\NotificationService;
use Sigcon\Services\Reports\Pdf\ReportPdfHandler;

/**
 * Informes del contratista: elaboración, envío con versión inmutable, revisión, observaciones,
 * aprobación, rechazo y reapertura controlada (ADR-015). Las reglas de acceso están en ReportAccess.
 *
 * Toda decisión se toma con el informe bloqueado (FOR UPDATE) y se evalúa contra su estado real:
 * dos supervisores (o dos pestañas) no pueden aprobar dos veces ni decidir sobre un estado viejo.
 */
final class ReportService
{
    public const ENTITY = 'report';

    public function __construct(
        private readonly ReportRepository $reports,
        private readonly ActivityRepository $activities,
        private readonly DocumentRepository $documents,
        private readonly EvidenceRepository $evidences,
        private readonly PaymentRepository $payments,
        private readonly FileStorage $storage,
        private readonly ContractService $contracts,
        private readonly ReportAccess $access,
        private readonly HistoryRecorder $history,
        private readonly BusinessHistoryRepository $historyRepository,
        private readonly AuditLogger $audit,
        private readonly JobQueue $queue,
        private readonly NotificationService $notifications,
        private readonly AuthContext $auth,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /**
     * @param list<ReportStatus> $statuses vacío = todos
     * @return Page<Report>
     */
    public function list(array $statuses, ?string $contractUuid, PageRequest $page): Page
    {
        return $this->reports->paginate($statuses, $contractUuid, $page, ContractScope::forUser($this->auth), $this->access->draftOwnerFilter());
    }

    /** @return array{report: Report, contract: Contract} */
    public function get(string $uuid): array
    {
        $report = (Uuid::isValid($uuid) ? $this->reports->findByUuid($uuid) : null)
            ?? throw new NotFoundException('El informe no existe.');

        return ['report' => $report, 'contract' => $this->access->contractFor($report)];
    }

    /**
     * Vista completa del informe para la pantalla de detalle.
     *
     * @return array<string, mixed>
     */
    public function detail(string $uuid): array
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);

        return [
            'report' => $report,
            'contract' => $contract,
            'can' => $this->access->capabilities($report, $contract),
            'content' => $this->buildContent($report, $contract),
            'versions' => $this->reports->versions($report->id),
            'reviews' => $this->reports->reviews($report->id),
        ];
    }

    /** @return list<HistoryEntry> */
    public function history(string $uuid): array
    {
        return $this->historyRepository->forEntity(self::ENTITY, $this->get($uuid)['report']->id);
    }

    public function create(string $contractUuid, DateTimeImmutable $start, DateTimeImmutable $end): Report
    {
        $contract = $this->contracts->get($contractUuid);
        if (!$this->access->isAuthor($contract)) {
            throw new AuthorizationException('Solo el contratista del contrato puede elaborar sus informes.');
        }
        if (!$this->access->contractAllowsReporting($contract)) {
            throw new BusinessRuleException(sprintf('No se elaboran informes de un contrato %s.', mb_strtolower($contract->status->label())));
        }
        if ($start < $contract->startDate || $end > $contract->endDate) {
            throw ValidationException::field('period_start', 'out_of_contract', 'El período debe estar dentro del plazo del contrato.');
        }

        return $this->db->transaction(function () use ($contract, $start, $end): Report {
            $this->activities->lockContract($contract->id); // serializa el consecutivo y el cruce de períodos
            if ($this->reports->periodOverlaps($contract->id, $start, $end)) {
                throw ValidationException::field('period_start', 'overlap', 'El período se cruza con otro informe de este contrato.');
            }
            $uuid = Uuid::v4();
            $id = $this->reports->create($uuid, $contract->id, $this->reports->nextNumber($contract->id), $start, $end, (int) $this->auth->userId(), $this->clock->now());
            $this->history->record(self::ENTITY, $id, 'created', 'Informe creado en borrador', toStatus: ReportStatus::Draft->value);
            $this->audit->record(AuditAction::ReportCreated, 'report', $uuid, ['contract' => $contract->uuid, 'period' => $start->format('Y-m-d') . '/' . $end->format('Y-m-d')]);

            return $this->reload($id);
        });
    }

    /**
     * @param array<string, string> $items uuid de obligación => descripción de lo realizado
     */
    public function updateContent(string $uuid, ?string $summary, ?string $notes, array $items): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->canEdit($report, $contract)) {
            throw $this->cannotEdit($report, $contract);
        }
        $obligations = $this->obligationsByUuid($contract->id);
        $resolved = [];
        foreach ($items as $activityUuid => $description) {
            $obligation = $obligations[$activityUuid] ?? throw ValidationException::field('items', 'unknown_obligation', 'Una de las obligaciones no pertenece a este contrato.');
            if (trim($description) !== '') {
                $resolved[$obligation->id] = trim($description);
            }
        }

        return $this->db->transaction(function () use ($report, $summary, $notes, $resolved): Report {
            if (!($this->reports->lockStatus($report->id)?->isEditable() ?? false)) {
                throw new BusinessRuleException('El informe cambió de estado y ya no se puede editar.');
            }
            $now = $this->clock->now();
            $this->reports->updateContent($report->id, $summary, $notes, $now);
            $this->reports->replaceItems($report->id, $resolved, $now);

            return $this->reload($report->id);
        });
    }

    public function submit(string $uuid): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->canEdit($report, $contract)) {
            throw $this->cannotEdit($report, $contract);
        }
        $errors = [];
        if (mb_strlen(trim((string) $report->summary)) < 20) {
            $errors[] = ['field' => 'summary', 'code' => 'required', 'message' => 'Escriba un resumen de al menos 20 caracteres antes de enviar.'];
        }
        if ($this->reports->items($report->id) === []) {
            $errors[] = ['field' => 'items', 'code' => 'required', 'message' => 'Describa lo realizado en al menos una obligación.'];
        }
        if ($errors !== []) {
            throw ValidationException::withErrors($errors);
        }

        return $this->db->transaction(function () use ($report, $contract): Report {
            $current = $this->reports->lockStatus($report->id);
            if ($current === null || !$current->canBeSubmitted()) {
                throw new BusinessRuleException('El informe ya fue enviado.');
            }
            $version = $report->currentVersion + 1;
            $content = $this->buildContent($report, $contract);
            $json = self::canonicalJson($content);
            $hash = hash('sha256', $json);
            $now = $this->clock->now();
            $next = $current->submittedStatus();

            $this->reports->insertVersion($report->id, $version, $json, $hash, (int) $this->auth->userId(), $now);
            $this->reports->setSubmitted($report->id, $next, $version, $now);
            $this->history->record(self::ENTITY, $report->id, 'submitted', $next === ReportStatus::Resubmitted
                ? sprintf('Contratista reenvió el informe corregido (versión %d)', $version)
                : sprintf('Contratista envió el informe (versión %d)', $version), fromStatus: $current->value, toStatus: $next->value);
            $this->audit->record(AuditAction::ReportSubmitted, 'report', $report->uuid, ['version' => $version, 'content_hash' => $hash]);
            $this->queuePdf($report->id, $version);
            $this->notifications->notify(
                [$contract->supervisorId],
                $next === ReportStatus::Resubmitted ? 'report.resubmitted' : 'report.submitted',
                sprintf('%s: informe N.° %d %s', $contract->contractNumber, $report->number, $next === ReportStatus::Resubmitted ? 'corregido y reenviado' : 'enviado para revisión'),
                sprintf('%s envió la versión %d (período %s – %s).', $contract->contractorName, $version, $report->periodStart->format('d/m/Y'), $report->periodEnd->format('d/m/Y')),
                self::link($report->uuid),
            );

            return $this->reload($report->id);
        });
    }

    public function startReview(string $uuid): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->capabilities($report, $contract)['start_review']) {
            throw $this->reviewDenied($report, $contract);
        }

        return $this->decide($report, static fn (ReportStatus $s) => $s->awaitsReview(), function (Report $r, ReportStatus $current): void {
            $this->reports->setStatus($r->id, ReportStatus::InReview, $this->clock->now());
            $this->history->record(self::ENTITY, $r->id, 'review_started', 'Supervisor inició la revisión', fromStatus: $current->value, toStatus: ReportStatus::InReview->value);
            $this->audit->record(AuditAction::ReportReviewStarted, 'report', $r->uuid, ['version' => $r->currentVersion]);
        });
    }

    /**
     * @param list<array{activity: ?string, text: string}> $observations
     */
    public function observe(string $uuid, ?string $comment, array $observations): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->capabilities($report, $contract)['observe']) {
            throw $this->reviewDenied($report, $contract);
        }
        if (($comment === null || trim($comment) === '') && $observations === []) {
            throw ValidationException::field('observations', 'required', 'Escriba al menos una observación para el contratista.');
        }
        $obligations = $this->obligationsByUuid($contract->id);
        $resolved = [];
        foreach ($observations as $observation) {
            $activityId = null;
            if ($observation['activity'] !== null) {
                $activityId = ($obligations[$observation['activity']] ?? throw ValidationException::field('observations', 'unknown_obligation', 'Una observación se refiere a una obligación de otro contrato.'))->id;
            }
            $resolved[] = ['activity_id' => $activityId, 'text' => $observation['text']];
        }

        return $this->decide($report, static fn (ReportStatus $s) => $s === ReportStatus::InReview, function (Report $r) use ($comment, $resolved): void {
            $reviewId = $this->reports->insertReview(Uuid::v4(), $r->id, $r->currentVersion, 'observed', $comment, (int) $this->auth->userId(), $this->clock->now());
            foreach ($resolved as $o) {
                $this->reports->insertObservation($reviewId, $o['activity_id'], $o['text']);
            }
            $this->reports->setStatus($r->id, ReportStatus::Observed, $this->clock->now());
            $this->history->record(self::ENTITY, $r->id, 'observed', 'Supervisor solicitó correcciones', $comment, ReportStatus::InReview->value, ReportStatus::Observed->value, ['observations' => count($resolved)]);
            $this->audit->record(AuditAction::ReportObserved, 'report', $r->uuid, ['version' => $r->currentVersion, 'observations' => count($resolved)]);
            $this->notifyContractor($r, 'report.observed', 'tiene observaciones del supervisor', 'Revise las observaciones, corrija el informe y reenvíelo.');
        });
    }

    public function approve(string $uuid, ?string $comment): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->capabilities($report, $contract)['approve']) {
            throw $this->reviewDenied($report, $contract);
        }

        return $this->decide($report, static fn (ReportStatus $s) => $s === ReportStatus::InReview, function (Report $r) use ($comment): void {
            $now = $this->clock->now();
            $this->reports->insertReview(Uuid::v4(), $r->id, $r->currentVersion, 'approved', $comment, (int) $this->auth->userId(), $now);
            $this->reports->setApproved($r->id, $r->currentVersion, (int) $this->auth->userId(), $now);
            $this->history->record(self::ENTITY, $r->id, 'approved', sprintf('Supervisor aprobó el informe (versión %d)', $r->currentVersion), $comment, ReportStatus::InReview->value, ReportStatus::Approved->value);
            $this->audit->record(AuditAction::ReportApproved, 'report', $r->uuid, ['version' => $r->currentVersion]);
            $this->notifyContractor($r, 'report.approved', 'fue aprobado', sprintf('El supervisor aprobó la versión %d.', $r->currentVersion));
            $this->queuePdf($r->id, $r->currentVersion); // el PDF de la versión incluye la aprobación
            // La sincronización con el almacenamiento institucional (Google Drive) está diferida
            // por decisión de la Alcaldía (ADR-004): no se crea ninguna tarea ni se simula.
        });
    }

    public function reject(string $uuid, string $comment): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->capabilities($report, $contract)['reject']) {
            throw $this->reviewDenied($report, $contract);
        }

        return $this->decide($report, static fn (ReportStatus $s) => $s === ReportStatus::InReview, function (Report $r) use ($comment): void {
            $this->reports->insertReview(Uuid::v4(), $r->id, $r->currentVersion, 'rejected', $comment, (int) $this->auth->userId(), $this->clock->now());
            $this->reports->setStatus($r->id, ReportStatus::Rejected, $this->clock->now());
            $this->history->record(self::ENTITY, $r->id, 'rejected', 'Supervisor rechazó el informe', $comment, ReportStatus::InReview->value, ReportStatus::Rejected->value);
            $this->audit->record(AuditAction::ReportRejected, 'report', $r->uuid, ['version' => $r->currentVersion]);
            $this->notifyContractor($r, 'report.rejected', 'fue rechazado', 'Consulte el motivo. Para el mismo período debe elaborarse un informe nuevo.');
        });
    }

    public function reopen(string $uuid, string $reason): Report
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        if (!$this->access->capabilities($report, $contract)['reopen']) {
            throw $report->status === ReportStatus::Approved
                ? new AuthorizationException('No tiene permiso para reabrir informes aprobados.')
                : new BusinessRuleException('Solo se reabren informes aprobados.');
        }
        // Un informe que sustenta un pago aprobado o pagado no se reabre (trazabilidad del pago).
        $payment = $this->payments->activeForReport($report->id);
        if ($payment !== null && in_array($payment->status, [PaymentStatus::Approved, PaymentStatus::Paid], true)) {
            throw new BusinessRuleException(sprintf('El informe sustenta el pago N.° %d, que está "%s"; no se puede reabrir.', $payment->number, $payment->status->label()));
        }

        return $this->decide($report, static fn (ReportStatus $s) => $s === ReportStatus::Approved, function (Report $r) use ($reason): void {
            $this->reports->insertReview(Uuid::v4(), $r->id, $r->currentVersion, 'reopened', $reason, (int) $this->auth->userId(), $this->clock->now());
            $this->reports->reopen($r->id, $this->clock->now());
            $this->history->record(self::ENTITY, $r->id, 'reopened', sprintf('Informe reabierto (la aprobación de la versión %d queda en el historial)', (int) $r->approvedVersion), $reason, ReportStatus::Approved->value, ReportStatus::Observed->value);
            $this->audit->record(AuditAction::ReportReopened, 'report', $r->uuid, ['approved_version' => $r->approvedVersion, 'reason' => $reason]);
            $this->notifyContractor($r, 'report.reopened', 'fue reabierto', 'El informe aprobado se reabrió para correcciones. Consulte el motivo.');
            if ($r->approvedVersion !== null) {
                $this->queuePdf($r->id, $r->approvedVersion); // el PDF deja de mostrarse como aprobado
            }
        });
    }

    /** @return array{content: array<string, mixed>, content_hash: string, hash_valid: bool} */
    public function version(string $uuid, int $version): array
    {
        ['report' => $report] = $this->get($uuid);
        $row = $this->reports->versionContent($report->id, $version) ?? throw new NotFoundException('La versión no existe.');
        $content = json_decode($row['content'], true);

        return [
            'content' => is_array($content) ? $content : [],
            'content_hash' => $row['content_hash'],
            // Recalculado sobre el contenido guardado: detecta alteraciones directas en la base de datos.
            'hash_valid' => is_array($content) && hash_equals($row['content_hash'], hash('sha256', self::canonicalJson($content))),
        ];
    }

    /**
     * Qué cambió de una versión a la anterior.
     *
     * @return array{summary: bool, notes: bool, items: list<string>, documents_added: list<string>, documents_removed: list<string>}
     */
    public function changes(string $uuid, int $version): array
    {
        $current = $this->version($uuid, $version)['content'];
        $previous = $version > 1 ? $this->version($uuid, $version - 1)['content'] : [];

        $index = static function (array $content, string $key, string $by): array {
            $result = [];
            foreach (($content[$key] ?? []) as $row) {
                if (is_array($row) && isset($row[$by])) {
                    $result[(string) $row[$by]] = $row;
                }
            }

            return $result;
        };
        $currentItems = $index($current, 'items', 'obligation_uuid');
        $previousItems = $index($previous, 'items', 'obligation_uuid');
        $changedItems = [];
        foreach ($currentItems + $previousItems as $key => $item) {
            if (($currentItems[$key]['description'] ?? null) !== ($previousItems[$key]['description'] ?? null)) {
                $changedItems[] = (string) ($item['title'] ?? $key);
            }
        }
        $currentDocs = $index($current, 'documents', 'sha256');
        $previousDocs = $index($previous, 'documents', 'sha256');

        return [
            'summary' => ($current['summary'] ?? null) !== ($previous['summary'] ?? null),
            'notes' => ($current['contractor_notes'] ?? null) !== ($previous['contractor_notes'] ?? null),
            'items' => $changedItems,
            'documents_added' => array_values(array_map(static fn ($d) => (string) $d['name'], array_diff_key($currentDocs, $previousDocs))),
            'documents_removed' => array_values(array_map(static fn ($d) => (string) $d['name'], array_diff_key($previousDocs, $currentDocs))),
        ];
    }

    /**
     * Contenido del informe tal como se congela al enviarlo (y como se muestra mientras se edita).
     *
     * @return array<string, mixed>
     */
    private function buildContent(Report $report, Contract $contract): array
    {
        $tz = new DateTimeZone(date_default_timezone_get());
        $from = new DateTimeImmutable($report->periodStart->format('Y-m-d') . ' 00:00:00', $tz);
        $to = (new DateTimeImmutable($report->periodEnd->format('Y-m-d') . ' 00:00:00', $tz))->modify('+1 day');
        $updates = [];
        foreach ($this->reports->progressInPeriod($contract->id, $from->setTimezone(new DateTimeZone('UTC')), $to->setTimezone(new DateTimeZone('UTC'))) as $u) {
            $updates[$u['obligation_id']][] = [
                'activity' => $u['activity_title'],
                'from' => $u['previous'],
                'to' => $u['new'],
                'note' => $u['note'],
                'user' => $u['user'],
                'recorded_at' => $u['recorded_at']->setTimezone($tz)->format(DATE_ATOM),
            ];
        }
        $evidences = [];
        foreach ($this->evidences->activeInPeriod($contract->id, $from->setTimezone(new DateTimeZone('UTC')), $to->setTimezone(new DateTimeZone('UTC'))) as $row) {
            $e = $row['evidence'];
            $evidences[$row['obligation_id']][] = [
                'uuid' => $e->uuid,
                'activity' => $e->activityTitle,
                'description' => $e->description,
                'captured_at' => $e->capturedAt->setTimezone($tz)->format(DATE_ATOM),
                'location_status' => $e->locationStatus->value,
                'latitude' => $e->latitude,
                'longitude' => $e->longitude,
                'accuracy_m' => $e->accuracyM,
                'original_sha256' => $e->originalSha256,
                'official_sha256' => $e->officialSha256,
            ];
        }
        $descriptions = $this->reports->items($report->id);
        $items = [];
        foreach ($this->activities->forContract($contract->id) as $activity) {
            if ($activity->level !== ActivityLevel::Obligation) {
                continue;
            }
            $items[] = [
                'obligation_uuid' => $activity->uuid,
                'title' => $activity->title,
                'progress' => $activity->progress,
                'description' => $descriptions[$activity->id] ?? null,
                'progress_updates' => $updates[$activity->id] ?? [],
                'evidences' => $evidences[$activity->id] ?? [],
            ];
        }

        return [
            'report_number' => $report->number,
            'contract_number' => $contract->contractNumber,
            'contractor' => $contract->contractorName,
            'supervisor' => $contract->supervisorName,
            'period_start' => $report->periodStart->format('Y-m-d'),
            'period_end' => $report->periodEnd->format('Y-m-d'),
            'summary' => $report->summary,
            'contractor_notes' => $report->contractorNotes,
            'items' => $items,
            'documents' => array_values(array_map(static fn (Document $d) => [
                'uuid' => $d->uuid,
                'name' => $d->originalName,
                'type' => $d->typeName,
                'sha256' => $d->sha256,
                'size_bytes' => $d->sizeBytes,
            ], array_filter($this->documents->forEntity(self::ENTITY, $report->id), static fn (Document $d) => $d->isActive()))),
        ];
    }

    /**
     * Ejecuta una decisión con el informe bloqueado, validando el estado real.
     *
     * @param callable(ReportStatus): bool $allowed
     * @param callable(Report, ReportStatus): void $action
     */
    private function decide(Report $report, callable $allowed, callable $action): Report
    {
        return $this->db->transaction(function () use ($report, $allowed, $action): Report {
            $current = $this->reports->lockStatus($report->id);
            if ($current === null || !$allowed($current)) {
                throw new BusinessRuleException(sprintf(
                    'El informe está "%s"; la acción ya no es posible. Recargue la página.',
                    $current?->label() ?? 'no disponible',
                ));
            }
            $fresh = $this->reload($report->id);
            $action($fresh, $current);

            return $this->reload($report->id);
        });
    }

    /**
     * JSON canónico (claves ordenadas en todos los niveles): el hash no depende del orden en
     * que MySQL guarde las claves de la columna JSON.
     *
     * @param array<mixed> $content
     */
    public static function canonicalJson(array $content): string
    {
        $sort = static function (mixed $value) use (&$sort): mixed {
            if (!is_array($value)) {
                return $value;
            }
            $value = array_map($sort, $value);
            if (!array_is_list($value)) {
                ksort($value, SORT_STRING);
            }

            return $value;
        };

        return json_encode($sort($content), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    /**
     * PDF de una versión (ADR-017). Mismo acceso que el informe; cada descarga se audita.
     *
     * @return array{stream: \Psr\Http\Message\StreamInterface, name: string, size: int}
     */
    public function pdf(string $uuid, int $versionNumber): array
    {
        ['report' => $report, 'contract' => $contract] = $this->get($uuid);
        $version = $this->reports->versions($report->id, $versionNumber)[0] ?? throw new NotFoundException('La versión no existe.');
        if ($version['pdf_path'] === null || $version['pdf_size_bytes'] === null) {
            throw new BusinessRuleException($version['pdf_status'] === 'failed'
                ? 'No fue posible generar el PDF de esta versión. La administración puede reintentarlo desde "Tareas en segundo plano".'
                : 'El PDF de esta versión se está generando. Intente de nuevo en unos minutos.');
        }
        $this->audit->record(AuditAction::ReportPdfDownloaded, 'report', $report->uuid, ['version' => $versionNumber, 'pdf_sha256' => $version['pdf_sha256']]);

        return [
            'stream' => $this->storage->readStream($version['pdf_path']),
            'name' => sprintf('informe-%d-%s-v%d.pdf', $report->number, $contract->contractNumber, $versionNumber),
            'size' => $version['pdf_size_bytes'],
        ];
    }

    private function notifyContractor(Report $report, string $type, string $what, string $body): void
    {
        $contract = $this->contracts->getById($report->contractId);
        $this->notifications->notify(
            [$contract->contractorUserId],
            $type,
            sprintf('%s: su informe N.° %d %s', $contract->contractNumber, $report->number, $what),
            $body,
            self::link($report->uuid),
        );
    }

    private static function link(string $reportUuid): string
    {
        return '/reports/' . $reportUuid;
    }

    /** Encola la (re)generación del PDF; se llama dentro de la transacción del cambio (outbox). */
    private function queuePdf(int $reportId, int $version): void
    {
        $this->queue->push(ReportPdfHandler::TYPE, ['report_id' => $reportId, 'version' => $version], ReportPdfHandler::dedupeKey($reportId, $version));
    }

    private function reload(int $id): Report
    {
        return $this->reports->findById($id) ?? throw new \LogicException('Informe no encontrado.');
    }

    /** @return array<string, Activity> */
    private function obligationsByUuid(int $contractId): array
    {
        $result = [];
        foreach ($this->activities->forContract($contractId) as $activity) {
            if ($activity->level === ActivityLevel::Obligation) {
                $result[$activity->uuid] = $activity;
            }
        }

        return $result;
    }

    private function cannotEdit(Report $report, Contract $contract): \RuntimeException
    {
        if (!$this->access->isAuthor($contract)) {
            return new AuthorizationException('Solo el contratista del contrato puede modificar el informe.');
        }

        return new BusinessRuleException(sprintf('Un informe "%s" no se puede modificar.', $report->status->label()));
    }

    private function reviewDenied(Report $report, Contract $contract): \RuntimeException
    {
        if (!$this->access->isAssignedSupervisor($contract)) {
            return new AuthorizationException('Solo el supervisor asignado al contrato puede revisar este informe.');
        }

        return new BusinessRuleException(sprintf('El informe está "%s"; la acción no es posible.', $report->status->label()));
    }
}
