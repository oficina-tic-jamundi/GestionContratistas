<?php

declare(strict_types=1);

namespace Sigcon\Services\Reports;

use Sigcon\Exceptions\NotFoundException;
use Sigcon\Models\Contract;
use Sigcon\Models\ContractStatus;
use Sigcon\Models\Report;
use Sigcon\Models\ReportStatus;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Contracts\ContractService;

/**
 * Quién ve y quién puede hacer qué con un informe (ADR-015). Única fuente de estas reglas:
 * la usan ReportService y DocumentService (anexos del informe).
 *
 * - Ver: alcance del contrato; los BORRADORES solo los ve su autor (el contratista) y quien
 *   tiene contracts.view_all. El supervisor ve el informe desde que se envía.
 * - Elaborar/editar/enviar: el contratista del contrato (reports.create), con el informe en
 *   borrador o con observaciones, y el contrato activo o terminado (informe final).
 * - Revisar/observar: reports.review Y ser el supervisor asignado a ESE contrato.
 * - Aprobar/rechazar: reports.approve Y ser el supervisor asignado.
 * - Reabrir un aprobado: reports.reopen (administración), con motivo.
 */
final class ReportAccess
{
    public function __construct(
        private readonly ContractService $contracts,
        private readonly AuthContext $auth,
    ) {
    }

    /** Contrato del informe, aplicando alcance y la regla de borradores (fuera de alcance = 404). */
    public function contractFor(Report $report): Contract
    {
        try {
            $contract = $this->contracts->getById($report->contractId);
        } catch (NotFoundException) {
            throw new NotFoundException('El informe no existe.');
        }
        if ($report->status === ReportStatus::Draft && !$this->isAuthor($contract) && !$this->auth->can(Permission::ContractsViewAll)) {
            throw new NotFoundException('El informe no existe.');
        }

        return $contract;
    }

    public function contractAllowsReporting(Contract $contract): bool
    {
        return in_array($contract->status, [ContractStatus::Active, ContractStatus::Terminated], true);
    }

    public function isAuthor(Contract $contract): bool
    {
        return $this->auth->can(Permission::ReportsCreate) && $this->contracts->isOwnContract($contract);
    }

    public function isAssignedSupervisor(Contract $contract): bool
    {
        return $contract->supervisorId !== null && $contract->supervisorId === $this->auth->userId();
    }

    public function canEdit(Report $report, Contract $contract): bool
    {
        return $this->isAuthor($contract) && $report->status->isEditable() && $this->contractAllowsReporting($contract);
    }

    /**
     * @return array{edit: bool, submit: bool, start_review: bool, observe: bool, approve: bool, reject: bool, reopen: bool}
     */
    public function capabilities(Report $report, Contract $contract): array
    {
        $reviewer = $this->isAssignedSupervisor($contract);
        $inReview = $report->status === ReportStatus::InReview;

        return [
            'edit' => $this->canEdit($report, $contract),
            'submit' => $this->canEdit($report, $contract),
            'start_review' => $reviewer && $this->auth->can(Permission::ReportsReview) && $report->status->awaitsReview(),
            'observe' => $reviewer && $this->auth->can(Permission::ReportsReview) && $inReview,
            'approve' => $reviewer && $this->auth->can(Permission::ReportsApprove) && $inReview,
            'reject' => $reviewer && $this->auth->can(Permission::ReportsApprove) && $inReview,
            'reopen' => $this->auth->can(Permission::ReportsReopen) && $report->status === ReportStatus::Approved,
        ];
    }

    /** Usuario del que se ocultan borradores ajenos en los listados (null = ve todos). */
    public function draftOwnerFilter(): ?int
    {
        return $this->auth->can(Permission::ContractsViewAll) ? null : $this->auth->userId();
    }
}
