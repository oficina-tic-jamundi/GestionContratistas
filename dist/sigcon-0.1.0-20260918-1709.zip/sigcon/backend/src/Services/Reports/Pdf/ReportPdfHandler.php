<?php

declare(strict_types=1);

namespace Sigcon\Services\Reports\Pdf;

use Sigcon\Helpers\Clock;
use Sigcon\Repositories\EvidenceRepository;
use Sigcon\Repositories\ReportRepository;
use Sigcon\Services\Jobs\JobHandler;
use Sigcon\Services\Jobs\PermanentJobFailure;
use Sigcon\Storage\FileStorage;

/**
 * Trabajo `report.pdf`: genera (o regenera) el PDF de una versión del informe.
 *
 * Idempotente: siempre refleja el estado ACTUAL de la versión (por ejemplo, si fue aprobada
 * después de encolar el trabajo). Escribe el archivo nuevo, actualiza la versión y solo
 * entonces borra el PDF anterior.
 */
final class ReportPdfHandler implements JobHandler
{
    public const TYPE = 'report.pdf';

    public function __construct(
        private readonly ReportRepository $reports,
        private readonly EvidenceRepository $evidences,
        private readonly ReportPdfRenderer $renderer,
        private readonly FileStorage $storage,
        private readonly Clock $clock,
    ) {
    }

    public static function dedupeKey(int $reportId, int $version): string
    {
        return sprintf('%s:%d:v%d', self::TYPE, $reportId, $version);
    }

    public function type(): string
    {
        return self::TYPE;
    }

    public function handle(array $payload): void
    {
        [$reportId, $versionNumber] = self::target($payload);
        $report = $this->reports->findById($reportId) ?? throw new PermanentJobFailure('El informe ya no existe.');
        $version = $this->reports->versions($reportId, $versionNumber)[0] ?? throw new PermanentJobFailure('La versión del informe no existe.');
        $stored = $this->reports->versionContent($reportId, $versionNumber) ?? throw new PermanentJobFailure('La versión del informe no existe.');
        $content = json_decode($stored['content'], true);
        if (!is_array($content)) {
            throw new PermanentJobFailure('El contenido de la versión no es válido.');
        }

        $approval = null;
        if ($report->approvedVersion === $versionNumber && $report->approvedAt !== null) {
            $comment = null;
            foreach ($this->reports->reviews($reportId) as $review) {
                if ($review['decision'] === 'approved' && $review['version'] === $versionNumber) {
                    $comment = $review['comment'];
                    break; // las revisiones vienen de la más reciente a la más antigua
                }
            }
            $approval = ['by' => (string) $report->approvedByName, 'at' => $report->approvedAt, 'comment' => $comment];
        }

        $now = $this->clock->now();
        $pdf = $this->renderer->render($content, $version, $approval, $this->thumbnails($content), $now);
        $path = sprintf('private/reports/%s/%s-v%d-%s.pdf', $now->format('Y/m'), $report->uuid, $versionNumber, $now->format('YmdHis'));
        $this->storage->storeContents($pdf, $path);
        $this->reports->setPdfReady($reportId, $versionNumber, $path, hash('sha256', $pdf), strlen($pdf), $now);

        $previous = $version['pdf_path'];
        if ($previous !== null && $previous !== $path && $this->storage->exists($previous)) {
            $this->storage->delete($previous);
        }
    }

    public function failed(array $payload, string $error): void
    {
        [$reportId, $versionNumber] = self::target($payload);
        $this->reports->setPdfFailed($reportId, $versionNumber);
    }

    /**
     * Miniaturas oficiales (con marca de agua) de las evidencias incluidas en la versión.
     *
     * @param array<string, mixed> $content
     * @return array<string, string>
     */
    private function thumbnails(array $content): array
    {
        $result = [];
        foreach ((array) ($content['items'] ?? []) as $item) {
            foreach ((array) (is_array($item) ? ($item['evidences'] ?? []) : []) as $evidence) {
                $uuid = is_array($evidence) ? (string) ($evidence['uuid'] ?? '') : '';
                $found = $uuid !== '' ? $this->evidences->findByUuid($uuid) : null;
                if ($found !== null && $this->storage->exists($found->thumbnailPath)) {
                    $result[$uuid] = $this->storage->readStream($found->thumbnailPath)->getContents();
                }
            }
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array{int, int}
     */
    private static function target(array $payload): array
    {
        $reportId = $payload['report_id'] ?? null;
        $version = $payload['version'] ?? null;
        if (!is_int($reportId) || !is_int($version)) {
            throw new PermanentJobFailure('Datos del trabajo incompletos.');
        }

        return [$reportId, $version];
    }
}
