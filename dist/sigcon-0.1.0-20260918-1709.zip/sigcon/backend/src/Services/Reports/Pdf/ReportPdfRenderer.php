<?php

declare(strict_types=1);

namespace Sigcon\Services\Reports\Pdf;

use DateTimeImmutable;
use DateTimeZone;
use Dompdf\Dompdf;
use Dompdf\Options;
use Sigcon\Config\Settings;

/**
 * PDF de una versión de informe (ADR-017), a partir del contenido CONGELADO de la versión.
 *
 * - dompdf sin acceso remoto (no descarga nada de internet) ni PHP embebido; las imágenes
 *   de las evidencias se incrustan como data URI.
 * - Todo texto se escapa: el contenido lo escribe el usuario.
 * - El formato institucional definitivo (plantilla, firmas) está pendiente (ADR-015); este
 *   diseño es la versión técnica inicial.
 */
final class ReportPdfRenderer
{
    public function __construct(private readonly Settings $settings)
    {
    }

    /**
     * @param array<string, mixed> $content contenido congelado de la versión
     * @param array{version: int, content_hash: string, submitted_by: string, submitted_at: DateTimeImmutable} $version
     * @param array{by: string, at: DateTimeImmutable, comment: ?string}|null $approval aprobación vigente de ESTA versión
     * @param array<string, string> $thumbnails uuid de evidencia => JPEG de la miniatura oficial
     */
    public function render(array $content, array $version, ?array $approval, array $thumbnails, DateTimeImmutable $generatedAt): string
    {
        $tmp = $this->settings->storagePath . DIRECTORY_SEPARATOR . 'tmp';
        if (!is_dir($tmp)) {
            @mkdir($tmp, 0750, true);
        }
        $options = new Options();
        $options->setIsRemoteEnabled(false);
        $options->setIsPhpEnabled(false);
        $options->setIsJavascriptEnabled(false);
        $options->setDefaultFont('DejaVu Sans');
        $options->setTempDir($tmp);
        $options->setChroot([$tmp]);
        $options->setDefaultPaperSize('letter');

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($this->html($content, $version, $approval, $thumbnails, $generatedAt), 'UTF-8');
        $dompdf->render();

        $canvas = $dompdf->getCanvas();
        $font = $dompdf->getFontMetrics()->getFont('DejaVu Sans') ?? throw new \RuntimeException('Fuente del PDF no disponible.');
        $canvas->page_text(
            $canvas->get_width() - 150,
            $canvas->get_height() - 32,
            'Página {PAGE_NUM} de {PAGE_COUNT}',
            $font,
            8,
            [0.35, 0.39, 0.45],
        );

        return (string) $dompdf->output();
    }

    /**
     * @param array<string, mixed> $content
     * @param array{version: int, content_hash: string, submitted_by: string, submitted_at: DateTimeImmutable} $version
     * @param array{by: string, at: DateTimeImmutable, comment: ?string}|null $approval
     * @param array<string, string> $thumbnails
     */
    public function html(array $content, array $version, ?array $approval, array $thumbnails, DateTimeImmutable $generatedAt): string
    {
        $e = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $tz = new DateTimeZone(date_default_timezone_get());
        $dateTime = static fn (DateTimeImmutable $d): string => $d->setTimezone($tz)->format('d/m/Y H:i');
        $date = static fn (mixed $ymd): string => is_string($ymd) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $ymd, $m) === 1 ? "{$m[3]}/{$m[2]}/{$m[1]}" : '—';
        $isoLocal = static fn (mixed $iso): string => is_string($iso) && $iso !== '' ? (new DateTimeImmutable($iso))->setTimezone($tz)->format('d/m/Y H:i') : '—';
        $text = static fn (mixed $value): string => nl2br(htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'), false);

        $items = '';
        foreach ((array) ($content['items'] ?? []) as $i => $item) {
            if (!is_array($item)) {
                continue;
            }
            $updates = '';
            foreach ((array) ($item['progress_updates'] ?? []) as $u) {
                if (is_array($u)) {
                    $updates .= sprintf(
                        '<tr><td>%s</td><td class="num">%s %% → %s %%</td><td>%s</td><td>%s</td></tr>',
                        $e($u['activity'] ?? ''),
                        $e($u['from'] ?? ''),
                        $e($u['to'] ?? ''),
                        $e($u['note'] ?? ''),
                        $e(($u['user'] ?? '') . ', ' . $isoLocal($u['recorded_at'] ?? null)),
                    );
                }
            }
            $cells = [];
            foreach ((array) ($item['evidences'] ?? []) as $ev) {
                if (!is_array($ev)) {
                    continue;
                }
                $uuid = (string) ($ev['uuid'] ?? '');
                $img = isset($thumbnails[$uuid])
                    ? sprintf('<img src="data:image/jpeg;base64,%s" alt="">', base64_encode($thumbnails[$uuid]))
                    : '<div class="noimg">Imagen no disponible</div>';
                $place = ($ev['latitude'] ?? null) !== null
                    ? sprintf('%s, %s (±%s m)', $e($ev['latitude']), $e($ev['longitude'] ?? ''), $e(round((float) ($ev['accuracy_m'] ?? 0))))
                    : 'Sin ubicación';
                $cells[] = sprintf(
                    '<td class="ev">%s<div class="cap">%s<br>%s<br>%s</div></td>',
                    $img,
                    $e($isoLocal($ev['captured_at'] ?? null)),
                    $place,
                    $e(mb_strimwidth((string) ($ev['activity'] ?? ''), 0, 60, '…')),
                );
            }
            $evidenceRows = '';
            foreach (array_chunk($cells, 3) as $row) { // tres miniaturas por fila
                $evidenceRows .= '<tr>' . implode('', $row) . str_repeat('<td class="ev"></td>', 3 - count($row)) . '</tr>';
            }

            $items .= sprintf(
                '<div class="item"><h3>%d. %s</h3><p class="progress">Avance: %s %%</p><p>%s</p>%s%s</div>',
                (int) $i + 1,
                $e($item['title'] ?? ''),
                $e($item['progress'] ?? '0'),
                ($item['description'] ?? null) !== null ? $text($item['description']) : '<em class="muted">Sin descripción en este período.</em>',
                $updates !== '' ? '<p class="label">Avances registrados en el período</p><table class="grid"><tr><th>Actividad</th><th>Avance</th><th>Nota</th><th>Registró</th></tr>' . $updates . '</table>' : '',
                $evidenceRows !== '' ? '<p class="label">Evidencias fotográficas del período</p><table class="evidences">' . $evidenceRows . '</table>' : '',
            );
        }

        $documents = '';
        foreach ((array) ($content['documents'] ?? []) as $doc) {
            if (is_array($doc)) {
                $documents .= sprintf('<li>%s · %s · SHA-256 %s</li>', $e($doc['name'] ?? ''), $e($doc['type'] ?? ''), $e($doc['sha256'] ?? ''));
            }
        }

        $status = $approval !== null
            ? sprintf(
                '<div class="approved"><strong>APROBADO</strong> por %s el %s (versión %d).%s</div>',
                $e($approval['by']),
                $e($dateTime($approval['at'])),
                $version['version'],
                $approval['comment'] !== null && $approval['comment'] !== '' ? '<br>Comentario: ' . $text($approval['comment']) : '',
            )
            : '<div class="pending">Versión enviada para revisión. Este documento <strong>no</strong> registra una aprobación del supervisor.</div>';

        return <<<HTML
        <!DOCTYPE html>
        <html lang="es"><head><meta charset="UTF-8"><title>Informe {$e($content['report_number'] ?? '')} — {$e($content['contract_number'] ?? '')}</title>
        <style>
          @page { margin: 26mm 18mm 20mm 18mm; }
          body { font-family: 'DejaVu Sans', sans-serif; font-size: 9.5pt; color: #1f2937; line-height: 1.4; }
          header { position: fixed; top: -18mm; left: 0; right: 0; border-bottom: 2px solid #1b365d; padding-bottom: 4px; }
          header .org { font-size: 10pt; font-weight: bold; color: #1b365d; }
          header .sys { font-size: 8pt; color: #5b6472; }
          footer { position: fixed; bottom: -12mm; left: 0; right: 0; font-size: 7.5pt; color: #5b6472; border-top: 1px solid #d5dae1; padding-top: 3px; padding-right: 32mm; }
          h2 { page-break-after: avoid; }
          .keep { page-break-inside: avoid; }
          h1 { font-size: 15pt; color: #1b365d; margin: 0 0 6px; }
          h2 { font-size: 11pt; color: #1b365d; border-bottom: 1px solid #d5dae1; padding-bottom: 2px; margin: 16px 0 6px; }
          h3 { font-size: 10pt; margin: 0 0 4px; }
          .progress { margin: 0 0 4px; font-size: 8pt; color: #5b6472; }
          table.meta { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
          table.meta td { padding: 3px 6px; border: 1px solid #d5dae1; vertical-align: top; }
          table.meta td.k { width: 28%; background: #f3f5f8; color: #5b6472; }
          table.grid { width: 100%; border-collapse: collapse; font-size: 8pt; margin: 4px 0; }
          table.grid th, table.grid td { border: 1px solid #d5dae1; padding: 2px 4px; text-align: left; vertical-align: top; }
          table.grid th { background: #f3f5f8; }
          td.num { white-space: nowrap; }
          .item { border: 1px solid #d5dae1; border-radius: 3px; padding: 8px; margin-bottom: 8px; page-break-inside: avoid; }
          .label { font-size: 8pt; color: #5b6472; margin: 6px 0 2px; }
          table.evidences { width: 100%; border-collapse: separate; border-spacing: 4px; }
          td.ev { width: 33%; vertical-align: top; font-size: 7pt; color: #5b6472; }
          td.ev img { width: 100%; }
          .noimg { border: 1px dashed #d5dae1; padding: 16px 4px; text-align: center; }
          .approved { background: #e8f5ec; border: 1px solid #2e7d4f; color: #1d5a37; padding: 6px 8px; margin: 8px 0; }
          .pending { background: #fff7e0; border: 1px solid #c99a06; color: #7a5c00; padding: 6px 8px; margin: 8px 0; }
          .muted { color: #5b6472; }
          .hash { font-size: 7.5pt; color: #5b6472; word-wrap: break-word; }
        </style></head>
        <body>
        <header><div class="org">ALCALDÍA MUNICIPAL DE JAMUNDÍ · VALLE DEL CAUCA</div><div class="sys">SIGCON · Sistema de Gestión de Contratistas</div></header>
        <footer>Generado por SIGCON el {$e($dateTime($generatedAt))} (hora de Colombia) · versión {$version['version']} · huella {$e(substr($version['content_hash'], 0, 12))}…</footer>

        <h1>Informe de actividades N.° {$e($content['report_number'] ?? '')}</h1>
        <table class="meta">
          <tr><td class="k">Contrato</td><td>{$e($content['contract_number'] ?? '')}</td></tr>
          <tr><td class="k">Contratista</td><td>{$e($content['contractor'] ?? '')}</td></tr>
          <tr><td class="k">Supervisor</td><td>{$e($content['supervisor'] ?? 'Sin asignar')}</td></tr>
          <tr><td class="k">Período</td><td>{$e($date($content['period_start'] ?? null))} – {$e($date($content['period_end'] ?? null))}</td></tr>
          <tr><td class="k">Versión</td><td>{$version['version']}, enviada el {$e($dateTime($version['submitted_at']))} por {$e($version['submitted_by'])}</td></tr>
        </table>
        {$status}

        <h2>Resumen del período</h2>
        <p>{$text($content['summary'] ?? '—')}</p>

        <h2>Actividades por obligación</h2>
        {$items}

        HTML
        . (($content['contractor_notes'] ?? null) !== null ? "<h2>Observaciones del contratista</h2><p>{$text($content['contractor_notes'])}</p>" : '')
        . '<h2>Anexos</h2>' . ($documents !== '' ? "<ul>{$documents}</ul>" : '<p class="muted">Sin anexos.</p>')
        . <<<HTML
        <div class="keep"><h2>Integridad</h2>
        <p class="hash">Huella SHA-256 del contenido de la versión {$version['version']}: {$e($version['content_hash'])}.
        Puede verificarse en SIGCON. Las evidencias se identifican por la huella de su fotografía original.</p></div>
        </body></html>
        HTML;
    }
}
