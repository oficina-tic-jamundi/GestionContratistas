<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments;

use Sigcon\Exceptions\NotFoundException;
use Sigcon\Helpers\Clock;
use Sigcon\Repositories\PaymentRuleSettingsRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Payments\Rules\PaymentContext;
use Sigcon\Services\Payments\Rules\PaymentRule;

/**
 * Único punto que decide si un pago es elegible (ADR-007). Evalúa TODAS las reglas activas
 * (no se detiene en la primera que falla) y devuelve el detalle para guardarlo con el pago.
 * La interfaz nunca repite estas reglas: muestra el resultado.
 */
final class PaymentEligibilityService
{
    /** @var array<string, PaymentRule> */
    private array $rules = [];

    /** @param iterable<PaymentRule> $rules */
    public function __construct(
        iterable $rules,
        private readonly PaymentRuleSettingsRepository $settings,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly Clock $clock,
    ) {
        foreach ($rules as $rule) {
            $this->rules[$rule->code()] = $rule;
        }
    }

    /**
     * @return array{eligible: bool, results: list<array{code: string, label: string, enabled: bool, passed: ?bool, reason: string}>}
     */
    public function evaluate(PaymentContext $context): array
    {
        $settings = $this->settings->all();
        $results = [];
        $eligible = true;
        foreach ($this->rules as $code => $rule) {
            $setting = $settings[$code] ?? null;
            if ($setting === null || !$setting['enabled']) {
                $results[] = ['code' => $code, 'label' => $rule->label(), 'enabled' => false, 'passed' => null, 'reason' => 'Regla desactivada.'];
                continue;
            }
            $result = $rule->evaluate($context, $setting['params']);
            $eligible = $eligible && $result->passed;
            $results[] = ['code' => $code, 'label' => $rule->label(), 'enabled' => true, 'passed' => $result->passed, 'reason' => $result->reason];
        }

        return ['eligible' => $eligible, 'results' => $results];
    }

    /**
     * Reglas con su configuración, para la pantalla de administración.
     *
     * @return list<array<string, mixed>>
     */
    public function rules(): array
    {
        $settings = $this->settings->all();

        return array_values(array_map(static fn (PaymentRule $rule) => [
            'code' => $rule->code(),
            'label' => $rule->label(),
            'description' => $rule->description(),
            'parameters' => $rule->parameters(),
            'enabled' => $settings[$rule->code()]['enabled'] ?? false,
            'params' => (object) ($settings[$rule->code()]['params'] ?? []),
            'updated_by' => $settings[$rule->code()]['updated_by'] ?? null,
            'updated_at' => $settings[$rule->code()]['updated_at'] ?? null,
        ], $this->rules));
    }

    /** @param array<string, mixed> $params */
    public function configure(string $code, bool $enabled, array $params): void
    {
        $rule = $this->rules[$code] ?? throw new NotFoundException('La regla no existe.');
        $current = $this->settings->all()[$code] ?? null;
        // Una regla desactivada conserva sus parámetros anteriores si no se envían.
        $normalized = $enabled || $params !== [] ? $rule->normalize($params) : ($current['params'] ?? []);
        $this->settings->save($code, $enabled, $normalized, (int) $this->auth->userId(), $this->clock->now());
        $this->audit->record(AuditAction::PaymentRuleConfigured, 'payment_rule', $code, [
            'before' => $current === null ? null : ['enabled' => $current['enabled'], 'params' => $current['params']],
            'after' => ['enabled' => $enabled, 'params' => $normalized],
        ]);
    }
}
