<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments;

use DateTimeImmutable;
use DateTimeZone;
use Sigcon\Database\Database;
use Sigcon\Exceptions\AuthorizationException;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\DateTimes;
use Sigcon\Helpers\Money;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Contract;
use Sigcon\Models\ContractStatus;
use Sigcon\Models\HistoryEntry;
use Sigcon\Models\Payment;
use Sigcon\Models\PaymentStatus;
use Sigcon\Models\ReportStatus;
use Sigcon\Repositories\ActivityRepository;
use Sigcon\Repositories\BusinessHistoryRepository;
use Sigcon\Repositories\ContractScope;
use Sigcon\Repositories\PaymentRepository;
use Sigcon\Repositories\ReportRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Contracts\ContractService;
use Sigcon\Services\History\HistoryRecorder;
use Sigcon\Services\Notifications\NotificationService;
use Sigcon\Services\Payments\Rules\PaymentContext;
use Sigcon\Services\Reports\ReportAccess;

/**
 * Pagos (cuentas de cobro) de los contratos (ADR-007, ADR-018).
 *
 * - Un pago corresponde a un informe APROBADO (como máximo un pago vigente por informe).
 * - La suma de los pagos no anulados nunca supera el valor del contrato (verificado con el
 *   contrato bloqueado).
 * - Enviar a aprobación y aprobar exigen que el pago sea elegible EN ESE MOMENTO; cada
 *   evaluación queda guardada con el detalle de todas las reglas, aunque no sea elegible.
 * - Separación de funciones: quien registró o envió el pago no puede aprobarlo.
 * - "Pagado" registra un hecho externo (fecha y comprobante); SIGCON no ejecuta pagos.
 */
final class PaymentService
{
    public const ENTITY = 'payment';

    public function __construct(
        private readonly PaymentRepository $payments,
        private readonly ReportRepository $reports,
        private readonly ReportAccess $reportAccess,
        private readonly ActivityRepository $activities,
        private readonly ContractService $contracts,
        private readonly PaymentEligibilityService $eligibility,
        private readonly BusinessHistoryRepository $historyRepository,
        private readonly HistoryRecorder $history,
        private readonly AuditLogger $audit,
        private readonly NotificationService $notifications,
        private readonly AuthContext $auth,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /** @return Page<Payment> */
    public function list(?PaymentStatus $status, ?string $contractUuid, PageRequest $page): Page
    {
        return $this->payments->paginate($status, $contractUuid, $page, ContractScope::forUser($this->auth));
    }

    /** @return array{payment: Payment, contract: Contract} */
    public function get(string $uuid): array
    {
        $payment = (Uuid::isValid($uuid) ? $this->payments->findByUuid($uuid) : null) ?? throw new NotFoundException('El pago no existe.');
        try {
            $contract = $this->contracts->getById($payment->contractId);
        } catch (NotFoundException) {
            throw new NotFoundException('El pago no existe.');
        }

        return ['payment' => $payment, 'contract' => $contract];
    }

    /** @return array<string, mixed> */
    public function detail(string $uuid): array
    {
        ['payment' => $payment, 'contract' => $contract] = $this->get($uuid);

        return [
            'payment' => $payment,
            'contract' => $contract,
            'budget' => $this->budget($contract),
            'evaluation' => $this->payments->lastEvaluation($payment->id),
            'can' => $this->capabilities($payment),
        ];
    }

    /** @return list<HistoryEntry> */
    public function history(string $uuid): array
    {
        return $this->historyRepository->forEntity(self::ENTITY, $this->get($uuid)['payment']->id);
    }

    /**
     * Valor del contrato, comprometido (pagos no anulados), pagado y disponible, en pesos.
     *
     * @return array{total: string, committed: string, paid: string, available: string}
     */
    public function budget(Contract $contract): array
    {
        $totals = $this->payments->totals($contract->id);
        $total = Money::toCents($contract->totalValue);

        return [
            'total' => $contract->totalValue,
            'committed' => Money::fromCents($totals['committed']),
            'paid' => Money::fromCents($totals['paid']),
            'available' => Money::fromCents($total - $totals['committed']),
        ];
    }

    public function create(string $reportUuid, string $amount, ?string $notes): Payment
    {
        $this->require(Permission::PaymentsManage);
        $report = (Uuid::isValid($reportUuid) ? $this->reports->findByUuid($reportUuid) : null) ?? throw new NotFoundException('El informe no existe.');
        $contract = $this->reportAccess->contractFor($report);
        if ($report->status !== ReportStatus::Approved) {
            throw ValidationException::field('report', 'not_approved', 'Solo se registran pagos de informes aprobados.');
        }
        if ($contract->status === ContractStatus::Archived) {
            throw new BusinessRuleException('No se registran pagos de un contrato archivado.');
        }

        return $this->db->transaction(function () use ($report, $contract, $amount, $notes): Payment {
            $this->activities->lockContract($contract->id); // serializa consecutivo y presupuesto
            if ($this->payments->activeForReport($report->id) !== null) {
                throw ValidationException::field('report', 'duplicate', 'Este informe ya tiene un pago registrado.');
            }
            $this->ensureBudget($contract, $amount, null);
            $uuid = Uuid::v4();
            $number = $this->payments->nextNumber($contract->id);
            $id = $this->payments->create($uuid, $contract->id, $report->id, $number, $amount, $notes, (int) $this->auth->userId(), $this->clock->now());
            $this->history->record(self::ENTITY, $id, 'created', sprintf('Pago N.° %d registrado por %s', $number, Money::format($amount)), toStatus: PaymentStatus::Draft->value);
            $this->audit->record(AuditAction::PaymentCreated, 'payment', $uuid, ['contract' => $contract->uuid, 'report' => $report->uuid, 'amount' => $amount]);

            return $this->reload($id);
        });
    }

    public function update(string $uuid, string $amount, ?string $notes): Payment
    {
        $this->require(Permission::PaymentsManage);
        ['payment' => $payment, 'contract' => $contract] = $this->get($uuid);

        return $this->db->transaction(function () use ($payment, $contract, $amount, $notes): Payment {
            $this->activities->lockContract($contract->id);
            $this->expect($payment, static fn (PaymentStatus $s) => $s->isEditable(), 'Solo se modifica un pago en preparación.');
            $this->ensureBudget($contract, $amount, $payment->id);
            $this->payments->updateDraft($payment->id, $amount, $notes, $this->clock->now());
            if ($amount !== $payment->amount) {
                $this->history->record(self::ENTITY, $payment->id, 'updated', sprintf('Valor modificado de %s a %s', Money::format($payment->amount), Money::format($amount)));
            }
            $this->audit->record(AuditAction::PaymentUpdated, 'payment', $payment->uuid, ['from' => $payment->amount, 'to' => $amount]);

            return $this->reload($payment->id);
        });
    }

    /**
     * Evaluación manual de elegibilidad (se guarda para trazabilidad).
     *
     * @return array{eligible: bool, results: list<array<string, mixed>>}
     */
    public function evaluate(string $uuid): array
    {
        $this->require(Permission::PaymentsManage);
        ['payment' => $payment, 'contract' => $contract] = $this->get($uuid);
        if (!in_array($payment->status, [PaymentStatus::Draft, PaymentStatus::ReadyForApproval], true)) {
            throw new BusinessRuleException(sprintf('Un pago "%s" ya no se evalúa.', $payment->status->label()));
        }

        return $this->db->transaction(fn (): array => $this->runEvaluation($payment, $contract, 'manual'));
    }

    public function submit(string $uuid): Payment
    {
        $this->require(Permission::PaymentsManage);
        ['payment' => $payment, 'contract' => $contract] = $this->get($uuid);

        $outcome = $this->db->transaction(function () use ($payment, $contract): array {
            $this->expect($payment, static fn (PaymentStatus $s) => $s === PaymentStatus::Draft, 'Solo se envía a aprobación un pago en preparación.');
            $evaluation = $this->runEvaluation($payment, $contract, 'submit');
            if ($evaluation['eligible']) {
                $now = $this->clock->now();
                $this->payments->transition($payment->id, PaymentStatus::ReadyForApproval, $now, [
                    'submitted_by' => (int) $this->auth->userId(),
                    'submitted_at' => DateTimes::toDb($now),
                ]);
                $this->history->record(self::ENTITY, $payment->id, 'submitted', 'Pago enviado a aprobación (elegible)', fromStatus: PaymentStatus::Draft->value, toStatus: PaymentStatus::ReadyForApproval->value);
                $this->audit->record(AuditAction::PaymentSubmitted, 'payment', $payment->uuid, []);
                $this->notifications->notifyPermission(
                    Permission::PaymentsApprove,
                    'payment.ready',
                    sprintf('%s: pago N.° %d listo para aprobación', $contract->contractNumber, $payment->number),
                    sprintf('%s · %s. Cumple las reglas de elegibilidad vigentes.', $contract->contractorName, Money::format($payment->amount)),
                    self::link($payment->uuid),
                );
            }

            return $evaluation;
        });
        // La evaluación fallida queda guardada: se informa después de confirmar la transacción.
        if (!$outcome['eligible']) {
            throw $this->notEligible($outcome);
        }

        return $this->reload($payment->id);
    }

    public function approve(string $uuid): Payment
    {
        $this->require(Permission::PaymentsApprove);
        ['payment' => $payment, 'contract' => $contract] = $this->get($uuid);
        $this->ensureSegregation($payment);

        $outcome = $this->db->transaction(function () use ($payment, $contract): array {
            $this->expect($payment, static fn (PaymentStatus $s) => $s === PaymentStatus::ReadyForApproval, 'Solo se aprueba un pago listo para aprobación.');
            $evaluation = $this->runEvaluation($payment, $contract, 'approve');
            if ($evaluation['eligible']) {
                $now = $this->clock->now();
                $this->payments->transition($payment->id, PaymentStatus::Approved, $now, [
                    'approved_by' => (int) $this->auth->userId(),
                    'approved_at' => DateTimes::toDb($now),
                ]);
                $this->history->record(self::ENTITY, $payment->id, 'approved', sprintf('Pago aprobado por %s', Money::format($payment->amount)), fromStatus: PaymentStatus::ReadyForApproval->value, toStatus: PaymentStatus::Approved->value);
                $this->audit->record(AuditAction::PaymentApproved, 'payment', $payment->uuid, ['amount' => $payment->amount]);
                $this->notifications->notifyPermission(
                    Permission::PaymentsRegister,
                    'payment.approved',
                    sprintf('%s: pago N.° %d aprobado', $contract->contractNumber, $payment->number),
                    sprintf('%s · %s. Pendiente de registrar el pago efectuado.', $contract->contractorName, Money::format($payment->amount)),
                    self::link($payment->uuid),
                );
                $this->notifications->notify(
                    [$contract->contractorUserId],
                    'payment.approved',
                    sprintf('%s: su pago N.° %d fue aprobado', $contract->contractNumber, $payment->number),
                    sprintf('Valor: %s.', Money::format($payment->amount)),
                    self::link($payment->uuid),
                );
            }

            return $evaluation;
        });
        if (!$outcome['eligible']) {
            throw $this->notEligible($outcome, 'El pago ya no es elegible; no se aprobó.');
        }

        return $this->reload($payment->id);
    }

    public function returnToDraft(string $uuid, string $reason): Payment
    {
        $this->require(Permission::PaymentsApprove);
        ['payment' => $payment] = $this->get($uuid);

        return $this->db->transaction(function () use ($payment, $reason): Payment {
            $this->expect($payment, static fn (PaymentStatus $s) => $s === PaymentStatus::ReadyForApproval, 'Solo se devuelve un pago listo para aprobación.');
            $this->payments->transition($payment->id, PaymentStatus::Draft, $this->clock->now(), ['submitted_by' => null, 'submitted_at' => null]);
            $this->history->record(self::ENTITY, $payment->id, 'returned', 'Pago devuelto para ajustes', $reason, PaymentStatus::ReadyForApproval->value, PaymentStatus::Draft->value);
            $this->audit->record(AuditAction::PaymentReturned, 'payment', $payment->uuid, ['reason' => $reason]);
            $this->notifications->notify(
                [$payment->createdBy, $payment->submittedBy],
                'payment.returned',
                sprintf('%s: pago N.° %d devuelto para ajustes', $payment->contractNumber, $payment->number),
                $reason,
                self::link($payment->uuid),
            );

            return $this->reload($payment->id);
        });
    }

    public function registerPaid(string $uuid, DateTimeImmutable $paymentDate, string $reference): Payment
    {
        $this->require(Permission::PaymentsRegister);
        ['payment' => $payment, 'contract' => $contract] = $this->get($uuid);
        $today = new DateTimeImmutable($this->clock->now()->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('Y-m-d'), new DateTimeZone('UTC'));
        if ($paymentDate > $today) {
            throw ValidationException::field('payment_date', 'future', 'La fecha de pago no puede ser posterior a hoy.');
        }
        if ($payment->approvedAt !== null && $paymentDate->format('Y-m-d') < $payment->approvedAt->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('Y-m-d')) {
            throw ValidationException::field('payment_date', 'before_approval', 'La fecha de pago no puede ser anterior a la aprobación.');
        }

        return $this->db->transaction(function () use ($payment, $contract, $paymentDate, $reference): Payment {
            $this->expect($payment, static fn (PaymentStatus $s) => $s === PaymentStatus::Approved, 'Solo se registra el pago de un pago aprobado.');
            $now = $this->clock->now();
            $this->payments->transition($payment->id, PaymentStatus::Paid, $now, [
                'payment_date' => $paymentDate->format('Y-m-d'),
                'payment_reference' => $reference,
                'paid_registered_by' => (int) $this->auth->userId(),
                'paid_registered_at' => DateTimes::toDb($now),
            ]);
            $this->history->record(self::ENTITY, $payment->id, 'paid', sprintf('Pago registrado como pagado el %s (comprobante %s)', $paymentDate->format('d/m/Y'), $reference), fromStatus: PaymentStatus::Approved->value, toStatus: PaymentStatus::Paid->value);
            $this->audit->record(AuditAction::PaymentPaid, 'payment', $payment->uuid, ['payment_date' => $paymentDate->format('Y-m-d'), 'reference' => $reference, 'amount' => $payment->amount]);
            $this->notifications->notify(
                [$contract->contractorUserId],
                'payment.paid',
                sprintf('%s: su pago N.° %d fue pagado', $payment->contractNumber, $payment->number),
                sprintf('%s el %s (comprobante %s).', Money::format($payment->amount), $paymentDate->format('d/m/Y'), $reference),
                self::link($payment->uuid),
            );

            return $this->reload($payment->id);
        });
    }

    public function cancel(string $uuid, string $reason): Payment
    {
        $this->require(Permission::PaymentsManage);
        ['payment' => $payment] = $this->get($uuid);

        return $this->db->transaction(function () use ($payment, $reason): Payment {
            $this->expect($payment, static fn (PaymentStatus $s) => $s->isCancellable(), 'Un pago aprobado o pagado no se anula.');
            $now = $this->clock->now();
            $this->payments->transition($payment->id, PaymentStatus::Cancelled, $now, [
                'cancelled_reason' => $reason,
                'cancelled_by' => (int) $this->auth->userId(),
                'cancelled_at' => DateTimes::toDb($now),
            ]);
            $this->history->record(self::ENTITY, $payment->id, 'cancelled', 'Pago anulado', $reason, $payment->status->value, PaymentStatus::Cancelled->value);
            $this->audit->record(AuditAction::PaymentCancelled, 'payment', $payment->uuid, ['reason' => $reason]);

            return $this->reload($payment->id);
        });
    }

    /** @return array<string, bool> acciones que el backend aceptaría ahora */
    private function capabilities(Payment $payment): array
    {
        $manage = $this->auth->can(Permission::PaymentsManage);
        $approve = $this->auth->can(Permission::PaymentsApprove) && !$this->isOwnWork($payment);

        return [
            'edit' => $manage && $payment->status === PaymentStatus::Draft,
            'evaluate' => $manage && in_array($payment->status, [PaymentStatus::Draft, PaymentStatus::ReadyForApproval], true),
            'submit' => $manage && $payment->status === PaymentStatus::Draft,
            'approve' => $approve && $payment->status === PaymentStatus::ReadyForApproval,
            'return' => $this->auth->can(Permission::PaymentsApprove) && $payment->status === PaymentStatus::ReadyForApproval,
            'register_paid' => $this->auth->can(Permission::PaymentsRegister) && $payment->status === PaymentStatus::Approved,
            'cancel' => $manage && $payment->status->isCancellable(),
        ];
    }

    /**
     * @return array{eligible: bool, results: list<array<string, mixed>>}
     */
    private function runEvaluation(Payment $payment, Contract $contract, string $trigger): array
    {
        $report = $this->reports->findById($payment->reportId) ?? throw new \LogicException('Informe del pago no encontrado.');
        $result = $this->eligibility->evaluate(new PaymentContext($payment, $contract, $report));
        $this->payments->insertEvaluation($payment->id, $result['eligible'], $result['results'], $trigger, (int) $this->auth->userId(), $this->clock->now());
        $this->audit->record(AuditAction::PaymentEvaluated, 'payment', $payment->uuid, ['eligible' => $result['eligible'], 'trigger' => $trigger]);

        return $result;
    }

    /** @param array{eligible: bool, results: list<array<string, mixed>>} $evaluation */
    private function notEligible(array $evaluation, string $prefix = 'El pago no es elegible.'): BusinessRuleException
    {
        $failed = array_map(
            static fn (array $r) => (string) $r['reason'],
            array_filter($evaluation['results'], static fn (array $r) => $r['enabled'] && $r['passed'] === false),
        );

        return new BusinessRuleException($prefix . ' ' . implode(' ', $failed));
    }

    /** Separación de funciones: quien registró o envió el pago no puede aprobarlo. */
    private function ensureSegregation(Payment $payment): void
    {
        if ($this->isOwnWork($payment)) {
            throw new AuthorizationException('Quien registró o envió el pago no puede aprobarlo (separación de funciones).');
        }
    }

    private function isOwnWork(Payment $payment): bool
    {
        $user = $this->auth->userId();

        return $payment->createdBy === $user || ($payment->submittedBy !== null && $payment->submittedBy === $user);
    }

    private function ensureBudget(Contract $contract, string $amount, ?int $exceptPaymentId): void
    {
        $cents = Money::toCents($amount);
        if ($cents <= 0) {
            throw ValidationException::field('amount', 'invalid', 'El valor debe ser mayor que cero.');
        }
        $available = Money::toCents($contract->totalValue) - $this->payments->totals($contract->id, $exceptPaymentId)['committed'];
        if ($cents > $available) {
            throw ValidationException::field('amount', 'exceeds_contract', sprintf('El valor supera el saldo disponible del contrato (%s).', Money::format(Money::fromCents(max(0, $available)))));
        }
    }

    /** @param callable(PaymentStatus): bool $allowed */
    private function expect(Payment $payment, callable $allowed, string $message): void
    {
        $current = $this->payments->lockStatus($payment->id);
        if ($current === null || !$allowed($current)) {
            throw new BusinessRuleException($message . ($current !== null ? sprintf(' Estado actual: "%s".', $current->label()) : ''));
        }
    }

    private function require(Permission $permission): void
    {
        if (!$this->auth->can($permission)) {
            throw new AuthorizationException('No tiene permiso para esta acción sobre pagos.');
        }
    }

    private static function link(string $paymentUuid): string
    {
        return '/payments/' . $paymentUuid;
    }

    private function reload(int $id): Payment
    {
        return $this->payments->findById($id) ?? throw new \LogicException('Pago no encontrado.');
    }
}
