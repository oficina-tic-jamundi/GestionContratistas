<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Exceptions\ValidationException;
use Sigcon\Models\Document;
use Sigcon\Repositories\DocumentRepository;
use Sigcon\Services\Documents\DocumentService;

/**
 * El contrato debe tener vigentes documentos de los tipos seleccionados.
 * Desactivada por defecto: la lista institucional de documentos está pendiente (ADR-014).
 */
final class RequiredDocumentsRule implements PaymentRule
{
    public function __construct(private readonly DocumentRepository $documents)
    {
    }

    public function code(): string
    {
        return 'required_documents';
    }

    public function label(): string
    {
        return 'Documentos requeridos del contrato';
    }

    public function description(): string
    {
        return 'El contrato debe tener vigente al menos un documento de cada tipo seleccionado.';
    }

    public function parameters(): array
    {
        return [[
            'name' => 'types',
            'label' => 'Tipos de documento requeridos',
            'type' => 'choices',
            'options' => array_map(
                static fn (array $t) => ['value' => $t['code'], 'label' => $t['name']],
                $this->documents->types(DocumentService::ENTITY_CONTRACT),
            ),
        ]];
    }

    public function normalize(array $params): array
    {
        $types = $params['types'] ?? null;
        $valid = array_column($this->documents->types(DocumentService::ENTITY_CONTRACT), 'code');
        if (!is_array($types) || $types === [] || array_diff($types, $valid) !== []) {
            throw ValidationException::field('params.types', 'invalid', 'Seleccione al menos un tipo de documento válido.');
        }

        return ['types' => array_values(array_unique(array_map('strval', $types)))];
    }

    public function evaluate(PaymentContext $context, array $params): RuleResult
    {
        $required = is_array($params['types'] ?? null) ? $params['types'] : [];
        $present = [];
        $names = [];
        foreach ($this->documents->forEntity(DocumentService::ENTITY_CONTRACT, $context->contract->id) as $document) {
            if ($document->isActive()) {
                $present[$document->typeCode] = true;
            }
        }
        foreach ($this->documents->types(DocumentService::ENTITY_CONTRACT) as $type) {
            $names[$type['code']] = $type['name'];
        }
        $missing = array_values(array_filter($required, static fn (string $code) => !isset($present[$code])));

        return $missing === []
            ? RuleResult::pass('El contrato tiene todos los documentos requeridos.')
            : RuleResult::fail('Faltan documentos: ' . implode(', ', array_map(static fn (string $c) => $names[$c] ?? $c, $missing)) . '.');
    }
}
