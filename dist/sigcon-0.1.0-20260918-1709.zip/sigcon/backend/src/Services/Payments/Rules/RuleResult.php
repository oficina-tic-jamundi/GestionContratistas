<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

/** Resultado de una regla, con un motivo legible (se guarda para trazabilidad). */
final class RuleResult
{
    private function __construct(
        public readonly bool $passed,
        public readonly string $reason,
    ) {
    }

    public static function pass(string $reason): self
    {
        return new self(true, $reason);
    }

    public static function fail(string $reason): self
    {
        return new self(false, $reason);
    }
}
