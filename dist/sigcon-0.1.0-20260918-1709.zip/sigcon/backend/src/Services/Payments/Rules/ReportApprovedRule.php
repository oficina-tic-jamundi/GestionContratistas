<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Models\ReportStatus;

/** El informe del período debe estar aprobado por el supervisor. */
final class ReportApprovedRule implements PaymentRule
{
    public function code(): string
    {
        return 'report_approved';
    }

    public function label(): string
    {
        return 'Informe del período aprobado';
    }

    public function description(): string
    {
        return 'El informe asociado al pago debe estar aprobado por el supervisor (ADR-007).';
    }

    public function parameters(): array
    {
        return [];
    }

    public function normalize(array $params): array
    {
        return [];
    }

    public function evaluate(PaymentContext $context, array $params): RuleResult
    {
        $report = $context->report;

        return $report->status === ReportStatus::Approved && $report->approvedVersion !== null
            ? RuleResult::pass(sprintf('Informe N.° %d aprobado (versión %d) por %s.', $report->number, $report->approvedVersion, (string) $report->approvedByName))
            : RuleResult::fail(sprintf('El informe N.° %d está "%s".', $report->number, $report->status->label()));
    }
}
