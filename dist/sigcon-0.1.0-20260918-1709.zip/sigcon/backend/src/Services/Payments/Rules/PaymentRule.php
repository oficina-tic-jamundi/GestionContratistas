<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Exceptions\ValidationException;

/**
 * Condición de elegibilidad de un pago (ADR-007). Cada regla es independiente, tiene sus
 * propias pruebas y sus parámetros se configuran en la base de datos.
 */
interface PaymentRule
{
    public function code(): string;

    public function label(): string;

    /** Explicación para quien configura las reglas. */
    public function description(): string;

    /**
     * Parámetros configurables, para que la interfaz los muestre sin conocer la regla.
     *
     * @return list<array{name: string, label: string, type: 'integer'|'choices', min?: int, max?: int, options?: list<array{value: string, label: string}>}>
     */
    public function parameters(): array;

    /**
     * Valida y normaliza los parámetros enviados por el administrador.
     *
     * @param array<string, mixed> $params
     * @return array<string, mixed>
     * @throws ValidationException
     */
    public function normalize(array $params): array;

    /** @param array<string, mixed> $params ya normalizados */
    public function evaluate(PaymentContext $context, array $params): RuleResult;
}
