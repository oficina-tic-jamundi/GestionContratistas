<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use DateTimeImmutable;
use DateTimeZone;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Repositories\EvidenceRepository;

/**
 * Mínimo de evidencias fotográficas vigentes capturadas en el período del informe.
 * Desactivada por defecto: el mínimo institucional está pendiente (ADR-016).
 */
final class MinEvidencesRule implements PaymentRule
{
    public function __construct(private readonly EvidenceRepository $evidences)
    {
    }

    public function code(): string
    {
        return 'min_evidences';
    }

    public function label(): string
    {
        return 'Evidencias fotográficas mínimas del período';
    }

    public function description(): string
    {
        return 'En el período del informe debe haber al menos la cantidad indicada de evidencias vigentes.';
    }

    public function parameters(): array
    {
        return [['name' => 'min', 'label' => 'Cantidad mínima', 'type' => 'integer', 'min' => 1, 'max' => 500]];
    }

    public function normalize(array $params): array
    {
        $min = $params['min'] ?? null;
        if (!is_int($min) || $min < 1 || $min > 500) {
            throw ValidationException::field('params.min', 'invalid', 'La cantidad mínima debe estar entre 1 y 500.');
        }

        return ['min' => $min];
    }

    public function evaluate(PaymentContext $context, array $params): RuleResult
    {
        $min = is_int($params['min'] ?? null) ? $params['min'] : 1;
        $tz = new DateTimeZone(date_default_timezone_get());
        $utc = new DateTimeZone('UTC');
        $from = (new DateTimeImmutable($context->report->periodStart->format('Y-m-d') . ' 00:00:00', $tz))->setTimezone($utc);
        $to = (new DateTimeImmutable($context->report->periodEnd->format('Y-m-d') . ' 00:00:00', $tz))->modify('+1 day')->setTimezone($utc);
        $count = count($this->evidences->activeInPeriod($context->contract->id, $from, $to));

        return $count >= $min
            ? RuleResult::pass(sprintf('%d evidencia(s) en el período (mínimo %d).', $count, $min))
            : RuleResult::fail(sprintf('Solo hay %d evidencia(s) en el período; se requieren %d.', $count, $min));
    }
}
