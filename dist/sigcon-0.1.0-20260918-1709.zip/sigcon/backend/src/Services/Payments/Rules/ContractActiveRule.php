<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Exceptions\ValidationException;
use Sigcon\Models\ContractStatus;

/** El contrato debe estar en uno de los estados permitidos (por defecto, solo Activo). */
final class ContractActiveRule implements PaymentRule
{
    private const ALLOWED = [ContractStatus::Active, ContractStatus::Suspended, ContractStatus::Terminated, ContractStatus::Liquidated];

    public function code(): string
    {
        return 'contract_active';
    }

    public function label(): string
    {
        return 'Contrato en un estado que permite pagos';
    }

    public function description(): string
    {
        return 'El contrato debe estar en alguno de los estados seleccionados. Por defecto, solo Activo (ADR-007).';
    }

    public function parameters(): array
    {
        return [[
            'name' => 'statuses',
            'label' => 'Estados permitidos',
            'type' => 'choices',
            'options' => array_map(static fn (ContractStatus $s) => ['value' => $s->value, 'label' => $s->label()], self::ALLOWED),
        ]];
    }

    public function normalize(array $params): array
    {
        $allowed = array_map(static fn (ContractStatus $s) => $s->value, self::ALLOWED);
        $statuses = $params['statuses'] ?? null;
        if (!is_array($statuses) || $statuses === [] || array_diff($statuses, $allowed) !== []) {
            throw ValidationException::field('params.statuses', 'invalid', 'Seleccione al menos un estado válido.');
        }

        return ['statuses' => array_values(array_unique(array_map('strval', $statuses)))];
    }

    public function evaluate(PaymentContext $context, array $params): RuleResult
    {
        $statuses = is_array($params['statuses'] ?? null) ? $params['statuses'] : [ContractStatus::Active->value];
        $status = $context->contract->status;

        return in_array($status->value, $statuses, true)
            ? RuleResult::pass(sprintf('El contrato está %s.', mb_strtolower($status->label())))
            : RuleResult::fail(sprintf('El contrato está %s.', mb_strtolower($status->label())));
    }
}
