<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Repositories\ReportRepository;

/** Ningún informe del contrato puede tener observaciones pendientes de corregir. */
final class NoPendingObservationsRule implements PaymentRule
{
    public function __construct(private readonly ReportRepository $reports)
    {
    }

    public function code(): string
    {
        return 'no_pending_observations';
    }

    public function label(): string
    {
        return 'Sin observaciones pendientes';
    }

    public function description(): string
    {
        return 'Ningún informe del contrato puede estar "con observaciones" esperando corrección del contratista (ADR-007).';
    }

    public function parameters(): array
    {
        return [];
    }

    public function normalize(array $params): array
    {
        return [];
    }

    public function evaluate(PaymentContext $context, array $params): RuleResult
    {
        $numbers = $this->reports->numbersWithPendingObservations($context->contract->id);

        return $numbers === []
            ? RuleResult::pass('No hay informes con observaciones pendientes.')
            : RuleResult::fail(sprintf('Informes con observaciones pendientes: N.° %s.', implode(', N.° ', $numbers)));
    }
}
