<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Exceptions\ValidationException;
use Sigcon\Repositories\ActivityRepository;
use Sigcon\Services\Activities\ProgressCalculator;

/**
 * Avance global mínimo del contrato (promedio ponderado de las obligaciones, ADR-013).
 * Desactivada por defecto: el criterio institucional está pendiente (p. ej. 100 % solo para el
 * último pago, o avance proporcional al tiempo transcurrido).
 */
final class MinProgressRule implements PaymentRule
{
    public function __construct(private readonly ActivityRepository $activities)
    {
    }

    public function code(): string
    {
        return 'min_progress';
    }

    public function label(): string
    {
        return 'Avance mínimo del contrato';
    }

    public function description(): string
    {
        return 'El avance global del contrato (promedio ponderado de sus obligaciones) debe ser al menos el porcentaje indicado.';
    }

    public function parameters(): array
    {
        return [['name' => 'min_percent', 'label' => 'Avance mínimo (%)', 'type' => 'integer', 'min' => 1, 'max' => 100]];
    }

    public function normalize(array $params): array
    {
        $min = $params['min_percent'] ?? null;
        if (!is_int($min) || $min < 1 || $min > 100) {
            throw ValidationException::field('params.min_percent', 'invalid', 'El avance mínimo debe estar entre 1 y 100.');
        }

        return ['min_percent' => $min];
    }

    public function evaluate(PaymentContext $context, array $params): RuleResult
    {
        $min = is_int($params['min_percent'] ?? null) ? $params['min_percent'] : 100;
        $progress = ProgressCalculator::weightedAverage($this->activities->obligationValues($context->contract->id));

        return ProgressCalculator::toHundredths($progress) >= $min * 100
            ? RuleResult::pass(sprintf('Avance del contrato: %s %% (mínimo %d %%).', $progress, $min))
            : RuleResult::fail(sprintf('Avance del contrato: %s %%; se requiere al menos %d %%.', $progress, $min));
    }
}
