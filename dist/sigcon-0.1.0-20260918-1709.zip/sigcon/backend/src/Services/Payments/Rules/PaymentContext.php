<?php

declare(strict_types=1);

namespace Sigcon\Services\Payments\Rules;

use Sigcon\Models\Contract;
use Sigcon\Models\Payment;
use Sigcon\Models\Report;

/** Datos del pago que evalúan las reglas (se leen una sola vez por evaluación). */
final class PaymentContext
{
    public function __construct(
        public readonly Payment $payment,
        public readonly Contract $contract,
        public readonly Report $report,
    ) {
    }
}
