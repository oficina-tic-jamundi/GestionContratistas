<?php

declare(strict_types=1);

namespace Sigcon\Services\Evidence;

use DateTimeImmutable;
use Sigcon\Models\LocationStatus;

/**
 * Ubicación tal como la entregó el dispositivo (ya validada en forma por el controlador).
 * `$reported` es Ok cuando hay coordenadas; el servicio decide si son de baja precisión.
 */
final class CaptureLocation
{
    public function __construct(
        public readonly LocationStatus $reported,
        public readonly ?float $latitude = null,
        public readonly ?float $longitude = null,
        public readonly ?float $accuracyM = null,
        public readonly ?float $altitudeM = null,
        public readonly ?float $headingDeg = null,
        public readonly ?float $speedMps = null,
        public readonly ?DateTimeImmutable $capturedAt = null,
    ) {
    }

    public function hasCoordinates(): bool
    {
        return $this->latitude !== null && $this->longitude !== null && $this->accuracyM !== null;
    }
}
