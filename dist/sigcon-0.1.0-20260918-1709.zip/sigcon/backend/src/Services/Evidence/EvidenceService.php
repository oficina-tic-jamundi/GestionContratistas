<?php

declare(strict_types=1);

namespace Sigcon\Services\Evidence;

use DateTimeImmutable;
use DateTimeZone;
use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UploadedFileInterface;
use Sigcon\Config\EvidenceSettings;
use Sigcon\Database\Database;
use Sigcon\Exceptions\AuthorizationException;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\DateTimes;
use Sigcon\Helpers\Uuid;
use Sigcon\Models\Activity;
use Sigcon\Models\Contract;
use Sigcon\Models\ContractStatus;
use Sigcon\Models\Evidence;
use Sigcon\Models\LocationStatus;
use Sigcon\Repositories\ActivityRepository;
use Sigcon\Repositories\EvidenceRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Contracts\ContractService;
use Sigcon\Storage\FileStorage;

/**
 * Evidencias fotográficas (ADR-006, ADR-016).
 *
 * - Consulta: mismo alcance que el contrato (fuera de alcance = 404).
 * - Registro: `evidence.capture` y ser el contratista del contrato, con el contrato activo.
 * - Original sin marca de agua: solo con `evidence.view_original`; cada consulta se audita.
 * - Retiro (no eliminación): quien la registró o quien gestiona contratos, con motivo.
 * - La hora oficial es la del servidor; la del dispositivo se guarda solo como dato informativo.
 */
final class EvidenceService
{
    public const VARIANTS = ['official', 'thumbnail', 'original'];

    public function __construct(
        private readonly EvidenceRepository $evidences,
        private readonly ActivityRepository $activities,
        private readonly ContractService $contracts,
        private readonly EvidenceImageProcessor $processor,
        private readonly EvidenceSettings $settings,
        private readonly FileStorage $storage,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /**
     * @return array{evidences: list<Evidence>, withdrawable: list<string>, can_capture: bool, can_view_original: bool, max_mb: int}
     */
    public function forContract(string $contractUuid, ?string $activityUuid = null): array
    {
        $contract = $this->contracts->get($contractUuid);
        $activityId = null;
        if ($activityUuid !== null) {
            $activity = (Uuid::isValid($activityUuid) ? $this->activities->findByUuid($activityUuid) : null);
            if ($activity === null || $activity->contractId !== $contract->id) {
                throw new NotFoundException('El elemento no existe.');
            }
            $activityId = $activity->id;
        }
        $evidences = $this->evidences->forContract($contract->id, $activityId);

        return [
            'evidences' => $evidences,
            'withdrawable' => array_values(array_map(
                static fn (Evidence $e) => $e->uuid,
                array_filter($evidences, fn (Evidence $e) => $e->isActive() && $this->canWithdraw($e, $contract)),
            )),
            'can_capture' => $this->canCapture($contract),
            'can_view_original' => $this->auth->can(Permission::EvidenceViewOriginal),
            'max_mb' => intdiv($this->settings->maxBytes, 1024 * 1024),
        ];
    }

    public function capture(
        string $activityUuid,
        ?UploadedFileInterface $photo,
        ?string $description,
        CaptureLocation $location,
        ?DateTimeImmutable $deviceCapturedAt,
    ): Evidence {
        $activity = $this->findActivity($activityUuid);
        $contract = $this->contractOf($activity);
        if (!$this->isExecutor($contract)) {
            throw new AuthorizationException('Solo el contratista del contrato puede registrar evidencias.');
        }
        if ($contract->status !== ContractStatus::Active) {
            throw new BusinessRuleException(sprintf('No se registran evidencias en un contrato %s.', mb_strtolower($contract->status->label())));
        }

        $image = $this->processor->validate($photo);
        $photo = $photo ?? throw new \LogicException('Fotografía validada ausente.');
        $uuid = Uuid::v4();
        $now = $this->clock->now();
        $status = $this->locationStatus($location);
        $rendered = $this->processor->render($image['path'], $image['mime'], $this->watermarkLines($uuid, $now, $contract, $activity, $location, $status, $image['sha256']));

        $base = sprintf('private/evidences/%s/%s', $now->format('Y/m'), $uuid);
        $paths = [
            'original' => "{$base}-original.{$image['extension']}",
            'official' => "{$base}.jpg",
            'thumbnail' => "{$base}-thumb.jpg",
        ];

        try {
            $this->db->transaction(function () use ($uuid, $contract, $activity, $description, $image, $rendered, $paths, $status, $location, $deviceCapturedAt, $now, $photo): void {
                $this->activities->lockContract($contract->id); // evita duplicados por envíos simultáneos
                if ($this->evidences->activeOriginalExists($contract->id, $image['sha256'])) {
                    throw ValidationException::field('photo', 'duplicate', 'Esta fotografía ya está registrada como evidencia en el contrato.');
                }
                $this->evidences->create([
                    'uuid' => $uuid,
                    'contract_id' => $contract->id,
                    'activity_id' => $activity->id,
                    'description' => $description,
                    'original_path' => $paths['original'],
                    'original_mime' => $image['mime'],
                    'original_size_bytes' => $image['size'],
                    'original_sha256' => $image['sha256'],
                    'width' => $image['width'],
                    'height' => $image['height'],
                    'official_path' => $paths['official'],
                    'official_sha256' => hash('sha256', $rendered['official']),
                    'thumbnail_path' => $paths['thumbnail'],
                    'location_status' => $status->value,
                    'latitude' => $status->hasCoordinates() ? self::decimal($location->latitude, 6) : null,
                    'longitude' => $status->hasCoordinates() ? self::decimal($location->longitude, 6) : null,
                    'accuracy_m' => $status->hasCoordinates() ? self::decimal($location->accuracyM, 2) : null,
                    'altitude_m' => $status->hasCoordinates() ? self::decimal($location->altitudeM, 2) : null,
                    'heading_deg' => $status->hasCoordinates() ? self::decimal($location->headingDeg, 2) : null,
                    'speed_mps' => $status->hasCoordinates() ? self::decimal($location->speedMps, 2) : null,
                    'location_captured_at' => $status->hasCoordinates() && $location->capturedAt !== null ? DateTimes::toDb($location->capturedAt) : null,
                    'device_captured_at' => $deviceCapturedAt === null ? null : DateTimes::toDb($deviceCapturedAt),
                    'captured_at' => DateTimes::toDb($now),
                    'captured_by' => (int) $this->auth->userId(),
                    'status' => 'active',
                ]);
                // Los archivos se escriben dentro de la transacción: si algo falla, no queda el registro.
                $this->storage->storeUpload($photo, $paths['original']);
                $this->storage->storeContents($rendered['official'], $paths['official']);
                $this->storage->storeContents($rendered['thumbnail'], $paths['thumbnail']);
                $this->audit->record(AuditAction::EvidenceCaptured, 'evidence', $uuid, [
                    'contract' => $contract->uuid,
                    'activity' => $activity->uuid,
                    'original_sha256' => $image['sha256'],
                    'location_status' => $status->value,
                ]);
            });
        } catch (\Throwable $e) {
            // Compensación: archivos escritos de una transacción que no se confirmó.
            if ($this->evidences->findByUuid($uuid) === null) {
                foreach ($paths as $path) {
                    if ($this->storage->exists($path)) {
                        $this->storage->delete($path);
                    }
                }
            }
            throw $e;
        }

        return $this->evidences->findByUuid($uuid) ?? throw new \LogicException('Evidencia no encontrada tras el registro.');
    }

    /** @return array{evidence: Evidence, stream: StreamInterface, mime: string} */
    public function image(string $uuid, string $variant): array
    {
        $evidence = $this->find($uuid);
        $contract = $this->contractOfEvidence($evidence);
        if ($variant === 'original') {
            if (!$this->auth->can(Permission::EvidenceViewOriginal)) {
                throw new AuthorizationException('No tiene permiso para consultar la fotografía original.');
            }
            $this->audit->record(AuditAction::EvidenceOriginalViewed, 'evidence', $evidence->uuid, ['contract' => $contract->uuid]);

            return ['evidence' => $evidence, 'stream' => $this->storage->readStream($evidence->originalPath), 'mime' => $evidence->originalMime];
        }
        $path = $variant === 'thumbnail' ? $evidence->thumbnailPath : $evidence->officialPath;

        return ['evidence' => $evidence, 'stream' => $this->storage->readStream($path), 'mime' => 'image/jpeg'];
    }

    public function withdraw(string $uuid, string $reason): Evidence
    {
        $evidence = $this->find($uuid);
        $contract = $this->contractOfEvidence($evidence);
        if (!$evidence->isActive()) {
            return $evidence;
        }
        if (!$this->canWithdraw($evidence, $contract)) {
            throw $contract->status === ContractStatus::Archived && ($this->auth->can(Permission::ContractsManage) || $evidence->capturedBy === $this->auth->userId())
                ? new BusinessRuleException('Las evidencias de un contrato archivado no se modifican.')
                : new AuthorizationException('Solo quien registró la evidencia o quien gestiona el contrato puede retirarla.');
        }
        $this->db->transaction(function () use ($evidence, $contract, $reason): void {
            $this->evidences->withdraw($evidence->id, $reason, (int) $this->auth->userId(), $this->clock->now());
            $this->audit->record(AuditAction::EvidenceWithdrawn, 'evidence', $evidence->uuid, ['contract' => $contract->uuid, 'reason' => $reason]);
        });

        return $this->find($uuid);
    }

    /**
     * Texto de la marca de agua, en el orden de ADR-006: identidad, fecha y hora oficiales,
     * ubicación con su precisión y contexto. Diseño propio de SIGCON.
     *
     * @return list<string>
     */
    public function watermarkLines(string $uuid, DateTimeImmutable $now, Contract $contract, Activity $activity, CaptureLocation $location, LocationStatus $status, string $originalSha256): array
    {
        $local = $now->setTimezone(new DateTimeZone(date_default_timezone_get()));
        $place = $status->hasCoordinates()
            ? sprintf(
                'Lat %s  Lon %s  ·  precisión ±%s m%s',
                number_format((float) $location->latitude, 6, '.', ''),
                number_format((float) $location->longitude, 6, '.', ''),
                number_format((float) $location->accuracyM, 0, ',', '.'),
                $status === LocationStatus::LowAccuracy ? ' (baja)' : '',
            )
            : $status->label();

        return [
            'SIGCON · Alcaldía Municipal de Jamundí',
            sprintf('%s  ·  hora oficial de Colombia (%s)', $local->format('d/m/Y H:i:s'), $local->format('P')),
            $place,
            sprintf('Contrato %s  ·  %s', $contract->contractNumber, $contract->contractorName),
            sprintf('%s: %s', $activity->level->label(), $activity->title),
            sprintf('Evidencia %s  ·  original SHA-256 %s…', substr($uuid, 0, 8), substr($originalSha256, 0, 12)),
        ];
    }

    private function locationStatus(CaptureLocation $location): LocationStatus
    {
        if (!$location->hasCoordinates()) {
            return $location->reported;
        }

        return $location->accuracyM > $this->settings->lowAccuracyMeters ? LocationStatus::LowAccuracy : LocationStatus::Ok;
    }

    private function canCapture(Contract $contract): bool
    {
        return $contract->status === ContractStatus::Active && $this->isExecutor($contract);
    }

    private function canWithdraw(Evidence $evidence, Contract $contract): bool
    {
        return $contract->status !== ContractStatus::Archived
            && ($this->auth->can(Permission::ContractsManage)
                || ($evidence->capturedBy === $this->auth->userId() && $this->isExecutor($contract)));
    }

    private function isExecutor(Contract $contract): bool
    {
        return $this->auth->can(Permission::EvidenceCapture) && $this->contracts->isOwnContract($contract);
    }

    private function findActivity(string $uuid): Activity
    {
        return (Uuid::isValid($uuid) ? $this->activities->findByUuid($uuid) : null)
            ?? throw new NotFoundException('El elemento no existe.');
    }

    private function contractOf(Activity $activity): Contract
    {
        try {
            return $this->contracts->getById($activity->contractId);
        } catch (NotFoundException) {
            throw new NotFoundException('El elemento no existe.');
        }
    }

    private function find(string $uuid): Evidence
    {
        return (Uuid::isValid($uuid) ? $this->evidences->findByUuid($uuid) : null)
            ?? throw new NotFoundException('La evidencia no existe.');
    }

    private function contractOfEvidence(Evidence $evidence): Contract
    {
        try {
            return $this->contracts->getById($evidence->contractId);
        } catch (NotFoundException) {
            throw new NotFoundException('La evidencia no existe.');
        }
    }

    private static function decimal(?float $value, int $decimals): ?string
    {
        return $value === null ? null : number_format($value, $decimals, '.', '');
    }
}
