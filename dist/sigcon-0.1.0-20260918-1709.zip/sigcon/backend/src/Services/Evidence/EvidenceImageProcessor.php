<?php

declare(strict_types=1);

namespace Sigcon\Services\Evidence;

use GdImage;
use Psr\Http\Message\UploadedFileInterface;
use RuntimeException;
use Sigcon\Config\EvidenceSettings;
use Sigcon\Exceptions\FileException;

/**
 * Procesamiento de fotografías de evidencia con GD (ADR-006):
 *
 * - Valida la foto por su contenido real (finfo + decodificación), nunca por lo que declara el
 *   navegador. Formatos: JPEG, PNG y WebP.
 * - Limita la resolución antes de decodificar (la memoria de GD crece con los megapíxeles).
 * - Genera la versión oficial: orientación EXIF aplicada, redimensionada al lado máximo
 *   configurado y con la marca de agua dibujada en el servidor. Se codifica como JPEG nuevo,
 *   de modo que no conserva los metadatos del original.
 * - Genera la miniatura a partir de la versión oficial (nunca se expone el original sin marca).
 *
 * El original no se modifica: lo guarda el servicio byte a byte.
 */
final class EvidenceImageProcessor
{
    /** tipo MIME real => extensión con la que se guarda el original */
    public const FORMATS = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

    public function __construct(private readonly EvidenceSettings $settings)
    {
    }

    /**
     * @return array{path: string, mime: string, extension: string, size: int, sha256: string, width: int, height: int}
     */
    public function validate(?UploadedFileInterface $file): array
    {
        if ($file === null) {
            throw self::error('required', 'Tome o seleccione una fotografía.');
        }
        $error = $file->getError();
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            throw self::error('too_large', $this->sizeMessage());
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw self::error('upload_failed', 'La fotografía no se recibió completa. Intente de nuevo.');
        }
        $path = $file->getStream()->getMetadata('uri');
        if (!is_string($path) || !is_file($path)) {
            throw self::error('upload_failed', 'La fotografía no se recibió correctamente.');
        }
        $size = (int) filesize($path);
        if ($size === 0) {
            throw self::error('empty', 'La fotografía está vacía.');
        }
        if ($size > $this->settings->maxBytes) {
            throw self::error('too_large', $this->sizeMessage());
        }

        $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($path);
        if (in_array($mime, ['image/heic', 'image/heif', 'image/avif'], true)) {
            throw self::error('unsupported_format', 'El formato HEIC/HEIF no es compatible. Use la cámara de SIGCON o configure el teléfono para tomar fotos en JPEG ("Más compatible").');
        }
        if (!isset(self::FORMATS[$mime])) {
            throw self::error('not_an_image', 'El archivo no es una fotografía válida. Se aceptan JPEG, PNG y WebP.');
        }
        $info = @getimagesize($path);
        if ($info === false || $info[0] < 1 || $info[1] < 1) {
            throw self::error('invalid_content', 'La fotografía está dañada o no es válida.');
        }
        if ($info[0] * $info[1] > $this->settings->maxMegapixels * 1_000_000) {
            throw self::error('too_many_pixels', sprintf('La fotografía supera la resolución máxima permitida (%d megapíxeles).', $this->settings->maxMegapixels));
        }
        [$width, $height] = in_array(self::orientation($path, $mime), [5, 6, 7, 8], true) ? [$info[1], $info[0]] : [$info[0], $info[1]];

        return [
            'path' => $path,
            'mime' => $mime,
            'extension' => self::FORMATS[$mime],
            'size' => $size,
            'sha256' => (string) hash_file('sha256', $path),
            'width' => $width,
            'height' => $height,
        ];
    }

    /**
     * Genera la versión oficial (JPEG con marca de agua) y la miniatura.
     *
     * @param list<string> $lines líneas de la marca de agua; la primera va en negrilla
     * @return array{official: string, thumbnail: string}
     */
    public function render(string $path, string $mime, array $lines): array
    {
        $info = @getimagesize($path);
        if ($info === false) {
            throw self::error('invalid_content', 'La fotografía está dañada o no es válida.');
        }
        $this->ensureMemory($info[0], $info[1]);

        $source = @imagecreatefromstring((string) file_get_contents($path));
        if (!$source instanceof GdImage) {
            throw self::error('invalid_content', 'La fotografía está dañada o no es válida.');
        }
        $source = self::applyOrientation($source, self::orientation($path, $mime));
        $official = $this->resized($source, $this->settings->officialMaxSide);
        imagedestroy($source);

        $this->drawWatermark($official, $lines);
        $officialJpeg = $this->jpeg($official);

        $thumbnail = $this->resized($official, $this->settings->thumbnailSide);
        imagedestroy($official);
        $thumbnailJpeg = $this->jpeg($thumbnail);
        imagedestroy($thumbnail);

        return ['official' => $officialJpeg, 'thumbnail' => $thumbnailJpeg];
    }

    /** Valor EXIF Orientation (1 = normal). Solo JPEG trae EXIF confiable. */
    public static function orientation(string $path, string $mime): int
    {
        if ($mime !== 'image/jpeg' || !function_exists('exif_read_data')) {
            return 1;
        }
        $exif = @exif_read_data($path);
        $value = is_array($exif) ? ($exif['Orientation'] ?? 1) : 1;

        return is_int($value) && $value >= 1 && $value <= 8 ? $value : 1;
    }

    public static function applyOrientation(GdImage $image, int $orientation): GdImage
    {
        // imagerotate gira en sentido antihorario.
        $rotation = match ($orientation) {
            3, 4 => 180,
            5, 6 => 270,
            7, 8 => 90,
            default => 0,
        };
        if ($rotation !== 0) {
            $rotated = imagerotate($image, $rotation, 0);
            if ($rotated === false) {
                throw new RuntimeException('No fue posible orientar la fotografía.');
            }
            imagedestroy($image);
            $image = $rotated;
        }
        if (in_array($orientation, [2, 4, 5, 7], true)) {
            imageflip($image, IMG_FLIP_HORIZONTAL);
        }

        return $image;
    }

    /**
     * Marca de agua con diseño propio de SIGCON: franja inferior translúcida, barra de acento y
     * texto blanco con sombra. El tamaño se adapta a la foto; las líneas largas se recortan.
     *
     * @param list<string> $lines
     */
    public function drawWatermark(GdImage $image, array $lines): void
    {
        $width = imagesx($image);
        $height = imagesy($image);
        $fontSize = (int) max(10, min(38, round(min($width, $height) * 0.026)));
        $lineHeight = (int) round($fontSize * 1.55);
        $padding = (int) round($fontSize * 0.9);
        $accent = (int) max(3, round($fontSize * 0.35));
        $bandHeight = min($height, $padding * 2 + $lineHeight * count($lines));
        $top = $height - $bandHeight;

        imagealphablending($image, true);
        imagefilledrectangle($image, 0, $top, $width - 1, $height - 1, (int) imagecolorallocatealpha($image, 12, 24, 43, 40));
        imagefilledrectangle($image, 0, $top, $accent - 1, $height - 1, (int) imagecolorallocate($image, 242, 183, 5));

        $white = (int) imagecolorallocate($image, 255, 255, 255);
        $shadow = (int) imagecolorallocatealpha($image, 0, 0, 0, 60);
        $x = $accent + $padding;
        $maxWidth = $width - $x - $padding;
        foreach ($lines as $i => $line) {
            $font = $i === 0 ? $this->settings->boldFontPath : $this->settings->fontPath;
            $size = $i === 0 ? $fontSize * 1.05 : $fontSize * 0.9;
            $text = $this->fit($line, $font, $size, $maxWidth);
            $y = $top + $padding + ($i + 1) * $lineHeight - (int) round($lineHeight * 0.3);
            imagettftext($image, $size, 0, $x + 1, $y + 1, $shadow, $font, $text);
            imagettftext($image, $size, 0, $x, $y, $white, $font, $text);
        }
    }

    private function fit(string $text, string $font, float $size, int $maxWidth): string
    {
        if ($this->textWidth($text, $font, $size) <= $maxWidth) {
            return $text;
        }
        while (mb_strlen($text) > 1 && $this->textWidth($text . '…', $font, $size) > $maxWidth) {
            $text = mb_substr($text, 0, -1);
        }

        return rtrim($text) . '…';
    }

    private function textWidth(string $text, string $font, float $size): int
    {
        $box = imagettfbbox($size, 0, $font, $text);

        return $box === false ? PHP_INT_MAX : abs($box[2] - $box[0]);
    }

    private function resized(GdImage $image, int $maxSide): GdImage
    {
        $width = imagesx($image);
        $height = imagesy($image);
        $scale = min(1, $maxSide / max($width, $height));
        $newWidth = max(1, (int) round($width * $scale));
        $newHeight = max(1, (int) round($height * $scale));

        $target = imagecreatetruecolor($newWidth, $newHeight);
        if ($target === false) {
            throw new RuntimeException('No fue posible procesar la fotografía.');
        }
        // Fondo blanco: las transparencias de PNG/WebP no existen en JPEG.
        imagefill($target, 0, 0, (int) imagecolorallocate($target, 255, 255, 255));
        imagecopyresampled($target, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        return $target;
    }

    private function jpeg(GdImage $image): string
    {
        imageinterlace($image, true);
        ob_start();
        imagejpeg($image, null, $this->settings->jpegQuality);

        return (string) ob_get_clean();
    }

    /**
     * GD necesita ~5 bytes por píxel para la imagen decodificada más la copia redimensionada.
     * Si el límite de memoria de PHP no alcanza, se intenta ampliar solo para esta petición.
     */
    private function ensureMemory(int $width, int $height): void
    {
        $needed = $width * $height * 5 + 64 * 1024 * 1024 + memory_get_usage();
        $limit = self::bytes((string) ini_get('memory_limit'));
        if ($limit === -1 || $limit >= $needed) {
            return;
        }
        if (ini_set('memory_limit', (string) (int) ceil($needed / 1048576) . 'M') === false) {
            throw self::error('too_many_pixels', 'El servidor no tiene memoria suficiente para procesar una fotografía de esta resolución.');
        }
    }

    private static function bytes(string $value): int
    {
        $value = trim($value);
        if ($value === '-1') {
            return -1;
        }
        $number = (int) $value;

        return match (strtolower(substr($value, -1))) {
            'g' => $number * 1024 ** 3,
            'm' => $number * 1024 ** 2,
            'k' => $number * 1024,
            default => $number,
        };
    }

    private function sizeMessage(): string
    {
        return sprintf('La fotografía supera el tamaño máximo permitido (%d MB).', intdiv($this->settings->maxBytes, 1024 * 1024));
    }

    private static function error(string $code, string $message): FileException
    {
        return new FileException($message, [['field' => 'photo', 'code' => $code, 'message' => $message]]);
    }
}
