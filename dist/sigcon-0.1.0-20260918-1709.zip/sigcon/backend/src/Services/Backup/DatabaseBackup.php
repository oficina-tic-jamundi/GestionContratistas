<?php

declare(strict_types=1);

namespace Sigcon\Services\Backup;

use DateTimeZone;
use RuntimeException;
use Sigcon\Config\BackupSettings;
use Sigcon\Config\DatabaseSettings;
use Sigcon\Config\Settings;
use Sigcon\Helpers\Clock;

/**
 * Backup de la base de datos: mysqldump → gzip → cifrado autenticado (BackupCipher), en
 * streaming. Las credenciales van en un archivo temporal 0600 (nunca en la línea de comandos,
 * donde otros procesos del servidor podrían verlas). Un backup fallido no deja archivos.
 */
final class DatabaseBackup
{
    private const CHUNK = 1 << 20; // 1 MiB
    private const PATTERN = '/^sigcon-db-(\d{8})-(\d{6})\.sql\.gz\.enc$/';

    public function __construct(
        private readonly BackupSettings $backup,
        private readonly Settings $settings,
        private readonly Clock $clock,
    ) {
    }

    /** @return array{file: string, bytes: int} */
    public function run(): array
    {
        $key = $this->backup->key(); // antes de todo: sin clave no hay backup (nunca en claro)
        $this->ensureDirectory($this->backup->path);
        $now = $this->clock->now()->setTimezone(new DateTimeZone(date_default_timezone_get()));
        $file = $this->backup->path . DIRECTORY_SEPARATOR . sprintf('sigcon-db-%s.sql.gz.enc', $now->format('Ymd-His'));
        $partial = $file . '.part';
        $credentials = $this->credentialsFile($this->settings->database);

        try {
            $this->dump($credentials, $partial, $key);
            if (!rename($partial, $file)) {
                throw new RuntimeException('No fue posible finalizar el archivo de backup.');
            }
            @chmod($file, 0600);
        } finally {
            @unlink($credentials);
            if (is_file($partial)) {
                @unlink($partial);
            }
        }

        return ['file' => $file, 'bytes' => (int) filesize($file)];
    }

    /**
     * Conserva los últimos `keepDaily` backups y, además, el primero de cada uno de los
     * últimos `keepMonthly` meses. Elimina el resto.
     *
     * @return list<string> archivos eliminados
     */
    public function prune(): array
    {
        $files = [];
        foreach (is_dir($this->backup->path) ? (scandir($this->backup->path) ?: []) : [] as $name) {
            if (preg_match(self::PATTERN, $name, $m) === 1) {
                $files[$name] = $m[1] . $m[2];
            }
        }
        arsort($files, SORT_STRING); // más reciente primero
        $keep = array_slice(array_keys($files), 0, $this->backup->keepDaily);
        $monthly = [];
        foreach (array_reverse($files, true) as $name => $stamp) { // más antiguo primero: el primero de cada mes
            $month = substr($stamp, 0, 6);
            $monthly[$month] ??= $name;
        }
        krsort($monthly);
        $keep = array_merge($keep, array_slice(array_values($monthly), 0, $this->backup->keepMonthly));

        $deleted = [];
        foreach (array_keys($files) as $name) {
            if (!in_array($name, $keep, true) && @unlink($this->backup->path . DIRECTORY_SEPARATOR . $name)) {
                $deleted[] = $name;
            }
        }

        return $deleted;
    }

    public function decrypt(string $encrypted, string $target): void
    {
        $input = @fopen($encrypted, 'rb');
        if ($input === false) {
            throw new RuntimeException('No se encontró el archivo de backup.');
        }
        $output = fopen($target, 'wb');
        if ($output === false) {
            fclose($input);
            throw new RuntimeException('No fue posible crear el archivo de salida.');
        }
        try {
            BackupCipher::decrypt($input, $output, $this->backup->key());
        } catch (\Throwable $e) {
            fclose($output);
            @unlink($target);
            throw $e;
        } finally {
            fclose($input);
            if (is_resource($output)) {
                fclose($output);
            }
        }
    }

    private function dump(string $credentials, string $partial, #[\SensitiveParameter] string $key): void
    {
        $deflate = deflate_init(ZLIB_ENCODING_GZIP, ['level' => 6]);
        if ($deflate === false) {
            throw new RuntimeException('No fue posible iniciar la compresión (extensión zlib).');
        }
        $output = fopen($partial, 'xb');
        if ($output === false) {
            throw new RuntimeException('No fue posible crear el archivo de backup.');
        }
        $command = [
            $this->backup->mysqldump,
            '--defaults-extra-file=' . $credentials,
            '--single-transaction',
            '--quick',
            '--routines',
            '--triggers',
            '--no-tablespaces', // en hosting compartido no se tiene el privilegio PROCESS
            '--default-character-set=utf8mb4',
            $this->settings->database->database,
        ];
        $process = proc_open($command, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        if (!is_resource($process)) {
            fclose($output);
            throw new RuntimeException('No fue posible ejecutar mysqldump. Revise BACKUP_MYSQLDUMP_PATH.');
        }
        $cipher = BackupCipher::encryptTo($output, $key);
        try {
            while (!feof($pipes[1])) {
                $chunk = fread($pipes[1], self::CHUNK);
                if ($chunk === false || $chunk === '') {
                    continue;
                }
                $compressed = deflate_add($deflate, $chunk, ZLIB_NO_FLUSH);
                if ($compressed !== '' && $compressed !== false) {
                    $cipher->push($output, $compressed);
                }
            }
            $cipher->push($output, (string) deflate_add($deflate, '', ZLIB_FINISH), true);
            $errors = trim((string) stream_get_contents($pipes[2]));
        } finally {
            fclose($pipes[1]);
            fclose($pipes[2]);
            $exit = proc_close($process);
            fclose($output);
        }
        if ($exit !== 0) {
            // stderr de mysqldump no incluye la contraseña (va en el archivo de opciones).
            throw new RuntimeException('mysqldump terminó con error: ' . mb_substr($errors, 0, 300));
        }
    }

    /** Archivo de opciones de MySQL con las credenciales, legible solo por el propietario. */
    private function credentialsFile(DatabaseSettings $db): string
    {
        $dir = $this->settings->storagePath . DIRECTORY_SEPARATOR . 'tmp';
        $this->ensureDirectory($dir);
        $file = $dir . DIRECTORY_SEPARATOR . 'backup-' . bin2hex(random_bytes(8)) . '.cnf';
        $escape = static fn (string $v): string => '"' . addcslashes($v, "\\\"") . '"';
        $content = "[client]\nhost={$escape($db->host)}\nport={$db->port}\nuser={$escape($db->username)}\npassword={$escape($db->password)}\n";
        $handle = fopen($file, 'xb');
        if ($handle === false) {
            throw new RuntimeException('No fue posible preparar las credenciales temporales.');
        }
        @chmod($file, 0600);
        fwrite($handle, $content);
        fclose($handle);

        return $file;
    }

    private function ensureDirectory(string $dir): void
    {
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('No fue posible crear el directorio de backups.');
        }
    }
}
