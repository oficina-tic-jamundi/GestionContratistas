<?php

declare(strict_types=1);

namespace Sigcon\Services\Backup;

use RuntimeException;

/**
 * Cifrado autenticado por bloques (libsodium secretstream, XChaCha20-Poly1305) para archivos
 * de backup de cualquier tamaño, sin cargarlos completos en memoria.
 *
 * Formato: "SIGCONBK1" + cabecera de secretstream + [longitud (4 bytes, big-endian) + bloque]…
 * El último bloque lleva la marca FINAL: un archivo truncado o alterado no se descifra.
 */
final class BackupCipher
{
    private const MAGIC = 'SIGCONBK1';

    private mixed $state;

    private function __construct(mixed $state)
    {
        $this->state = $state;
    }

    /**
     * Inicia el cifrado y escribe la cabecera en el destino.
     *
     * @param resource $output
     */
    public static function encryptTo($output, #[\SensitiveParameter] string $key): self
    {
        [$state, $header] = sodium_crypto_secretstream_xchacha20poly1305_init_push($key);
        self::write($output, self::MAGIC . $header);

        return new self($state);
    }

    /** @param resource $output */
    public function push($output, string $plain, bool $final = false): void
    {
        $tag = $final ? SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL : SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE;
        $cipher = sodium_crypto_secretstream_xchacha20poly1305_push($this->state, $plain, '', $tag);
        self::write($output, pack('N', strlen($cipher)) . $cipher);
    }

    /**
     * Descifra un archivo completo hacia el destino.
     *
     * @param resource $input
     * @param resource $output
     */
    public static function decrypt($input, $output, #[\SensitiveParameter] string $key): void
    {
        $magic = fread($input, strlen(self::MAGIC));
        if ($magic !== self::MAGIC) {
            throw new RuntimeException('El archivo no es un backup cifrado de SIGCON.');
        }
        $header = fread($input, SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES);
        if (!is_string($header) || strlen($header) !== SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES) {
            throw new RuntimeException('Cabecera del backup incompleta.');
        }
        $state = sodium_crypto_secretstream_xchacha20poly1305_init_pull($header, $key);
        $finished = false;
        while (!$finished) {
            $length = fread($input, 4);
            if (!is_string($length) || strlen($length) !== 4) {
                throw new RuntimeException('El backup está incompleto (truncado).');
            }
            $size = unpack('N', $length)[1] ?? 0;
            $cipher = $size > 0 ? self::readExactly($input, (int) $size) : '';
            $result = sodium_crypto_secretstream_xchacha20poly1305_pull($state, $cipher);
            if ($result === false) {
                throw new RuntimeException('El backup fue alterado o la clave no corresponde.');
            }
            [$plain, $tag] = $result;
            self::write($output, $plain);
            $finished = $tag === SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL;
        }
    }

    /** @param resource $input */
    private static function readExactly($input, int $size): string
    {
        $data = '';
        while (strlen($data) < $size && !feof($input)) {
            $chunk = fread($input, max(1, $size - strlen($data)));
            if ($chunk === false) {
                break;
            }
            $data .= $chunk;
        }
        if (strlen($data) !== $size) {
            throw new RuntimeException('El backup está incompleto (truncado).');
        }

        return $data;
    }

    /** @param resource $output */
    private static function write($output, string $data): void
    {
        if (fwrite($output, $data) !== strlen($data)) {
            throw new RuntimeException('No fue posible escribir el backup.');
        }
    }
}
