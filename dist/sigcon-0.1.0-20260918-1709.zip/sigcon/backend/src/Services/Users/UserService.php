<?php

declare(strict_types=1);

namespace Sigcon\Services\Users;

use PDOException;
use Sigcon\Database\Database;
use Sigcon\DTOs\CreateUserData;
use Sigcon\DTOs\UpdateUserData;
use Sigcon\DTOs\UserFilters;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Role;
use Sigcon\Models\User;
use Sigcon\Models\UserStatus;
use Sigcon\Repositories\RoleRepository;
use Sigcon\Repositories\UserRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\PasswordHasher;
use Sigcon\Security\PasswordPolicy;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Auth\SessionService;
use Sigcon\Services\Departments\DepartmentService;

/**
 * Administración de usuarios.
 *
 * Reglas de negocio:
 * - El correo es único (también frente a usuarios retirados).
 * - Siempre debe quedar al menos un administrador activo.
 * - Un usuario no puede desactivarse, cambiar sus propios roles ni restablecer su propia
 *   contraseña desde la administración (usa "cambiar contraseña").
 * - Desactivar o restablecer la contraseña cierra todas las sesiones del usuario.
 * - Las contraseñas temporales obligan a cambiarla en el siguiente inicio de sesión.
 *
 * La autorización por permiso se verifica antes (middleware / controlador).
 */
final class UserService
{
    public function __construct(
        private readonly UserRepository $users,
        private readonly RoleRepository $roles,
        private readonly SessionService $sessions,
        private readonly DepartmentService $departments,
        private readonly PasswordHasher $hasher,
        private readonly PasswordPolicy $policy,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /** @return array{page: Page<User>, roles: array<int, list<array{code: string, name: string}>>} */
    public function list(UserFilters $filters, PageRequest $page): array
    {
        $result = $this->users->paginate($filters, $page);

        return [
            'page' => $result,
            'roles' => $this->users->rolesForUsers(array_map(static fn (User $u) => $u->id, $result->items)),
        ];
    }

    public function get(string $uuid): User
    {
        if (!Uuid::isValid($uuid)) {
            throw new NotFoundException('El usuario no existe.');
        }

        return $this->users->findByUuid($uuid) ?? throw new NotFoundException('El usuario no existe.');
    }

    /** @return list<array{code: string, name: string}> */
    public function rolesOf(User $user): array
    {
        return $this->users->rolesFor($user->id);
    }

    /**
     * @return array{user: User, temporary_password: string}
     */
    public function create(CreateUserData $data): array
    {
        $roleIds = $this->resolveRoleIds($data->roles);
        $departmentId = $data->departmentUuid === null ? null : $this->departments->requireActive($data->departmentUuid)->id;
        $temporaryPassword = $this->policy->generateTemporary();
        $hash = $this->hasher->hash($temporaryPassword);
        $actorId = $this->auth->userId();

        $user = $this->db->transaction(function () use ($data, $roleIds, $hash, $actorId, $departmentId): User {
            if ($this->users->emailExists($data->email)) {
                throw $this->emailTaken();
            }
            $now = $this->clock->now();
            try {
                $id = $this->users->create(Uuid::v4(), $data->firstName, $data->lastName, $data->email, $data->phone, $hash, true, $now, $actorId, $departmentId);
            } catch (PDOException $e) {
                // Carrera: otra petición creó el mismo correo entre la verificación y el INSERT.
                throw Database::isUniqueViolation($e) ? $this->emailTaken() : $e;
            }
            $this->users->replaceRoles($id, array_values($roleIds), $now, $actorId);
            $user = $this->users->findById($id) ?? throw new \LogicException('Usuario recién creado no encontrado.');

            $this->audit->record(AuditAction::UserCreated, 'user', $user->uuid, [
                'email' => $user->email,
                'roles' => array_keys($roleIds),
            ]);

            return $user;
        });

        return ['user' => $user, 'temporary_password' => $temporaryPassword];
    }

    public function update(string $uuid, UpdateUserData $data): User
    {
        $user = $this->get($uuid);
        $actorId = $this->auth->userId();
        $roleIds = $data->roles === null ? null : $this->resolveRoleIds($data->roles);
        $fields = $data->fields;
        if ($data->departmentProvided) {
            $fields['department_id'] = $data->departmentUuid === null
                ? null
                : (string) $this->departments->requireActive($data->departmentUuid)->id;
        }

        if ($roleIds !== null && $actorId === $user->id) {
            throw new BusinessRuleException('No puede modificar sus propios roles. Solicítelo a otro administrador.');
        }

        return $this->db->transaction(function () use ($user, $fields, $roleIds, $actorId): User {
            $this->users->lockById($user->id);
            $now = $this->clock->now();

            $changes = $this->diff($user, $fields);
            if (isset($changes['email']) && $this->users->emailExists((string) $changes['email']['to'], $user->id)) {
                throw $this->emailTaken();
            }
            if ($changes !== []) {
                try {
                    $this->users->update($user->id, array_map(static fn (array $c) => $c['to'], $changes), $now, $actorId);
                } catch (PDOException $e) {
                    throw Database::isUniqueViolation($e) ? $this->emailTaken() : $e;
                }
                $this->audit->record(AuditAction::UserUpdated, 'user', $user->uuid, ['changes' => $changes]);
            }

            if ($roleIds !== null) {
                $current = array_column($this->users->rolesFor($user->id), 'code');
                $new = array_keys($roleIds);
                sort($current);
                sort($new);
                if ($current !== $new) {
                    if (in_array(Role::ADMIN, $current, true) && !in_array(Role::ADMIN, $new, true)) {
                        $this->assertAnotherActiveAdmin($user->id);
                    }
                    $this->users->replaceRoles($user->id, array_values($roleIds), $now, $actorId);
                    // Los permisos se recalculan en cada petición: el cambio aplica de inmediato.
                    $this->audit->record(AuditAction::UserRolesChanged, 'user', $user->uuid, ['from' => $current, 'to' => $new]);
                }
            }

            return $this->users->findById($user->id) ?? throw new \LogicException('Usuario no encontrado.');
        });
    }

    public function activate(string $uuid): User
    {
        return $this->changeStatus($uuid, UserStatus::Active);
    }

    public function deactivate(string $uuid): User
    {
        return $this->changeStatus($uuid, UserStatus::Inactive);
    }

    /** @return array{user: User, temporary_password: string} */
    public function resetPassword(string $uuid): array
    {
        $user = $this->get($uuid);
        if ($this->auth->userId() === $user->id) {
            throw new BusinessRuleException('Para cambiar su propia contraseña use la opción "Cambiar contraseña".');
        }
        $temporaryPassword = $this->policy->generateTemporary();
        $hash = $this->hasher->hash($temporaryPassword);

        $this->db->transaction(function () use ($user, $hash): void {
            $this->users->updatePassword($user->id, $hash, true, $this->clock->now(), $this->auth->userId());
            $revoked = $this->sessions->revokeAllForUser($user->id, 'password_reset');
            $this->audit->record(AuditAction::UserPasswordReset, 'user', $user->uuid, ['sessions_revoked' => $revoked]);
        });

        return ['user' => $this->get($uuid), 'temporary_password' => $temporaryPassword];
    }

    private function changeStatus(string $uuid, UserStatus $status): User
    {
        $user = $this->get($uuid);
        if ($user->status === $status) {
            return $user; // idempotente: no genera auditoría duplicada
        }
        if ($status === UserStatus::Inactive && $this->auth->userId() === $user->id) {
            throw new BusinessRuleException('No puede desactivar su propia cuenta.');
        }

        $this->db->transaction(function () use ($user, $status): void {
            $this->users->lockById($user->id);
            if ($status === UserStatus::Inactive) {
                if (in_array(Role::ADMIN, array_column($this->users->rolesFor($user->id), 'code'), true)) {
                    $this->assertAnotherActiveAdmin($user->id);
                }
                $revoked = $this->sessions->revokeAllForUser($user->id, 'user_deactivated');
                $this->users->setStatus($user->id, $status, $this->clock->now(), $this->auth->userId());
                $this->audit->record(AuditAction::UserDeactivated, 'user', $user->uuid, ['sessions_revoked' => $revoked]);
            } else {
                $this->users->setStatus($user->id, $status, $this->clock->now(), $this->auth->userId());
                $this->audit->record(AuditAction::UserActivated, 'user', $user->uuid);
            }
        });

        return $this->get($uuid);
    }

    private function assertAnotherActiveAdmin(int $userId): void
    {
        if ($this->users->countActiveWithRole(Role::ADMIN, $userId) === 0) {
            throw new BusinessRuleException('Debe existir al menos un administrador activo en el sistema.');
        }
    }

    /**
     * @param list<string> $codes
     * @return array<string, int>
     */
    private function resolveRoleIds(array $codes): array
    {
        $ids = $this->roles->idsByCodes($codes);
        $unknown = array_diff($codes, array_keys($ids));
        if ($unknown !== []) {
            throw ValidationException::field('roles', 'unknown_role', sprintf('Rol no existe: %s', implode(', ', $unknown)));
        }

        return $ids;
    }

    /**
     * @param array<string, string|null> $fields
     * @return array<string, array{from: string|null, to: string|null}>
     */
    private function diff(User $user, array $fields): array
    {
        $current = [
            'first_name' => $user->firstName,
            'last_name' => $user->lastName,
            'email' => $user->email,
            'phone' => $user->phone,
            'department_id' => $user->departmentId === null ? null : (string) $user->departmentId,
        ];
        $changes = [];
        foreach ($fields as $column => $value) {
            if ($current[$column] !== $value) {
                $changes[$column] = ['from' => $current[$column], 'to' => $value];
            }
        }

        return $changes;
    }

    private function emailTaken(): ValidationException
    {
        return ValidationException::field('email', 'taken', 'Ya existe un usuario con este correo electrónico.');
    }
}
