<?php

declare(strict_types=1);

namespace Sigcon\Services\Contracts;

use PDOException;
use Sigcon\Database\Database;
use Sigcon\DTOs\ContractData;
use Sigcon\DTOs\ContractFilters;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Contract;
use Sigcon\Models\ContractStatus;
use Sigcon\Models\HistoryEntry;
use Sigcon\Models\User;
use Sigcon\Repositories\BusinessHistoryRepository;
use Sigcon\Repositories\ContractRepository;
use Sigcon\Repositories\ContractScope;
use Sigcon\Repositories\UserRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\Permission;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Contractors\ContractorService;
use Sigcon\Services\Departments\DepartmentService;
use Sigcon\Services\History\HistoryRecorder;

/**
 * Contratos: creación en borrador, edición del borrador, cambios de estado, cambio de supervisor.
 *
 * Reglas (ver ADR-012):
 * - Toda lectura aplica el alcance del usuario (ContractScope): fuera de alcance = 404.
 * - Solo el borrador se edita libremente. Las modificaciones a contratos en ejecución (otrosí,
 *   adición, prórroga) quedan PENDIENTES de definición institucional.
 * - Activar exige supervisor elegible, contratista y dependencia activos.
 * - El supervisor debe ser un usuario activo con permiso contracts.supervise y no puede ser el
 *   propio contratista.
 * - Las transiciones siguen ContractStatus y algunas exigen observación.
 * - Cada cambio queda en el historial de negocio y en la auditoría, en la misma transacción.
 */
final class ContractService
{
    public function __construct(
        private readonly ContractRepository $contracts,
        private readonly BusinessHistoryRepository $history,
        private readonly ContractorService $contractors,
        private readonly DepartmentService $departments,
        private readonly UserRepository $users,
        private readonly HistoryRecorder $recorder,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /** @return Page<Contract> */
    public function list(ContractFilters $filters, PageRequest $page): Page
    {
        return $this->contracts->paginate($filters, $page, ContractScope::forUser($this->auth));
    }

    public function get(string $uuid): Contract
    {
        $contract = Uuid::isValid($uuid) ? $this->contracts->findByUuid($uuid, ContractScope::forUser($this->auth)) : null;

        return $contract ?? throw new NotFoundException('El contrato no existe.');
    }

    /** Contrato por id interno, aplicando el alcance del usuario (fuera de alcance = 404). */
    public function getById(int $id): Contract
    {
        return $this->contracts->findById($id, ContractScope::forUser($this->auth))
            ?? throw new NotFoundException('El contrato no existe.');
    }

    /** ¿El usuario actual es el contratista (cuenta vinculada) de este contrato? */
    public function isOwnContract(Contract $contract): bool
    {
        return $contract->contractorUserId !== null && $contract->contractorUserId === $this->auth->userId();
    }

    /** Relectura tras una escritura ya autorizada (no depende del alcance de lectura del usuario). */
    private function reload(string $uuid): Contract
    {
        return $this->contracts->findByUuid($uuid, ContractScope::unrestricted())
            ?? throw new \LogicException('Contrato no encontrado tras la escritura.');
    }

    /** @return list<HistoryEntry> */
    public function history(string $uuid): array
    {
        return $this->history->forEntity(HistoryRecorder::CONTRACT, $this->get($uuid)->id);
    }

    /** @return list<User> usuarios activos que pueden ser designados supervisores */
    public function supervisorCandidates(): array
    {
        return $this->users->activeWithPermission(Permission::ContractsSupervise->value);
    }

    public function create(ContractData $data): Contract
    {
        $refs = $this->resolveRefs($data);

        return $this->db->transaction(function () use ($data, $refs): Contract {
            if ($this->contracts->numberExists($data->contractNumber)) {
                throw $this->numberTaken();
            }
            $uuid = Uuid::v4();
            try {
                $id = $this->contracts->create($uuid, $data, $refs, $this->clock->now(), $this->auth->userId());
            } catch (PDOException $e) {
                throw Database::isUniqueViolation($e) ? $this->numberTaken() : $e;
            }
            $this->recorder->record(HistoryRecorder::CONTRACT, $id, 'created', 'Contrato registrado en borrador', toStatus: ContractStatus::Draft->value);
            $this->audit->record(AuditAction::ContractCreated, 'contract', $uuid, ['number' => $data->contractNumber]);

            return $this->reload($uuid);
        });
    }

    public function update(string $uuid, ContractData $data): Contract
    {
        $contract = $this->get($uuid);
        $refs = $this->resolveRefs($data);

        return $this->db->transaction(function () use ($contract, $data, $refs): Contract {
            $status = $this->contracts->lockStatus($contract->id) ?? throw new NotFoundException('El contrato no existe.');
            if (!$status->isEditable()) {
                throw new BusinessRuleException(sprintf(
                    'Un contrato %s no se puede modificar libremente. Las modificaciones a contratos en ejecución (otrosí) aún no están habilitadas.',
                    mb_strtolower($status->label()),
                ));
            }
            if ($this->contracts->numberExists($data->contractNumber, $contract->id)) {
                throw $this->numberTaken();
            }
            try {
                $this->contracts->update($contract->id, $data, $refs, $this->clock->now(), $this->auth->userId());
            } catch (PDOException $e) {
                throw Database::isUniqueViolation($e) ? $this->numberTaken() : $e;
            }
            $changes = $this->diff($contract, $data, $refs);
            if ($changes !== []) {
                $this->recorder->record(HistoryRecorder::CONTRACT, $contract->id, 'updated', 'Datos del borrador modificados', metadata: ['fields' => array_keys($changes)]);
                $this->audit->record(AuditAction::ContractUpdated, 'contract', $contract->uuid, ['changes' => $changes]);
            }

            return $this->reload($contract->uuid);
        });
    }

    public function transition(string $uuid, ContractStatus $target, ?string $comment): Contract
    {
        $contract = $this->get($uuid);

        return $this->db->transaction(function () use ($contract, $target, $comment): Contract {
            // Se relee el estado bajo bloqueo: si otro usuario lo cambió, se evalúa contra el estado real.
            $current = $this->contracts->lockStatus($contract->id) ?? throw new NotFoundException('El contrato no existe.');
            if (!$current->canTransitionTo($target)) {
                throw new BusinessRuleException(sprintf(
                    'No es posible pasar un contrato de "%s" a "%s".',
                    $current->label(),
                    $target->label(),
                ));
            }
            if ($current->transitionRequiresComment($target) && ($comment === null || trim($comment) === '')) {
                throw ValidationException::field('comment', 'required', 'Esta acción requiere una observación que explique el motivo.');
            }
            if ($current === ContractStatus::Draft && $target === ContractStatus::Active) {
                $this->assertReadyToActivate($contract);
            }

            $this->contracts->setStatus($contract->id, $target, $this->clock->now(), $this->auth->userId());
            $this->recorder->record(
                HistoryRecorder::CONTRACT,
                $contract->id,
                'status_changed',
                $target->transitionSummary($current),
                $comment,
                $current->value,
                $target->value,
            );
            $this->audit->record(AuditAction::ContractStatusChanged, 'contract', $contract->uuid, [
                'from' => $current->value,
                'to' => $target->value,
            ]);

            return $this->reload($contract->uuid);
        });
    }

    public function changeSupervisor(string $uuid, string $supervisorUuid, ?string $comment): Contract
    {
        $contract = $this->get($uuid);

        return $this->db->transaction(function () use ($contract, $supervisorUuid, $comment): Contract {
            $current = $this->contracts->lockStatus($contract->id) ?? throw new NotFoundException('El contrato no existe.');
            if (!$current->allowsSupervisorChange()) {
                throw new BusinessRuleException(sprintf('No se puede cambiar el supervisor de un contrato %s.', mb_strtolower($current->label())));
            }
            if ($current !== ContractStatus::Draft && ($comment === null || trim($comment) === '')) {
                throw ValidationException::field('comment', 'required', 'Indique el motivo del cambio de supervisor (ej. acto de designación).');
            }
            $supervisor = $this->eligibleSupervisor($supervisorUuid, $contract->contractorUserId);
            if ($supervisor->id === $contract->supervisorId) {
                return $contract;
            }

            $this->contracts->setSupervisor($contract->id, $supervisor->id, $this->clock->now(), $this->auth->userId());
            $this->recorder->record(
                HistoryRecorder::CONTRACT,
                $contract->id,
                'supervisor_changed',
                sprintf('Supervisor designado: %s', $supervisor->fullName()),
                $comment,
                metadata: ['from' => $contract->supervisorName, 'to' => $supervisor->fullName()],
            );
            $this->audit->record(AuditAction::ContractSupervisorChanged, 'contract', $contract->uuid, [
                'from' => $contract->supervisorUuid,
                'to' => $supervisor->uuid,
            ]);

            return $this->reload($contract->uuid);
        });
    }

    /** Solo un borrador puede descartarse (retiro lógico). */
    public function deleteDraft(string $uuid): void
    {
        $contract = $this->get($uuid);

        $this->db->transaction(function () use ($contract): void {
            $current = $this->contracts->lockStatus($contract->id) ?? throw new NotFoundException('El contrato no existe.');
            if ($current !== ContractStatus::Draft) {
                throw new BusinessRuleException('Solo se puede descartar un contrato en borrador. Los demás siguen su ciclo hasta archivarse.');
            }
            $this->contracts->softDelete($contract->id, $this->clock->now(), $this->auth->userId());
            $this->audit->record(AuditAction::ContractDeleted, 'contract', $contract->uuid, ['number' => $contract->contractNumber]);
        });
    }

    /** @return array{contractor_id: int, department_id: int, supervisor_id: ?int} */
    private function resolveRefs(ContractData $data): array
    {
        $contractor = $this->contractors->requireActive($data->contractorUuid);
        $department = $this->departments->requireActive($data->departmentUuid);
        $supervisor = $data->supervisorUuid === null ? null : $this->eligibleSupervisor($data->supervisorUuid, $contractor->userId);

        return ['contractor_id' => $contractor->id, 'department_id' => $department->id, 'supervisor_id' => $supervisor?->id];
    }

    private function eligibleSupervisor(string $uuid, ?int $contractorUserId): User
    {
        $user = Uuid::isValid($uuid) ? $this->users->findByUuid($uuid) : null;
        if ($user === null || !$user->isActive()
            || !in_array(Permission::ContractsSupervise->value, $this->users->permissionsFor($user->id), true)) {
            throw ValidationException::field('supervisor', 'invalid_supervisor', 'Seleccione un supervisor activo habilitado para supervisar contratos.');
        }
        if ($contractorUserId !== null && $user->id === $contractorUserId) {
            throw ValidationException::field('supervisor', 'conflict_of_interest', 'El supervisor no puede ser el mismo contratista.');
        }

        return $user;
    }

    private function assertReadyToActivate(Contract $contract): void
    {
        $errors = [];
        if ($contract->supervisorId === null) {
            $errors[] = ['field' => 'supervisor', 'code' => 'required', 'message' => 'Asigne un supervisor antes de activar el contrato.'];
        } else {
            try {
                $this->eligibleSupervisor((string) $contract->supervisorUuid, $contract->contractorUserId);
            } catch (ValidationException $e) {
                $errors = [...$errors, ...$e->errors()];
            }
        }
        try {
            $this->contractors->requireActive($contract->contractorUuid);
        } catch (ValidationException $e) {
            $errors = [...$errors, ...$e->errors()];
        }
        try {
            $this->departments->requireActive($contract->departmentUuid);
        } catch (ValidationException $e) {
            $errors = [...$errors, ...$e->errors()];
        }
        if ($errors !== []) {
            throw ValidationException::withErrors($errors);
        }
    }

    /**
     * @param array{contractor_id: int, department_id: int, supervisor_id: ?int} $refs
     * @return array<string, array{from: mixed, to: mixed}>
     */
    private function diff(Contract $before, ContractData $after, array $refs): array
    {
        $pairs = [
            'contract_number' => [$before->contractNumber, $after->contractNumber],
            'object' => [$before->object, $after->object],
            'contractor' => [$before->contractorId, $refs['contractor_id']],
            'department' => [$before->departmentId, $refs['department_id']],
            'supervisor' => [$before->supervisorId, $refs['supervisor_id']],
            'signed_at' => [$before->signedAt?->format('Y-m-d'), $after->signedAt?->format('Y-m-d')],
            'start_date' => [$before->startDate->format('Y-m-d'), $after->startDate->format('Y-m-d')],
            'end_date' => [$before->endDate->format('Y-m-d'), $after->endDate->format('Y-m-d')],
            'total_value' => [$before->totalValue, $after->totalValue],
            'secop_url' => [$before->secopUrl, $after->secopUrl],
        ];
        $changes = [];
        foreach ($pairs as $field => [$from, $to]) {
            if ($from !== $to) {
                $changes[$field] = ['from' => $from, 'to' => $to];
            }
        }

        return $changes;
    }

    private function numberTaken(): ValidationException
    {
        return ValidationException::field('contract_number', 'taken', 'Ya existe un contrato con este número.');
    }
}
