<?php

declare(strict_types=1);

namespace Sigcon\Services\System;

use Sigcon\Config\Settings;
use Sigcon\Database\Database;
use Sigcon\Database\Migrator;
use Sigcon\Exceptions\ConfigurationException;
use Sigcon\Services\Jobs\JobAdminService;

/**
 * Verificación del entorno para un despliegue (`php bin/console system:check`).
 * Cada comprobación es "ok", "warning" (funciona, pero conviene corregir) o "error"
 * (algo no va a funcionar). No muestra secretos: solo si están presentes y son válidos.
 */
final class SystemCheck
{
    public const OK = 'ok';
    public const WARNING = 'warning';
    public const ERROR = 'error';

    /** Extensiones sin las cuales SIGCON no funciona. */
    private const REQUIRED_EXTENSIONS = ['pdo_mysql', 'mbstring', 'openssl', 'fileinfo', 'gd', 'dom', 'json'];
    /** Recomendadas: sin ellas algo se degrada, pero el sistema funciona. */
    private const RECOMMENDED_EXTENSIONS = [
        'exif' => 'corrige la orientación de las fotos de evidencia',
        'zip' => 'valida con precisión los documentos DOCX/XLSX',
        'intl' => 'formatos regionales',
        'sodium' => 'criptografía moderna',
    ];

    public function __construct(
        private readonly Settings $settings,
        private readonly Database $database,
        private readonly Migrator $migrator,
        private readonly JobAdminService $jobs,
    ) {
    }

    /** @return list<array{check: string, status: string, detail: string}> */
    public function run(): array
    {
        $results = [];
        $add = static function (string $check, string $status, string $detail) use (&$results): void {
            $results[] = ['check' => $check, 'status' => $status, 'detail' => $detail];
        };

        // --- PHP ---
        $add('PHP', version_compare(PHP_VERSION, '8.3.0', '>=') ? self::OK : self::ERROR, 'Versión ' . PHP_VERSION . ' (se requiere 8.3 o superior)');
        foreach (self::REQUIRED_EXTENSIONS as $extension) {
            $add("Extensión {$extension}", extension_loaded($extension) ? self::OK : self::ERROR, extension_loaded($extension) ? 'Cargada' : 'Falta (obligatoria)');
        }
        foreach (self::RECOMMENDED_EXTENSIONS as $extension => $why) {
            $add("Extensión {$extension}", extension_loaded($extension) ? self::OK : self::WARNING, extension_loaded($extension) ? 'Cargada' : "Falta (recomendada: {$why})");
        }
        if (function_exists('gd_info')) {
            $gd = gd_info();
            $missing = array_keys(array_filter([
                'FreeType' => !($gd['FreeType Support'] ?? false),
                'JPEG' => !($gd['JPEG Support'] ?? false),
                'PNG' => !($gd['PNG Support'] ?? false),
                'WebP' => !($gd['WebP Support'] ?? false),
            ]));
            $add('GD para evidencias', $missing === [] ? self::OK : self::ERROR, $missing === [] ? 'FreeType, JPEG, PNG y WebP disponibles' : 'Sin soporte de: ' . implode(', ', $missing));
        }
        $add('Hash de contraseñas', defined('PASSWORD_ARGON2ID') ? self::OK : self::WARNING, defined('PASSWORD_ARGON2ID') ? 'Argon2id' : 'Argon2id no disponible: se usa bcrypt (seguro, pero Argon2id es preferible)');

        // --- Límites de carga y memoria ---
        $maxUpload = max($this->settings->uploadMaxBytes, $this->settings->evidence->maxBytes);
        $uploadLimit = min(self::bytes((string) ini_get('upload_max_filesize')), self::bytes((string) ini_get('post_max_size')));
        $add('Tamaño de carga', $uploadLimit === -1 || $uploadLimit >= $maxUpload ? self::OK : self::ERROR, sprintf(
            'upload_max_filesize=%s, post_max_size=%s; SIGCON necesita al menos %d MB',
            (string) ini_get('upload_max_filesize'),
            (string) ini_get('post_max_size'),
            intdiv($maxUpload, 1024 * 1024),
        ));
        $memory = self::bytes((string) ini_get('memory_limit'));
        $add('Memoria de PHP', $memory === -1 || $memory >= 256 * 1024 * 1024 ? self::OK : self::WARNING, 'memory_limit=' . (string) ini_get('memory_limit') . ' (recomendado 256M para procesar fotografías)');

        // --- Configuración ---
        $production = $this->settings->environment->isProduction();
        $add('Entorno', self::OK, $this->settings->environment->value . ($this->settings->debug ? ' (con depuración)' : ''));
        try {
            $this->settings->security->authSecret();
            $add('AUTH_SECRET', self::OK, 'Configurado y válido');
        } catch (ConfigurationException $e) {
            $add('AUTH_SECRET', self::ERROR, $e->getMessage());
        }
        $https = str_starts_with($this->settings->appUrl, 'https://');
        $add('APP_URL', $https || !$production ? self::OK : self::ERROR, match (true) {
            $https => 'HTTPS',
            $production => 'Sin HTTPS: la cámara, el GPS y las cookies seguras exigen HTTPS en producción',
            default => 'HTTP (aceptable solo en desarrollo)',
        });
        $add('Cookies seguras', $this->settings->security->cookieSecure || !$production ? self::OK : self::ERROR, $this->settings->security->cookieSecure ? 'Activadas' : 'Desactivadas (aceptable solo en desarrollo)');

        // --- Almacenamiento ---
        foreach (['Almacenamiento' => $this->settings->storagePath, 'Logs' => $this->settings->logPath] as $label => $path) {
            $writable = self::writable($path);
            $add($label, $writable ? self::OK : self::ERROR, $writable ? 'Escribible' : 'No se puede crear o escribir (revise permisos)');
        }
        // Carpetas públicas conocidas: backend/public y, en contexto web, el document root.
        $publicDirs = [$this->settings->rootPath . DIRECTORY_SEPARATOR . 'public'];
        $documentRoot = (string) ($_SERVER['DOCUMENT_ROOT'] ?? '');
        if ($documentRoot !== '') {
            $publicDirs[] = $documentRoot;
        }
        $storage = realpath($this->settings->storagePath);
        $insidePublic = false;
        foreach ($publicDirs as $dir) {
            $public = realpath($dir);
            if ($storage !== false && $public !== false && str_starts_with($storage . DIRECTORY_SEPARATOR, $public . DIRECTORY_SEPARATOR)) {
                $insidePublic = true;
            }
        }
        $add('Almacenamiento fuera del sitio público', $insidePublic ? self::ERROR : self::OK, $insidePublic ? 'STORAGE_PATH está dentro de una carpeta pública' : 'Correcto');
        $fonts = is_file($this->settings->evidence->fontPath) && is_file($this->settings->evidence->boldFontPath);
        $add('Fuentes de la marca de agua', $fonts ? self::OK : self::ERROR, $fonts ? 'Presentes' : 'Faltan backend/resources/fonts/DejaVuSans*.ttf');

        // --- Base de datos ---
        if (!$this->database->isAvailable()) {
            $add('Base de datos', self::ERROR, 'Sin conexión: revise DB_* en .env');

            return $results;
        }
        $add('Base de datos', self::OK, 'Conectada');
        $pending = array_filter($this->migrator->status(), static fn (array $m) => $m['status'] !== 'applied');
        $add('Migraciones', $pending === [] ? self::OK : self::ERROR, $pending === []
            ? 'Todas aplicadas'
            : sprintf('%d sin aplicar o modificadas: ejecute "php bin/console migrate"', count($pending)));

        // --- Cron ---
        $jobs = $this->jobs->status();
        $add('Cron (jobs:run)', $jobs['stale'] ? self::WARNING : self::OK, $jobs['last_run'] === null
            ? 'Nunca se ha ejecutado: configure el Cron de cPanel cada 5 minutos'
            : ($jobs['stale'] ? 'Sin ejecuciones recientes' : 'Ejecutándose'));
        $add('Tareas fallidas', ($jobs['counts']['failed'] ?? 0) > 0 ? self::WARNING : self::OK, sprintf('%d fallida(s)', $jobs['counts']['failed'] ?? 0));

        return $results;
    }

    private static function writable(string $path): bool
    {
        // Igual que la aplicación: si no existe, se intenta crear.
        if (!is_dir($path) && !@mkdir($path, 0750, true) && !is_dir($path)) {
            return false;
        }
        if (!is_writable($path)) {
            return false;
        }
        $probe = $path . DIRECTORY_SEPARATOR . '.write-test-' . bin2hex(random_bytes(4));
        $ok = @file_put_contents($probe, 'ok') === 2;
        @unlink($probe);

        return $ok;
    }

    private static function bytes(string $value): int
    {
        $value = trim($value);
        if ($value === '-1' || $value === '0') {
            return -1;
        }
        $number = (int) $value;

        return match (strtolower(substr($value, -1))) {
            'g' => $number * 1024 ** 3,
            'm' => $number * 1024 ** 2,
            'k' => $number * 1024,
            default => $number,
        };
    }
}
