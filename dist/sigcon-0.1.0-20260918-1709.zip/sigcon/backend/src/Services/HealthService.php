<?php

declare(strict_types=1);

namespace Sigcon\Services;

use DateTimeImmutable;
use DateTimeZone;
use Sigcon\Config\Settings;
use Sigcon\Database\Database;

/**
 * Estado operativo del servicio. Solo expone información no sensible:
 * no incluye versiones de PHP/MySQL, rutas ni detalles de errores.
 */
final class HealthService
{
    public function __construct(
        private readonly Settings $settings,
        private readonly Database $database,
    ) {
    }

    /** @return array{status: string, service: string, version: string, server_time: string, timezone: string, checks: array{database: string}} */
    public function check(): array
    {
        $databaseUp = $this->database->isAvailable();
        $now = new DateTimeImmutable('now', new DateTimeZone($this->settings->timezone));

        return [
            'status' => $databaseUp ? 'ok' : 'degraded',
            'service' => 'sigcon-api',
            'version' => Settings::VERSION,
            'server_time' => $now->format(DATE_ATOM),
            'timezone' => $this->settings->timezone,
            'checks' => ['database' => $databaseUp ? 'ok' : 'unavailable'],
        ];
    }
}
