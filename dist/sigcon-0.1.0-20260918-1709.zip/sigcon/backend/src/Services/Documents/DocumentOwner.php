<?php

declare(strict_types=1);

namespace Sigcon\Services\Documents;

use Sigcon\Models\Contract;
use Sigcon\Models\Report;

/**
 * Entidad a la que pertenece un documento (contrato o informe), ya resuelta con el alcance
 * del usuario. El contrato siempre está presente: de él salen el alcance y la auditoría.
 */
final class DocumentOwner
{
    public function __construct(
        public readonly string $entityType,
        public readonly int $entityId,
        public readonly string $entityUuid,
        public readonly Contract $contract,
        public readonly ?Report $report = null,
    ) {
    }

    /** @return array<string, string> contexto para la auditoría */
    public function auditContext(): array
    {
        return $this->report === null
            ? ['contract' => $this->contract->uuid]
            : ['contract' => $this->contract->uuid, 'report' => $this->report->uuid];
    }
}
