<?php

declare(strict_types=1);

namespace Sigcon\Services\Documents;

use Psr\Http\Message\UploadedFileInterface;
use Sigcon\Config\Settings;
use Sigcon\Exceptions\FileException;

/**
 * Validación estricta de archivos cargados (§52):
 * - Lista blanca de extensiones Y de tipo MIME real (detectado con finfo sobre el contenido).
 *   La extensión declarada debe corresponder al contenido real.
 * - Nunca se confía en el tipo enviado por el navegador ($_FILES['type']).
 * - Verificación adicional del contenido: las imágenes se decodifican (GD) y los PDF deben
 *   iniciar con la firma %PDF-.
 * - Límite de tamaño configurable (UPLOAD_MAX_SIZE_MB).
 */
final class UploadValidator
{
    /** extensión => tipos MIME reales aceptados */
    public const ALLOWED = [
        'pdf' => ['application/pdf'],
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png' => ['image/png'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
    ];

    public function __construct(private readonly Settings $settings)
    {
    }

    /**
     * @return array{extension: string, mime: string, size: int, sha256: string, original_name: string}
     */
    public function validate(?UploadedFileInterface $file): array
    {
        if ($file === null) {
            throw $this->error('file', 'required', 'Seleccione un archivo.');
        }
        $error = $file->getError();
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            throw $this->error('file', 'too_large', $this->sizeMessage());
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw $this->error('file', 'upload_failed', 'El archivo no se recibió completo. Intente cargarlo de nuevo.');
        }

        $path = $file->getStream()->getMetadata('uri');
        if (!is_string($path) || !is_file($path)) {
            throw $this->error('file', 'upload_failed', 'El archivo no se recibió correctamente.');
        }
        $size = (int) filesize($path);
        if ($size === 0) {
            throw $this->error('file', 'empty', 'El archivo está vacío.');
        }
        if ($size > $this->settings->uploadMaxBytes) {
            throw $this->error('file', 'too_large', $this->sizeMessage());
        }

        $originalName = self::sanitizeName((string) $file->getClientFilename());
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (!isset(self::ALLOWED[$extension])) {
            throw $this->error('file', 'extension_not_allowed', 'Tipo de archivo no permitido. Se aceptan: PDF, JPG, PNG, DOCX y XLSX.');
        }

        $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($path);
        if (!in_array($mime, self::ALLOWED[$extension], true)) {
            throw $this->error('file', 'content_mismatch', 'El contenido del archivo no corresponde a su extensión.');
        }
        $this->verifyContent($extension, $path);

        return [
            'extension' => $extension === 'jpeg' ? 'jpg' : $extension,
            'mime' => $mime === 'application/zip' ? self::officeMime($extension) : $mime,
            'size' => $size,
            'sha256' => (string) hash_file('sha256', $path),
            'original_name' => $originalName,
        ];
    }

    /**
     * Nombre legible y seguro para mostrar/descargar: sin rutas, sin caracteres de control ni
     * separadores, longitud limitada. Nunca se usa como ruta física.
     */
    public static function sanitizeName(string $name): string
    {
        $name = basename(str_replace('\\', '/', $name));
        $name = (string) preg_replace('/[\x00-\x1F\x7F<>:"\/\\\\|?*]+/u', '_', $name);
        $name = trim($name, " .\t");
        if ($name === '') {
            return 'archivo';
        }
        if (mb_strlen($name) > 200) {
            $ext = pathinfo($name, PATHINFO_EXTENSION);
            $name = mb_substr(pathinfo($name, PATHINFO_FILENAME), 0, 190) . ($ext !== '' ? '.' . $ext : '');
        }

        return $name;
    }

    private function verifyContent(string $extension, string $path): void
    {
        if ($extension === 'pdf') {
            $head = (string) file_get_contents($path, false, null, 0, 5);
            if ($head !== '%PDF-') {
                throw $this->error('file', 'invalid_content', 'El archivo PDF no es válido.');
            }

            return;
        }
        if (in_array($extension, ['jpg', 'jpeg', 'png'], true)) {
            $info = @getimagesize($path);
            $image = $info === false ? false : @imagecreatefromstring((string) file_get_contents($path));
            if ($image === false) {
                throw $this->error('file', 'invalid_content', 'La imagen está dañada o no es válida.');
            }
            imagedestroy($image);

            return;
        }
        // DOCX/XLSX: contenedor ZIP con la estructura mínima de Office Open XML.
        if (class_exists(\ZipArchive::class)) {
            $zip = new \ZipArchive();
            $valid = $zip->open($path) === true && $zip->locateName('[Content_Types].xml') !== false;
            if ($valid) {
                $zip->close();
            }
        } else {
            // Sin la extensión zip: firma ZIP y presencia del manifiesto de Office en el archivo.
            $contents = (string) file_get_contents($path);
            $valid = str_starts_with($contents, "PK\x03\x04") && str_contains($contents, '[Content_Types].xml');
        }
        if (!$valid) {
            throw $this->error('file', 'invalid_content', 'El documento de Office no es válido.');
        }
    }

    private static function officeMime(string $extension): string
    {
        return self::ALLOWED[$extension][0];
    }

    private function sizeMessage(): string
    {
        return sprintf('El archivo supera el tamaño máximo permitido (%d MB).', intdiv($this->settings->uploadMaxBytes, 1024 * 1024));
    }

    private function error(string $field, string $code, string $message): FileException
    {
        return new FileException($message, [['field' => $field, 'code' => $code, 'message' => $message]]);
    }
}
