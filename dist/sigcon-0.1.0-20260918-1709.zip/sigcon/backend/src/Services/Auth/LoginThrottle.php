<?php

declare(strict_types=1);

namespace Sigcon\Services\Auth;

use Sigcon\Config\Settings;
use Sigcon\Exceptions\RateLimitException;
use Sigcon\Helpers\Clock;
use Sigcon\Repositories\LoginAttemptRepository;

/**
 * Límite de intentos de inicio de sesión (fuerza bruta y relleno de credenciales).
 *
 * - Por cuenta: 5 fallos en 15 minutos bloquean esa cuenta 15 minutos (un inicio exitoso reinicia el conteo).
 * - Por IP: 30 fallos en 15 minutos bloquean esa IP 15 minutos (protege frente a pruebas sobre muchas cuentas).
 *
 * El bloqueo se aplica igual a correos existentes e inexistentes: no revela qué cuentas existen.
 * El correo se guarda como HMAC con AUTH_SECRET (no se almacenan correos digitados).
 */
final class LoginThrottle
{
    public const WINDOW_MINUTES = 15;
    public const MAX_FAILURES_PER_ACCOUNT = 5;
    public const MAX_FAILURES_PER_IP = 30;

    public function __construct(
        private readonly LoginAttemptRepository $attempts,
        private readonly Settings $settings,
        private readonly Clock $clock,
    ) {
    }

    public function assertAllowed(string $email, string $ip): void
    {
        $since = $this->clock->now()->modify(sprintf('-%d minutes', self::WINDOW_MINUTES));

        if ($this->attempts->failuresForEmailSince($this->emailKey($email), $since) >= self::MAX_FAILURES_PER_ACCOUNT
            || $this->attempts->failuresForIpSince($ip, $since) >= self::MAX_FAILURES_PER_IP) {
            throw new RateLimitException(
                sprintf('Demasiados intentos fallidos. Espere %d minutos antes de intentar nuevamente.', self::WINDOW_MINUTES),
                self::WINDOW_MINUTES * 60,
            );
        }
    }

    public function recordFailure(string $email, string $ip): void
    {
        $this->attempts->record($this->emailKey($email), $ip, false, $this->clock->now());
    }

    public function recordSuccess(string $email, string $ip): void
    {
        $this->attempts->record($this->emailKey($email), $ip, true, $this->clock->now());
    }

    private function emailKey(string $email): string
    {
        return hash_hmac('sha256', 'login|' . mb_strtolower($email), $this->settings->security->authSecret());
    }
}
