<?php

declare(strict_types=1);

namespace Sigcon\Services\Auth;

use Sigcon\Database\Database;
use Sigcon\DTOs\AuthResult;
use Sigcon\Exceptions\AuthenticationException;
use Sigcon\Exceptions\RateLimitException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Logging\RequestContext;
use Sigcon\Repositories\UserRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Security\PasswordHasher;
use Sigcon\Security\PasswordPolicy;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;

/**
 * Inicio y cierre de sesión, y cambio de contraseña del propio usuario.
 */
final class AuthService
{
    public const INVALID_CREDENTIALS = 'Correo o contraseña incorrectos.';

    public function __construct(
        private readonly UserRepository $users,
        private readonly SessionService $sessions,
        private readonly LoginThrottle $throttle,
        private readonly PasswordHasher $hasher,
        private readonly PasswordPolicy $policy,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly RequestContext $request,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    public function login(string $email, #[\SensitiveParameter] string $password): AuthResult
    {
        $email = mb_strtolower(trim($email));
        $ip = $this->request->ipAddress() ?? 'unknown';

        try {
            $this->throttle->assertAllowed($email, $ip);
        } catch (RateLimitException $e) {
            $this->audit->record(AuditAction::LoginBlocked, metadata: ['reason' => 'too_many_failures']);
            throw $e;
        }

        $user = $this->users->findByEmail($email);
        $hash = $user === null ? null : $this->users->findPasswordHash($user->id);

        // Siempre se ejecuta una verificación de costo equivalente, exista o no la cuenta.
        $valid = $hash !== null ? $this->hasher->verify($password, $hash) : $this->hasher->verifyAgainstDummy($password);

        if (!$valid || $user === null || $hash === null) {
            $this->throttle->recordFailure($email, $ip);
            $this->audit->record(
                AuditAction::LoginFailed,
                $user === null ? null : 'user',
                $user?->uuid,
                ['reason' => 'invalid_credentials'],
            );
            throw new AuthenticationException(self::INVALID_CREDENTIALS);
        }

        if (!$user->isActive()) {
            $this->throttle->recordFailure($email, $ip);
            $this->audit->record(AuditAction::LoginFailed, 'user', $user->uuid, ['reason' => 'inactive_account']);
            throw new AuthenticationException('Su cuenta está inactiva. Contacte al administrador del sistema.');
        }

        return $this->db->transaction(function () use ($user, $hash, $password, $email, $ip): AuthResult {
            if ($this->hasher->needsRehash($hash)) {
                $this->users->replacePasswordHash($user->id, $this->hasher->hash($password));
            }
            $started = $this->sessions->start($user->id);
            $this->users->touchLastLogin($user->id, $this->clock->now());
            $this->throttle->recordSuccess($email, $ip);
            $this->audit->record(AuditAction::LoginSucceeded, 'user', $user->uuid, actorId: $user->id);

            return new AuthResult($user, $started['token']);
        });
    }

    /**
     * Datos de acceso actuales de un usuario (se releen de la base: reflejan cambios recientes).
     *
     * @return array{user: \Sigcon\Models\User, roles: list<array{code: string, name: string}>, permissions: list<string>}
     */
    public function accessOf(int $userId): array
    {
        $user = $this->users->findById($userId) ?? throw new AuthenticationException('Debe iniciar sesión.');

        return [
            'user' => $user,
            'roles' => $this->users->rolesFor($userId),
            'permissions' => $this->users->permissionsFor($userId),
        ];
    }

    public function logout(): void
    {
        $user = $this->auth->user();
        $this->db->transaction(function () use ($user): void {
            $this->sessions->revoke($this->auth->session(), 'logout');
            $this->audit->record(AuditAction::Logout, 'user', $user->uuid);
        });
    }

    /**
     * Cambia la contraseña del usuario autenticado, cierra todas sus sesiones y abre una nueva
     * (rotación del identificador de sesión).
     */
    public function changePassword(#[\SensitiveParameter] string $current, #[\SensitiveParameter] string $new): AuthResult
    {
        $user = $this->auth->user();
        $hash = $this->users->findPasswordHash($user->id);
        if ($hash === null || !$this->hasher->verify($current, $hash)) {
            throw ValidationException::field('current_password', 'incorrect', 'La contraseña actual no es correcta.');
        }
        if (hash_equals($current, $new)) {
            throw ValidationException::field('new_password', 'unchanged', 'La nueva contraseña debe ser diferente de la actual.');
        }
        $violations = $this->policy->violations($new, $user->email);
        if ($violations !== []) {
            throw ValidationException::withErrors(array_map(
                static fn (string $message) => ['field' => 'new_password', 'code' => 'weak_password', 'message' => $message],
                $violations,
            ));
        }

        $newHash = $this->hasher->hash($new);

        return $this->db->transaction(function () use ($user, $newHash): AuthResult {
            $this->users->updatePassword($user->id, $newHash, false, $this->clock->now(), $user->id);
            $this->sessions->revokeAllForUser($user->id, 'password_changed');
            $started = $this->sessions->start($user->id);
            $this->audit->record(AuditAction::PasswordChanged, 'user', $user->uuid);

            return new AuthResult($user, $started['token']);
        });
    }
}
