<?php

declare(strict_types=1);

namespace Sigcon\Services\Auth;

use Sigcon\Config\Settings;
use Sigcon\Helpers\Clock;
use Sigcon\Logging\RequestContext;
use Sigcon\Models\Session;
use Sigcon\Repositories\SessionRepository;

/**
 * Ciclo de vida de las sesiones del lado del servidor (ADR-002).
 * El token en claro solo se devuelve al crear la sesión; en la base se guarda su SHA-256.
 */
final class SessionService
{
    /** Evita escribir en cada petición: last_activity_at se actualiza como máximo una vez por minuto. */
    private const TOUCH_INTERVAL_SECONDS = 60;

    public function __construct(
        private readonly SessionRepository $sessions,
        private readonly Settings $settings,
        private readonly Clock $clock,
        private readonly RequestContext $request,
    ) {
    }

    /** @return array{token: string, session: Session} */
    public function start(int $userId): array
    {
        $token = bin2hex(random_bytes(32));
        $now = $this->clock->now();
        $expiresAt = $now->modify(sprintf('+%d hours', $this->settings->security->sessionAbsoluteHours));

        $id = $this->sessions->create(
            self::hash($token),
            $userId,
            $now,
            $expiresAt,
            $this->request->ipAddress(),
            $this->request->userAgent(),
        );

        return ['token' => $token, 'session' => new Session($id, $userId, $now, $now, $expiresAt, null)];
    }

    /**
     * Devuelve la sesión si el token es válido, no fue revocada y no expiró
     * (ni por tiempo absoluto ni por inactividad). Si expiró, la revoca.
     */
    public function resolve(#[\SensitiveParameter] string $token): ?Session
    {
        $session = $this->sessions->findActiveByTokenHash(self::hash($token));
        if ($session === null) {
            return null;
        }

        $now = $this->clock->now();
        $idleLimit = $session->lastActivityAt->modify(sprintf('+%d minutes', $this->settings->security->sessionIdleMinutes));
        if ($now >= $session->expiresAt || $now >= $idleLimit) {
            $this->sessions->revoke($session->id, 'expired', $now);

            return null;
        }

        if ($now->getTimestamp() - $session->lastActivityAt->getTimestamp() >= self::TOUCH_INTERVAL_SECONDS) {
            $this->sessions->touch($session->id, $now);
        }

        return $session;
    }

    public function revoke(Session $session, string $reason): void
    {
        $this->sessions->revoke($session->id, $reason, $this->clock->now());
    }

    public function revokeAllForUser(int $userId, string $reason, ?int $exceptSessionId = null): int
    {
        return $this->sessions->revokeAllForUser($userId, $reason, $this->clock->now(), $exceptSessionId);
    }

    private static function hash(string $token): string
    {
        return hash('sha256', $token);
    }
}
