<?php

declare(strict_types=1);

namespace Sigcon\Services\Roles;

use PDOException;
use Sigcon\Database\Database;
use Sigcon\DTOs\RoleData;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Models\PermissionDefinition;
use Sigcon\Models\Role;
use Sigcon\Repositories\RoleRepository;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;

/**
 * Administración de roles y de sus permisos.
 *
 * Reglas:
 * - El código de un rol es inmutable.
 * - Los roles del sistema (admin, supervisor, contractor) no se eliminan.
 * - Los permisos del rol "admin" no se modifican desde la aplicación (evita bloquear la
 *   administración del sistema); los permisos nuevos se le asignan por migración.
 * - Un rol con usuarios asignados no se puede eliminar.
 */
final class RoleService
{
    public function __construct(
        private readonly RoleRepository $roles,
        private readonly AuditLogger $audit,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /** @return list<Role> */
    public function list(): array
    {
        return $this->roles->all();
    }

    /** @return list<PermissionDefinition> */
    public function permissions(): array
    {
        return $this->roles->allPermissions();
    }

    public function get(string $code): Role
    {
        return $this->roles->findByCode($code) ?? throw new NotFoundException('El rol no existe.');
    }

    public function create(RoleData $data): Role
    {
        $code = $data->code ?? throw new \InvalidArgumentException('Falta el código del rol.');
        $this->assertPermissionsExist($data->permissions);

        return $this->db->transaction(function () use ($data, $code): Role {
            try {
                $id = $this->roles->create($code, $data->name, $data->description, $this->clock->now());
            } catch (PDOException $e) {
                throw Database::isUniqueViolation($e)
                    ? ValidationException::field('code', 'taken', 'Ya existe un rol con este código.')
                    : $e;
            }
            $this->roles->replacePermissions($id, $data->permissions);
            $this->audit->record(AuditAction::RoleCreated, 'role', $code, [
                'name' => $data->name,
                'permissions' => $data->permissions,
            ]);

            return $this->get($code);
        });
    }

    public function update(string $code, RoleData $data): Role
    {
        $role = $this->get($code);
        $this->assertPermissionsExist($data->permissions);

        $newPermissions = $data->permissions;
        sort($newPermissions);
        $currentPermissions = $role->permissions;
        sort($currentPermissions);

        if ($role->code === Role::ADMIN && $newPermissions !== $currentPermissions) {
            throw new BusinessRuleException('Los permisos del rol Administrador no se pueden modificar.');
        }

        return $this->db->transaction(function () use ($role, $data, $newPermissions, $currentPermissions): Role {
            $this->roles->lockById($role->id);
            $this->roles->update($role->id, $data->name, $data->description, $this->clock->now());
            if ($newPermissions !== $currentPermissions) {
                $this->roles->replacePermissions($role->id, $newPermissions);
            }
            $this->audit->record(AuditAction::RoleUpdated, 'role', $role->code, array_filter([
                'name' => $role->name !== $data->name ? ['from' => $role->name, 'to' => $data->name] : null,
                'description' => $role->description !== $data->description ? ['from' => $role->description, 'to' => $data->description] : null,
                'permissions_added' => array_values(array_diff($newPermissions, $currentPermissions)),
                'permissions_removed' => array_values(array_diff($currentPermissions, $newPermissions)),
            ], static fn ($value) => $value !== null && $value !== []));

            return $this->get($role->code);
        });
    }

    public function delete(string $code): void
    {
        $role = $this->get($code);
        if ($role->isSystem) {
            throw new BusinessRuleException('Los roles del sistema no se pueden eliminar.');
        }

        $this->db->transaction(function () use ($role): void {
            $this->roles->lockById($role->id);
            // Se relee dentro de la transacción: otro proceso pudo asignar el rol mientras tanto.
            if ($this->get($role->code)->userCount > 0) {
                throw new BusinessRuleException('No se puede eliminar un rol que tiene usuarios asignados.');
            }
            $this->roles->delete($role->id);
            $this->audit->record(AuditAction::RoleDeleted, 'role', $role->code, ['name' => $role->name]);
        });
    }

    /** @param list<string> $codes */
    private function assertPermissionsExist(array $codes): void
    {
        $known = array_map(static fn (PermissionDefinition $p) => $p->code, $this->roles->allPermissions());
        $unknown = array_diff($codes, $known);
        if ($unknown !== []) {
            throw ValidationException::field('permissions', 'unknown_permission', sprintf('Permiso no existe: %s', implode(', ', $unknown)));
        }
    }
}
