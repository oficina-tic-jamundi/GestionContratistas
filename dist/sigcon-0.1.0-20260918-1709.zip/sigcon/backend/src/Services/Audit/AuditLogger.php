<?php

declare(strict_types=1);

namespace Sigcon\Services\Audit;

use Sigcon\Helpers\Clock;
use Sigcon\Logging\RequestContext;
use Sigcon\Logging\SensitiveDataRedactor;
use Sigcon\Repositories\AuditLogRepository;
use Sigcon\Security\AuthContext;

/**
 * Registra eventos de auditoría en la base de datos.
 *
 * Usa la misma conexión que los servicios: si el evento se registra dentro de una transacción
 * de negocio, se confirma o revierte junto con ella (nunca hay un cambio sin su auditoría,
 * ni una auditoría de un cambio que no ocurrió).
 */
final class AuditLogger
{
    public function __construct(
        private readonly AuditLogRepository $repository,
        private readonly AuthContext $auth,
        private readonly RequestContext $request,
        private readonly Clock $clock,
        private readonly SensitiveDataRedactor $redactor,
    ) {
    }

    /**
     * @param array<string, mixed> $metadata nunca incluir contraseñas ni tokens (se redactan por seguridad)
     * @param int|null $actorId usuario que realiza la acción; por defecto el usuario autenticado
     */
    public function record(
        AuditAction $action,
        ?string $entityType = null,
        int|string|null $entityId = null,
        array $metadata = [],
        ?int $actorId = null,
    ): void {
        $this->repository->insert(
            occurredAt: $this->clock->now(),
            userId: $actorId ?? $this->auth->userId(),
            action: $action->value,
            entityType: $entityType,
            entityId: $entityId === null ? null : (string) $entityId,
            ipAddress: $this->request->ipAddress(),
            userAgent: $this->request->userAgent(),
            requestId: $this->request->requestId(),
            metadata: $metadata === [] ? null : $this->redactor->redact($metadata),
        );
    }
}
