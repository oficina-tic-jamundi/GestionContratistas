<?php

declare(strict_types=1);

namespace Sigcon\Services\Audit;

use Sigcon\DTOs\AuditFilters;
use Sigcon\Helpers\DateTimes;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\AuditEntry;
use Sigcon\Repositories\AuditLogRepository;

/** Consulta del registro de auditoría (solo lectura). */
final class AuditQueryService
{
    public function __construct(private readonly AuditLogRepository $repository)
    {
    }

    /**
     * @return array{items: list<array<string, mixed>>, meta: array<string, mixed>}
     */
    public function search(AuditFilters $filters, PageRequest $request): array
    {
        $page = $this->repository->paginate($filters, $request);

        return [
            'items' => $page->map(static fn (AuditEntry $entry) => [
                'id' => $entry->id,
                'occurred_at' => DateTimes::toApi($entry->occurredAt),
                'action' => $entry->action,
                'action_label' => AuditAction::tryFrom($entry->action)?->label() ?? $entry->action,
                'entity_type' => $entry->entityType,
                'entity_id' => $entry->entityId,
                'user' => $entry->userUuid === null ? null : [
                    'uuid' => $entry->userUuid,
                    'name' => $entry->userName,
                    'email' => $entry->userEmail,
                ],
                'ip_address' => $entry->ipAddress,
                'user_agent' => $entry->userAgent,
                'request_id' => $entry->requestId,
                'metadata' => $entry->metadata,
            ]),
            'meta' => $page->meta(),
        ];
    }

    /** @return array<string, string> acción => etiqueta, para los filtros de la interfaz */
    public function actions(): array
    {
        $result = [];
        foreach (AuditAction::cases() as $action) {
            $result[$action->value] = $action->label();
        }

        return $result;
    }
}
