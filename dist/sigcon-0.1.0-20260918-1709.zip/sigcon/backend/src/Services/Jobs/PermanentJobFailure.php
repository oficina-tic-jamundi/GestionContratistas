<?php

declare(strict_types=1);

namespace Sigcon\Services\Jobs;

/** Error que no se resuelve reintentando: el trabajo pasa directamente a fallido. */
final class PermanentJobFailure extends \RuntimeException
{
}
