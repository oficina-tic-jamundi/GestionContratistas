<?php

declare(strict_types=1);

namespace Sigcon\Services\Jobs;

use Sigcon\Config\JobSettings;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Repositories\JobRepository;

/**
 * Encola trabajos para el procesador (`bin/console jobs:run`, ADR-005).
 *
 * Patrón outbox: se llama DENTRO de la transacción de negocio, de modo que el trabajo existe
 * si y solo si el cambio que lo origina se confirmó.
 */
final class JobQueue
{
    public function __construct(
        private readonly JobRepository $jobs,
        private readonly JobSettings $settings,
        private readonly Clock $clock,
    ) {
    }

    /**
     * @param array<string, mixed> $payload solo identificadores, nunca datos sensibles
     * @param string|null $dedupeKey si ya hay un trabajo igual pendiente, no se duplica
     * @return bool false si se omitió por duplicado
     */
    public function push(string $type, array $payload, ?string $dedupeKey = null, int $delaySeconds = 0): bool
    {
        $now = $this->clock->now();

        return $this->jobs->insert(Uuid::v4(), $type, $payload, $dedupeKey, $this->settings->maxAttempts, $now->modify("+{$delaySeconds} seconds"), $now);
    }
}
