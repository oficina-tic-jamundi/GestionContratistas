<?php

declare(strict_types=1);

namespace Sigcon\Services\Jobs;

/**
 * Procesa un tipo de trabajo. Debe ser idempotente: un trabajo puede ejecutarse más de una vez
 * (reintentos, o un proceso que murió después de completar el trabajo sin marcarlo).
 */
interface JobHandler
{
    public function type(): string;

    /**
     * @param array<string, mixed> $payload
     * @throws PermanentJobFailure si reintentar no tiene sentido (datos inexistentes, etc.)
     */
    public function handle(array $payload): void;

    /**
     * Se invoca cuando el trabajo queda fallido definitivamente (agotó los intentos o falla
     * permanente), para reflejarlo en la entidad afectada. No debe lanzar excepciones.
     *
     * @param array<string, mixed> $payload
     */
    public function failed(array $payload, string $error): void;
}
