<?php

declare(strict_types=1);

namespace Sigcon\Services\Jobs;

use Psr\Log\LoggerInterface;
use Sigcon\Config\JobSettings;
use Sigcon\Helpers\Clock;
use Sigcon\Models\Job;
use Sigcon\Repositories\JobRepository;
use Sigcon\Security\Permission;
use Sigcon\Services\Notifications\NotificationService;

/**
 * Procesador de la cola (ADR-005). Lo ejecuta el Cron de cPanel cada 5 minutos:
 * toma trabajos mientras haya y no se supere el tiempo máximo, y registra la ejecución.
 */
final class JobRunner
{
    /** @var array<string, JobHandler> */
    private array $handlers = [];

    /** @param iterable<JobHandler> $handlers */
    public function __construct(
        iterable $handlers,
        private readonly JobRepository $jobs,
        private readonly JobSettings $settings,
        private readonly Clock $clock,
        private readonly LoggerInterface $logger,
        private readonly ?NotificationService $notifications = null,
    ) {
        foreach ($handlers as $handler) {
            $this->handlers[$handler->type()] = $handler;
        }
    }

    /**
     * @param callable(): float $elapsed segundos transcurridos (inyectable para pruebas)
     * @return array{processed: int, succeeded: int, failed: int}
     */
    public function run(?int $maxJobs = null, ?callable $elapsed = null): array
    {
        $started = microtime(true);
        $elapsed ??= static fn (): float => microtime(true) - $started;
        $runnerId = sprintf('%s:%d:%s', gethostname() ?: 'host', getmypid() ?: 0, bin2hex(random_bytes(4)));
        $runId = $this->jobs->startRun($runnerId, $this->clock->now());
        $processed = 0;
        $succeeded = 0;
        $failed = 0;

        while ($elapsed() < $this->settings->maxRuntimeSeconds && ($maxJobs === null || $processed < $maxJobs)) {
            $now = $this->clock->now();
            $job = $this->jobs->claimNext($runnerId, $now, $now->modify("+{$this->settings->lockSeconds} seconds"));
            if ($job === null) {
                break;
            }
            $processed++;
            if ($this->process($job, $runnerId)) {
                $succeeded++;
            } else {
                $failed++;
            }
        }

        $this->jobs->finishRun($runId, $processed, $failed, $this->clock->now());

        return ['processed' => $processed, 'succeeded' => $succeeded, 'failed' => $failed];
    }

    private function process(Job $job, string $runnerId): bool
    {
        $handler = $this->handlers[$job->type] ?? null;
        try {
            if ($handler === null) {
                throw new PermanentJobFailure(sprintf('No hay un procesador para el tipo de trabajo "%s".', $job->type));
            }
            $handler->handle($job->payload);
            $this->jobs->markCompleted($job->id, $runnerId, $this->clock->now());

            return true;
        } catch (\Throwable $e) {
            $message = self::describe($e);
            $permanent = $e instanceof PermanentJobFailure || $job->attempts >= $job->maxAttempts;
            $now = $this->clock->now();
            if ($permanent) {
                $this->jobs->markFailed($job->id, $runnerId, $message, $now);
                try {
                    $handler?->failed($job->payload, $message);
                    $this->notifications?->notifyPermission(
                        Permission::JobsManage,
                        'job.failed',
                        'Una tarea en segundo plano falló definitivamente',
                        sprintf('Tipo: %s. %s', $job->type, mb_substr($message, 0, 300)),
                        '/jobs?status=failed',
                    );
                } catch (\Throwable) {
                    // Los avisos de falla no deben interrumpir el procesamiento de la cola.
                }
            } else {
                $wait = $this->settings->backoffMinutes($job->attempts);
                $this->jobs->markRetry($job->id, $runnerId, $message, $now->modify("+{$wait} minutes"), $now);
            }
            $this->logger->error('Trabajo en segundo plano con error', [
                'job' => $job->uuid,
                'type' => $job->type,
                'attempt' => $job->attempts,
                'final' => $permanent,
                'exception' => $e::class,
                'message' => $message,
            ]);

            return false;
        }
    }

    /** Mensaje para el administrador: sin rutas físicas del servidor. */
    private static function describe(\Throwable $e): string
    {
        $message = $e->getMessage() !== '' ? $e->getMessage() : $e::class;

        return (string) preg_replace('~(?:[A-Za-z]:)?[\\\\/][^\s:"\']+[\\\\/]~', '…/', $message);
    }
}
