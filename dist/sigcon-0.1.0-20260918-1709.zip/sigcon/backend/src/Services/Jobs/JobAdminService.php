<?php

declare(strict_types=1);

namespace Sigcon\Services\Jobs;

use Sigcon\Config\JobSettings;
use Sigcon\Exceptions\BusinessRuleException;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Http\Page;
use Sigcon\Http\PageRequest;
use Sigcon\Models\Job;
use Sigcon\Models\JobStatus;
use Sigcon\Repositories\JobRepository;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;

/** Consulta de la cola y reintento manual de trabajos fallidos (permiso `jobs.manage`). */
final class JobAdminService
{
    public function __construct(
        private readonly JobRepository $jobs,
        private readonly JobSettings $settings,
        private readonly AuditLogger $audit,
        private readonly Clock $clock,
    ) {
    }

    /** @return Page<Job> */
    public function list(?JobStatus $status, PageRequest $page): Page
    {
        return $this->jobs->paginate($status, $page);
    }

    /**
     * Estado del procesador: si el Cron dejó de ejecutarse, la administración debe saberlo.
     *
     * @return array{counts: array<string, int>, last_run: array{started_at: \DateTimeImmutable, finished_at: ?\DateTimeImmutable, processed: int, failed: int}|null, stale: bool, stale_after_minutes: int}
     */
    public function status(): array
    {
        $last = $this->jobs->lastRun();
        $limit = $this->clock->now()->modify("-{$this->settings->staleAfterMinutes} minutes");

        return [
            'counts' => $this->jobs->countsByStatus(),
            'last_run' => $last,
            'stale' => $last === null || $last['started_at'] < $limit,
            'stale_after_minutes' => $this->settings->staleAfterMinutes,
        ];
    }

    public function retry(string $uuid): Job
    {
        $job = (Uuid::isValid($uuid) ? $this->jobs->findByUuid($uuid) : null) ?? throw new NotFoundException('La tarea no existe.');
        if ($job->status !== JobStatus::Failed) {
            throw new BusinessRuleException('Solo se reintentan tareas fallidas.');
        }
        if (!$this->jobs->requeueFailed($job->id, $this->clock->now())) {
            throw new BusinessRuleException('Ya hay una tarea igual pendiente; no es necesario reintentar esta.');
        }
        $this->audit->record(AuditAction::JobRetried, 'job', $job->uuid, ['type' => $job->type, 'last_error' => $job->lastError]);

        return $this->jobs->findById($job->id) ?? throw new \LogicException('Tarea no encontrada.');
    }
}
