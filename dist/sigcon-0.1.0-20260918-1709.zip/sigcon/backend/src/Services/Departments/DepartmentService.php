<?php

declare(strict_types=1);

namespace Sigcon\Services\Departments;

use PDOException;
use Sigcon\Database\Database;
use Sigcon\DTOs\DepartmentData;
use Sigcon\Exceptions\NotFoundException;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\Uuid;
use Sigcon\Models\ActiveStatus;
use Sigcon\Models\Department;
use Sigcon\Repositories\DepartmentRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Services\Audit\AuditAction;
use Sigcon\Services\Audit\AuditLogger;

/**
 * Dependencias / Secretarías. No se eliminan: se desactivan. Una dependencia inactiva no puede
 * asignarse a contratos ni usuarios nuevos; los registros existentes la conservan.
 */
final class DepartmentService
{
    public function __construct(
        private readonly DepartmentRepository $departments,
        private readonly AuditLogger $audit,
        private readonly AuthContext $auth,
        private readonly Database $db,
        private readonly Clock $clock,
    ) {
    }

    /** @return list<Department> */
    public function list(?ActiveStatus $status = null): array
    {
        return $this->departments->all($status);
    }

    public function get(string $uuid): Department
    {
        return (Uuid::isValid($uuid) ? $this->departments->findByUuid($uuid) : null)
            ?? throw new NotFoundException('La dependencia no existe.');
    }

    /** Dependencia activa para asignar a un contrato o usuario. */
    public function requireActive(string $uuid, string $field = 'department'): Department
    {
        $department = Uuid::isValid($uuid) ? $this->departments->findByUuid($uuid) : null;
        if ($department === null || !$department->isActive()) {
            throw ValidationException::field($field, 'invalid_department', 'Seleccione una dependencia activa.');
        }

        return $department;
    }

    public function create(DepartmentData $data): Department
    {
        return $this->db->transaction(function () use ($data): Department {
            $this->assertUnique($data);
            $uuid = Uuid::v4();
            try {
                $this->departments->create($uuid, $data->code, $data->name, $this->clock->now(), $this->auth->userId());
            } catch (PDOException $e) {
                throw Database::isUniqueViolation($e) ? $this->duplicate() : $e;
            }
            $this->audit->record(AuditAction::DepartmentCreated, 'department', $uuid, ['code' => $data->code, 'name' => $data->name]);

            return $this->get($uuid);
        });
    }

    public function update(string $uuid, DepartmentData $data): Department
    {
        $department = $this->get($uuid);

        return $this->db->transaction(function () use ($department, $data): Department {
            $this->assertUnique($data, $department->id);
            try {
                $this->departments->update($department->id, $data->code, $data->name, $this->clock->now(), $this->auth->userId());
            } catch (PDOException $e) {
                throw Database::isUniqueViolation($e) ? $this->duplicate() : $e;
            }
            $this->audit->record(AuditAction::DepartmentUpdated, 'department', $department->uuid, array_filter([
                'code' => $department->code !== $data->code ? ['from' => $department->code, 'to' => $data->code] : null,
                'name' => $department->name !== $data->name ? ['from' => $department->name, 'to' => $data->name] : null,
            ]));

            return $this->get($department->uuid);
        });
    }

    public function setActive(string $uuid, bool $active): Department
    {
        $department = $this->get($uuid);
        $status = $active ? ActiveStatus::Active : ActiveStatus::Inactive;
        if ($department->status === $status) {
            return $department;
        }

        $this->db->transaction(function () use ($department, $status, $active): void {
            $this->departments->setStatus($department->id, $status, $this->clock->now(), $this->auth->userId());
            $this->audit->record($active ? AuditAction::DepartmentActivated : AuditAction::DepartmentDeactivated, 'department', $department->uuid);
        });

        return $this->get($uuid);
    }

    private function assertUnique(DepartmentData $data, ?int $exceptId = null): void
    {
        $errors = [];
        if ($this->departments->exists('code', $data->code, $exceptId)) {
            $errors[] = ['field' => 'code', 'code' => 'taken', 'message' => 'Ya existe una dependencia con este código.'];
        }
        if ($this->departments->exists('name', $data->name, $exceptId)) {
            $errors[] = ['field' => 'name', 'code' => 'taken', 'message' => 'Ya existe una dependencia con este nombre.'];
        }
        if ($errors !== []) {
            throw ValidationException::withErrors($errors);
        }
    }

    private function duplicate(): ValidationException
    {
        return ValidationException::field('code', 'taken', 'Ya existe una dependencia con este código o nombre.');
    }
}
