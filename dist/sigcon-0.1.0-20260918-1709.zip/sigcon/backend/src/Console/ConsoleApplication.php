<?php

declare(strict_types=1);

namespace Sigcon\Console;

use Psr\Log\LoggerInterface;
use Throwable;

/**
 * Despachador mínimo de comandos CLI. Se usa desde SSH y desde los Cron Jobs de cPanel.
 */
final class ConsoleApplication
{
    /** @var array<string, Command> */
    private array $commands = [];

    /** @param iterable<Command> $commands */
    public function __construct(iterable $commands, private readonly LoggerInterface $logger)
    {
        foreach ($commands as $command) {
            $this->commands[$command->name()] = $command;
        }
        ksort($this->commands);
    }

    /** @param list<string> $argv */
    public function run(array $argv, Output $output): int
    {
        $name = $argv[1] ?? 'list';
        $arguments = array_slice($argv, 2);

        if ($name === 'list' || !isset($this->commands[$name])) {
            if ($name !== 'list') {
                $output->error(sprintf('Comando desconocido: %s', $name));
            }
            $this->printList($output);

            return $name === 'list' ? 0 : 1;
        }

        try {
            return $this->commands[$name]->run($arguments, $output);
        } catch (Throwable $e) {
            $this->logger->error('Falló el comando de consola', ['command' => $name, 'exception' => $e]);
            $output->error(sprintf('Error: %s', $e->getMessage()));

            return 1;
        }
    }

    private function printList(Output $output): void
    {
        $output->line('SIGCON — comandos disponibles:');
        foreach ($this->commands as $name => $command) {
            $output->line(sprintf('  %-20s %s', $name, $command->description()));
        }
    }
}
