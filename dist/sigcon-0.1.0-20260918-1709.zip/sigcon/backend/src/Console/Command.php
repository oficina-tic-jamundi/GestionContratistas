<?php

declare(strict_types=1);

namespace Sigcon\Console;

interface Command
{
    public function name(): string;

    public function description(): string;

    /**
     * @param list<string> $arguments
     * @return int Código de salida (0 = éxito)
     */
    public function run(array $arguments, Output $output): int;
}
