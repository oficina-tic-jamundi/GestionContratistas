<?php

declare(strict_types=1);

namespace Sigcon\Console;

/** Lectura de opciones de consola con formato --nombre=valor. */
final class Arguments
{
    /** @var array<string, string> */
    private array $options = [];

    /** @param list<string> $arguments */
    public function __construct(array $arguments)
    {
        foreach ($arguments as $argument) {
            if (preg_match('/^--([a-z][a-z0-9-]*)=(.*)$/', $argument, $m) === 1) {
                $this->options[$m[1]] = $m[2];
            } elseif (preg_match('/^--([a-z][a-z0-9-]*)$/', $argument, $m) === 1) {
                $this->options[$m[1]] = 'true';
            }
        }
    }

    public function option(string $name): ?string
    {
        $value = $this->options[$name] ?? null;

        return $value === null || trim($value) === '' ? null : trim($value);
    }

    public function flag(string $name): bool
    {
        return ($this->options[$name] ?? null) === 'true';
    }
}
