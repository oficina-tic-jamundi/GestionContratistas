<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Services\Backup\DatabaseBackup;

/**
 * Backup cifrado de la base de datos (Cron diario, docs/deployment/backups.md):
 *
 *   php bin/console backup:database
 */
final class BackupDatabaseCommand implements Command
{
    public function __construct(private readonly DatabaseBackup $backup)
    {
    }

    public function name(): string
    {
        return 'backup:database';
    }

    public function description(): string
    {
        return 'Genera un backup cifrado de la base de datos y aplica la retención (30 diarios + 12 mensuales).';
    }

    public function run(array $arguments, Output $output): int
    {
        $result = $this->backup->run();
        $output->line(sprintf('Backup generado: %s (%s KB)', basename($result['file']), number_format($result['bytes'] / 1024, 0, ',', '.')));
        foreach ($this->backup->prune() as $deleted) {
            $output->line('  retención, eliminado: ' . $deleted);
        }

        return 0;
    }
}
