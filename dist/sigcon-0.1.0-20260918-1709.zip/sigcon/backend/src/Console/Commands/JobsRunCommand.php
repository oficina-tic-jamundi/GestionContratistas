<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Services\Jobs\JobRunner;

/**
 * Procesa la cola de trabajos. Lo ejecuta el Cron de cPanel cada 5 minutos (ADR-005, ADR-017):
 *
 *   php bin/console jobs:run            procesa hasta agotar la cola o el tiempo máximo
 *   php bin/console jobs:run --max=10   como máximo 10 trabajos
 *
 * Es seguro que dos ejecuciones se solapen: cada trabajo lo toma un único procesador.
 */
final class JobsRunCommand implements Command
{
    public function __construct(private readonly JobRunner $runner)
    {
    }

    public function name(): string
    {
        return 'jobs:run';
    }

    public function description(): string
    {
        return 'Procesa la cola de trabajos en segundo plano (Cron cada 5 minutos).';
    }

    public function run(array $arguments, Output $output): int
    {
        $max = null;
        foreach ($arguments as $argument) {
            if (preg_match('/^--max=(\d+)$/', $argument, $m) === 1 && (int) $m[1] > 0) {
                $max = (int) $m[1];
            } else {
                $output->error("Argumento no reconocido: {$argument}");

                return 2;
            }
        }
        $result = $this->runner->run($max);
        $output->line(sprintf('Procesados: %d · exitosos: %d · con error: %d', $result['processed'], $result['succeeded'], $result['failed']));

        // Un trabajo con error no es un fallo del procesador: se reintentará o queda para revisión.
        return 0;
    }
}
