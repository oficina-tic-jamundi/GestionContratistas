<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;

/**
 * Genera un valor aleatorio para AUTH_SECRET. Solo lo imprime:
 * nunca modifica archivos .env automáticamente.
 */
final class KeyGenerateCommand implements Command
{
    public function name(): string
    {
        return 'key:generate';
    }

    public function description(): string
    {
        return 'Genera un valor aleatorio seguro para AUTH_SECRET.';
    }

    public function run(array $arguments, Output $output): int
    {
        $output->line('AUTH_SECRET=' . base64_encode(random_bytes(32)));

        return 0;
    }
}
