<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Database\Migrator;

final class MigrateCommand implements Command
{
    public function __construct(private readonly Migrator $migrator)
    {
    }

    public function name(): string
    {
        return 'migrate';
    }

    public function description(): string
    {
        return 'Aplica las migraciones pendientes de la base de datos.';
    }

    public function run(array $arguments, Output $output): int
    {
        $applied = $this->migrator->migrate(static fn (string $name) => $output->line('  aplicada: ' . $name));
        $output->line($applied === [] ? 'No hay migraciones pendientes.' : sprintf('%d migración(es) aplicada(s).', count($applied)));

        return 0;
    }
}
