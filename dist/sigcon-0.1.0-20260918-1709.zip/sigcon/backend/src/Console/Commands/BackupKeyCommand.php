<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;

/**
 * Genera una clave para BACKUP_KEY. Guárdela también en el gestor de secretos institucional:
 * sin ella los backups NO se pueden descifrar.
 */
final class BackupKeyCommand implements Command
{
    public function name(): string
    {
        return 'backup:key';
    }

    public function description(): string
    {
        return 'Genera una clave para BACKUP_KEY (cifrado de los backups).';
    }

    public function run(array $arguments, Output $output): int
    {
        $output->line('BACKUP_KEY=' . base64_encode(random_bytes(SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES)));
        $output->line('Guarde esta clave en el gestor de secretos institucional: sin ella los backups no se pueden restaurar.');

        return 0;
    }
}
