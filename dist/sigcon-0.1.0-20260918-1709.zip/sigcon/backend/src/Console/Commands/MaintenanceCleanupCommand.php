<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Config\Settings;
use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Helpers\Clock;
use Sigcon\Repositories\JobRepository;
use Sigcon\Repositories\LoginAttemptRepository;
use Sigcon\Repositories\NotificationRepository;
use Sigcon\Repositories\SessionRepository;

/**
 * Limpieza periódica (Cron de cPanel, diario):
 * - sesiones vencidas o revocadas hace más de 7 días;
 * - intentos de inicio de sesión de más de 30 días;
 * - archivos temporales de más de 24 horas;
 * - trabajos completados y registros del procesador de más de 30 días (los fallidos se conservan);
 * - notificaciones LEÍDAS de más de 180 días (las no leídas se conservan).
 *
 * NO toca audit_logs: la auditoría se conserva según la política institucional de retención.
 */
final class MaintenanceCleanupCommand implements Command
{
    public function __construct(
        private readonly SessionRepository $sessions,
        private readonly LoginAttemptRepository $attempts,
        private readonly JobRepository $jobs,
        private readonly NotificationRepository $notifications,
        private readonly Settings $settings,
        private readonly Clock $clock,
    ) {
    }

    public function name(): string
    {
        return 'maintenance:cleanup';
    }

    public function description(): string
    {
        return 'Elimina sesiones vencidas, intentos de login antiguos, temporales y trabajos completados antiguos.';
    }

    public function run(array $arguments, Output $output): int
    {
        $now = $this->clock->now();
        $output->line(sprintf('Sesiones eliminadas: %d', $this->sessions->deleteFinishedBefore($now->modify('-7 days'))));
        $output->line(sprintf('Intentos de login eliminados: %d', $this->attempts->deleteOlderThan($now->modify('-30 days'))));
        $output->line(sprintf('Temporales eliminados: %d', $this->cleanTemporaryFiles($now->getTimestamp() - 86400)));
        $output->line(sprintf('Trabajos completados eliminados: %d', $this->jobs->deleteCompletedBefore($now->modify('-30 days'))));
        $output->line(sprintf('Notificaciones leídas eliminadas: %d', $this->notifications->deleteReadBefore($now->modify('-180 days'))));

        return 0;
    }

    private function cleanTemporaryFiles(int $olderThan): int
    {
        $dir = $this->settings->storagePath . DIRECTORY_SEPARATOR . 'tmp';
        if (!is_dir($dir)) {
            return 0;
        }
        $deleted = 0;
        foreach (new \DirectoryIterator($dir) as $file) {
            if ($file->isFile() && !str_starts_with($file->getFilename(), '.') && $file->getMTime() < $olderThan) {
                if (@unlink($file->getPathname())) {
                    $deleted++;
                }
            }
        }

        return $deleted;
    }
}
