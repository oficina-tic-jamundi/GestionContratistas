<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Services\Backup\DatabaseBackup;

/**
 * Descifra un backup para restaurarlo (docs/deployment/backups.md):
 *
 *   php bin/console backup:decrypt <archivo.sql.gz.enc> <destino.sql.gz>
 *
 * Verifica la integridad: un archivo alterado o truncado no se descifra.
 */
final class BackupDecryptCommand implements Command
{
    public function __construct(private readonly DatabaseBackup $backup)
    {
    }

    public function name(): string
    {
        return 'backup:decrypt';
    }

    public function description(): string
    {
        return 'Descifra y verifica un backup: backup:decrypt <archivo.enc> <destino.sql.gz>';
    }

    public function run(array $arguments, Output $output): int
    {
        if (count($arguments) !== 2) {
            $output->error('Uso: php bin/console backup:decrypt <archivo.sql.gz.enc> <destino.sql.gz>');

            return 2;
        }
        [$source, $target] = $arguments;
        if (file_exists($target)) {
            $output->error('El archivo de destino ya existe; no se sobrescribe.');

            return 2;
        }
        $this->backup->decrypt($source, $target);
        $output->line("Backup descifrado y verificado: {$target}");
        $output->line('Para restaurar: gunzip -c destino.sql.gz | mysql --defaults-extra-file=credenciales.cnf BASE_DE_DATOS');

        return 0;
    }
}
