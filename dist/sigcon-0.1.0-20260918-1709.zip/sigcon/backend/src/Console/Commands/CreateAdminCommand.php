<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Arguments;
use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\DTOs\CreateUserData;
use Sigcon\Exceptions\ValidationException;
use Sigcon\Models\Role;
use Sigcon\Services\Users\UserService;

/**
 * Crea un administrador desde la consola (primer usuario del sistema o recuperación de acceso).
 *
 *   php bin/console user:create-admin --email=persona@jamundi-valle.gov.co --first-name=Nombre --last-name=Apellido
 *
 * Genera una contraseña temporal que se muestra UNA vez; debe cambiarse en el primer inicio de sesión.
 * No existe ninguna contraseña por defecto en el código ni en las migraciones.
 */
final class CreateAdminCommand implements Command
{
    public function __construct(private readonly UserService $users)
    {
    }

    public function name(): string
    {
        return 'user:create-admin';
    }

    public function description(): string
    {
        return 'Crea un usuario administrador con contraseña temporal.';
    }

    public function run(array $arguments, Output $output): int
    {
        $args = new Arguments($arguments);

        try {
            $result = $this->users->create(CreateUserData::fromBody([
                'email' => $args->option('email'),
                'first_name' => $args->option('first-name'),
                'last_name' => $args->option('last-name'),
                'roles' => [Role::ADMIN],
            ]));
        } catch (ValidationException $e) {
            $output->error('No se pudo crear el administrador:');
            foreach ($e->errors() as $error) {
                $output->error(sprintf('  --%s: %s', str_replace('_', '-', (string) $error['field']), $error['message']));
            }
            $output->error('Uso: php bin/console user:create-admin --email=... --first-name=... --last-name=...');

            return 1;
        }

        $output->line(sprintf('Administrador creado: %s (%s)', $result['user']->fullName(), $result['user']->email));
        $output->line('Contraseña temporal (se muestra una sola vez): ' . $result['temporary_password']);
        $output->line('Deberá cambiarla en el primer inicio de sesión.');

        return 0;
    }
}
