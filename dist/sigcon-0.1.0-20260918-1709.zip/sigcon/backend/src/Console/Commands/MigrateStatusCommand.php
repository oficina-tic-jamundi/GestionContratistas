<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Database\Migrator;

final class MigrateStatusCommand implements Command
{
    public function __construct(private readonly Migrator $migrator)
    {
    }

    public function name(): string
    {
        return 'migrate:status';
    }

    public function description(): string
    {
        return 'Muestra el estado de cada migración.';
    }

    public function run(array $arguments, Output $output): int
    {
        $rows = $this->migrator->status();
        if ($rows === []) {
            $output->line('No hay migraciones.');

            return 0;
        }

        $problems = 0;
        foreach ($rows as $row) {
            $output->line(sprintf('  [%-12s] %s %s', $row['status'], $row['migration'], $row['applied_at'] ?? ''));
            if (in_array($row['status'], ['modified', 'missing-file'], true)) {
                $problems++;
            }
        }

        return $problems === 0 ? 0 : 1;
    }
}
