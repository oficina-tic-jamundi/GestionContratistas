<?php

declare(strict_types=1);

namespace Sigcon\Console\Commands;

use Sigcon\Console\Command;
use Sigcon\Console\Output;
use Sigcon\Services\System\SystemCheck;

/**
 * Verifica el entorno después de instalar o actualizar (docs/deployment/cpanel.md):
 *
 *   php bin/console system:check
 *
 * Termina con código 1 si hay errores, para usarlo en scripts de despliegue.
 */
final class SystemCheckCommand implements Command
{
    private const MARKS = [SystemCheck::OK => '[ OK ]', SystemCheck::WARNING => '[AVISO]', SystemCheck::ERROR => '[ERROR]'];

    public function __construct(private readonly SystemCheck $check)
    {
    }

    public function name(): string
    {
        return 'system:check';
    }

    public function description(): string
    {
        return 'Verifica PHP, extensiones, configuración, almacenamiento, base de datos, migraciones y Cron.';
    }

    public function run(array $arguments, Output $output): int
    {
        $errors = 0;
        $warnings = 0;
        foreach ($this->check->run() as $result) {
            $output->line(sprintf('%-8s %s %s', self::MARKS[$result['status']], mb_str_pad($result['check'], 40), $result['detail']));
            $errors += $result['status'] === SystemCheck::ERROR ? 1 : 0;
            $warnings += $result['status'] === SystemCheck::WARNING ? 1 : 0;
        }
        $output->line();
        $output->line(sprintf('Resultado: %d error(es), %d aviso(s).', $errors, $warnings));

        return $errors > 0 ? 1 : 0;
    }
}
