<?php

declare(strict_types=1);

namespace Sigcon\Logging;

use Monolog\Formatter\JsonFormatter;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Level;
use Monolog\Logger;
use Monolog\LogRecord;
use Monolog\Processor\PsrLogMessageProcessor;
use Psr\Log\LoggerInterface;
use Sigcon\Config\Settings;

/**
 * Crea (y reutiliza) un logger por canal. Formato JSON, un archivo por canal y día.
 */
final class LoggerFactory
{
    private const RETENTION_DAYS = 90;

    /** @var array<string, LoggerInterface> */
    private array $loggers = [];

    public function __construct(
        private readonly Settings $settings,
        private readonly RequestContext $requestContext,
    ) {
    }

    public function channel(LogChannel $channel): LoggerInterface
    {
        return $this->loggers[$channel->value] ??= $this->create($channel);
    }

    private function level(): Level
    {
        return match ($this->settings->logLevel) {
            'debug' => Level::Debug,
            'info' => Level::Info,
            'notice' => Level::Notice,
            'warning' => Level::Warning,
            default => Level::Error,
        };
    }

    private function create(LogChannel $channel): LoggerInterface
    {
        $handler = new RotatingFileHandler(
            $this->settings->logPath . DIRECTORY_SEPARATOR . $channel->value . '.log',
            self::RETENTION_DAYS,
            $this->level(),
            filePermission: 0640,
        );
        $formatter = new JsonFormatter();
        // Las trazas solo se incluyen fuera de producción.
        $formatter->includeStacktraces(!$this->settings->environment->isProduction());
        $handler->setFormatter($formatter);

        $logger = new Logger($channel->value, [$handler]);
        $logger->setTimezone(new \DateTimeZone($this->settings->timezone));
        $logger->pushProcessor(new PsrLogMessageProcessor());
        $logger->pushProcessor(function (LogRecord $record): LogRecord {
            $requestId = $this->requestContext->requestId();
            if ($requestId === null) {
                return $record;
            }

            return $record->with(extra: $record->extra + ['request_id' => $requestId]);
        });
        // Se agrega de último para que Monolog lo ejecute primero (pila LIFO).
        $logger->pushProcessor(new SensitiveDataRedactor());

        return $logger;
    }
}
