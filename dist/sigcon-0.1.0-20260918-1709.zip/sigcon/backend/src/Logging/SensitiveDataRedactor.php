<?php

declare(strict_types=1);

namespace Sigcon\Logging;

use Monolog\LogRecord;
use Monolog\Processor\ProcessorInterface;

/**
 * Reemplaza por "[REDACTED]" cualquier valor del contexto cuya clave sugiera un secreto.
 * Es una red de seguridad: el código no debe enviar secretos al log en primer lugar.
 */
final class SensitiveDataRedactor implements ProcessorInterface
{
    public const MASK = '[REDACTED]';

    /** Fragmentos de clave (en minúsculas) que se consideran sensibles. */
    private const SENSITIVE_KEY_FRAGMENTS = [
        'password',
        'passwd',
        'contrasena',
        'secret',
        'token',
        'authorization',
        'cookie',
        'private_key',
        'api_key',
        'apikey',
        'credential',
        'session_id',
        'csrf',
    ];

    public function __invoke(LogRecord $record): LogRecord
    {
        return $record->with(
            context: $this->redact($record->context),
            extra: $this->redact($record->extra),
        );
    }

    /**
     * @param array<mixed> $data
     * @return array<mixed>
     */
    public function redact(array $data, int $depth = 0): array
    {
        if ($depth > 8) {
            return [self::MASK];
        }

        foreach ($data as $key => $value) {
            if (is_string($key) && $this->isSensitiveKey($key)) {
                $data[$key] = self::MASK;
            } elseif (is_array($value)) {
                $data[$key] = $this->redact($value, $depth + 1);
            }
        }

        return $data;
    }

    private function isSensitiveKey(string $key): bool
    {
        $normalized = strtolower(str_replace('-', '_', $key));
        foreach (self::SENSITIVE_KEY_FRAGMENTS as $fragment) {
            if (str_contains($normalized, $fragment)) {
                return true;
            }
        }

        return false;
    }
}
