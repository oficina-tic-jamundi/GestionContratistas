<?php

declare(strict_types=1);

namespace Sigcon\Logging;

/**
 * Datos de la solicitud actual usados por logs y auditoría.
 * PHP atiende una solicitud por proceso, así que un único objeto compartido es seguro.
 */
final class RequestContext
{
    private ?string $requestId = null;
    private ?string $ipAddress = null;
    private ?string $userAgent = null;

    public function start(string $requestId, ?string $ipAddress, ?string $userAgent): void
    {
        $this->requestId = $requestId;
        $this->ipAddress = $ipAddress;
        $this->userAgent = $userAgent === null ? null : mb_substr($userAgent, 0, 255);
    }

    public function requestId(): ?string
    {
        return $this->requestId;
    }

    public function ipAddress(): ?string
    {
        return $this->ipAddress;
    }

    public function userAgent(): ?string
    {
        return $this->userAgent;
    }
}
