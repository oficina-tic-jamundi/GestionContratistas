<?php

declare(strict_types=1);

namespace Sigcon\Logging;

/** Canales de log. Cada canal escribe en su propio archivo rotativo diario. */
enum LogChannel: string
{
    case Application = 'application';
    case Security = 'security';
    case Audit = 'audit';
    case Integrations = 'integrations';
    case GoogleDrive = 'google-drive';
    case Uploads = 'uploads';
    case Jobs = 'jobs';
}
