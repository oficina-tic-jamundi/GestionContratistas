<?php

declare(strict_types=1);

namespace Sigcon\Database;

/**
 * Divide un archivo SQL en sentencias individuales separadas por ";".
 *
 * Respeta cadenas ('...', "...", `...`), comentarios (--, #, /* *\/) y escapes.
 * No soporta DELIMITER (procedimientos almacenados/triggers): las migraciones
 * de SIGCON no los usan; la lógica de negocio vive en PHP.
 */
final class SqlStatementSplitter
{
    /** @return list<string> */
    public function split(string $sql): array
    {
        $statements = [];
        $current = '';
        $length = strlen($sql);
        $quote = null;

        for ($i = 0; $i < $length; $i++) {
            $char = $sql[$i];
            $next = $sql[$i + 1] ?? '';

            if ($quote !== null) {
                $current .= $char;
                if ($char === '\\' && $quote !== '`') {
                    $current .= $next;
                    $i++;
                } elseif ($char === $quote) {
                    if ($next === $quote) { // comilla duplicada = comilla literal
                        $current .= $next;
                        $i++;
                    } else {
                        $quote = null;
                    }
                }
                continue;
            }

            if ($char === "'" || $char === '"' || $char === '`') {
                $quote = $char;
                $current .= $char;
                continue;
            }

            $isDashComment = $char === '-' && $next === '-' && in_array($sql[$i + 2] ?? "\n", [' ', "\t", "\n", "\r"], true);
            if ($isDashComment || $char === '#') {
                $end = strpos($sql, "\n", $i);
                $i = $end === false ? $length : $end;
                $current .= "\n";
                continue;
            }

            if ($char === '/' && $next === '*') {
                $end = strpos($sql, '*/', $i + 2);
                $i = $end === false ? $length : $end + 1;
                $current .= ' ';
                continue;
            }

            if ($char === ';') {
                $this->push($statements, $current);
                $current = '';
                continue;
            }

            $current .= $char;
        }

        $this->push($statements, $current);

        return $statements;
    }

    /** @param list<string> $statements */
    private function push(array &$statements, string $statement): void
    {
        $statement = trim($statement);
        if ($statement !== '') {
            $statements[] = $statement;
        }
    }
}
