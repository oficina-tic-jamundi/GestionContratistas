<?php

declare(strict_types=1);

namespace Sigcon\Database;

use PDO;
use PDOException;
use Sigcon\Config\DatabaseSettings;

/**
 * Conexión PDO perezosa: solo se abre cuando un repositorio la necesita,
 * de modo que las rutas que no usan base de datos no fallan si MySQL no está disponible.
 *
 * Convención: todas las fechas se guardan en UTC. La conversión a America/Bogota
 * se hace en la capa de presentación (ver docs/database/conventions.md).
 */
final class Database
{
    private ?PDO $pdo = null;

    public function __construct(private readonly DatabaseSettings $settings)
    {
    }

    public function pdo(): PDO
    {
        return $this->pdo ??= $this->connect();
    }

    public function isAvailable(): bool
    {
        try {
            $this->pdo()->query('SELECT 1');

            return true;
        } catch (PDOException) {
            return false;
        }
    }

    /**
     * Ejecuta $callback dentro de una transacción. Si lanza una excepción se revierte.
     * Es reentrante: si ya hay una transacción abierta, el callback participa en ella.
     *
     * Nunca llamar APIs externas dentro de una transacción (ver ADR-005).
     *
     * @template T
     * @param callable(PDO): T $callback
     * @return T
     */
    public function transaction(callable $callback): mixed
    {
        $pdo = $this->pdo();
        if ($pdo->inTransaction()) {
            return $callback($pdo);
        }

        $pdo->beginTransaction();
        try {
            $result = $callback($pdo);
            $pdo->commit();

            return $result;
        } catch (\Throwable $e) {
            try {
                $pdo->rollBack();
            } catch (PDOException) {
                // La transacción ya no estaba activa (ej. confirmación implícita por DDL).
            }
            throw $e;
        }
    }

    /**
     * Ejecuta una consulta preparada y devuelve todas las filas como arreglos asociativos.
     *
     * @param array<int|string, mixed> $params
     * @return list<array<string, mixed>>
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->pdo()->prepare($sql);
        $stmt->execute($params);
        $rows = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            if (is_array($row)) {
                $rows[] = $row;
            }
        }

        return $rows;
    }

    /** Violación de índice único (MySQL/MariaDB error 1062). */
    public static function isUniqueViolation(PDOException $e): bool
    {
        return ($e->errorInfo[1] ?? null) === 1062;
    }

    private function connect(): PDO
    {
        $pdo = new PDO($this->settings->dsn(), $this->settings->username, $this->settings->password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Prepared statements reales en el servidor (no emulados).
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        $pdo->exec("SET time_zone = '+00:00', sql_mode = 'STRICT_ALL_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,ONLY_FULL_GROUP_BY'");

        return $pdo;
    }
}
