<?php

declare(strict_types=1);

namespace Sigcon\Database;

use PDO;
use RuntimeException;

/**
 * Ejecuta migraciones SQL versionadas desde database/migrations.
 *
 * Reglas:
 * - Archivos "AAAAMMDDHHMMSS_descripcion.sql", aplicados en orden.
 * - Solo hacia adelante: para corregir una migración aplicada se crea una nueva.
 * - Se guarda el checksum de cada archivo aplicado; si un archivo aplicado cambia,
 *   el proceso se detiene (nunca se reescribe la historia de producción).
 * - MySQL confirma implícitamente el DDL, así que una migración con varias sentencias
 *   no es atómica: cada archivo debe ser pequeño y enfocado.
 * - Un lock de MySQL evita ejecuciones simultáneas.
 */
final class Migrator
{
    private const FILE_PATTERN = '/^(\d{14})_[a-z0-9_]+\.sql$/';
    private const LOCK_NAME = 'sigcon_migrations';

    public function __construct(
        private readonly Database $database,
        private readonly SqlStatementSplitter $splitter,
        private readonly string $migrationsPath,
    ) {
    }

    /**
     * @param callable(string): void $onApplied
     * @return list<string> versiones aplicadas en esta ejecución
     */
    public function migrate(callable $onApplied): array
    {
        $pdo = $this->database->pdo();
        $this->ensureTable($pdo);
        $this->acquireLock($pdo);

        try {
            $applied = $this->appliedMigrations($pdo);
            $this->assertNoModifiedMigrations($applied);

            $ran = [];
            foreach ($this->availableMigrations() as $name => $path) {
                if (isset($applied[$name])) {
                    continue;
                }
                $this->run($pdo, $name, $path);
                $onApplied($name);
                $ran[] = $name;
            }

            return $ran;
        } finally {
            $pdo->query("SELECT RELEASE_LOCK('" . self::LOCK_NAME . "')");
        }
    }

    /**
     * @return list<array{migration: string, status: string, applied_at: ?string}>
     */
    public function status(): array
    {
        $pdo = $this->database->pdo();
        $this->ensureTable($pdo);
        $applied = $this->appliedMigrations($pdo);
        $available = $this->availableMigrations();

        $rows = [];
        foreach ($available as $name => $path) {
            $row = $applied[$name] ?? null;
            $status = match (true) {
                $row === null => 'pending',
                $row['checksum'] !== $this->checksum($path) => 'modified',
                default => 'applied',
            };
            $rows[] = ['migration' => $name, 'status' => $status, 'applied_at' => $row['applied_at'] ?? null];
        }
        foreach ($applied as $name => $row) {
            if (!isset($available[$name])) {
                $rows[] = ['migration' => $name, 'status' => 'missing-file', 'applied_at' => $row['applied_at']];
            }
        }

        return $rows;
    }

    /** @return array<string, string> nombre => ruta, ordenado */
    public function availableMigrations(): array
    {
        if (!is_dir($this->migrationsPath)) {
            throw new RuntimeException(sprintf('No existe el directorio de migraciones: %s', $this->migrationsPath));
        }

        $files = [];
        foreach (scandir($this->migrationsPath) ?: [] as $file) {
            if (preg_match(self::FILE_PATTERN, $file) === 1) {
                $files[$file] = $this->migrationsPath . DIRECTORY_SEPARATOR . $file;
            }
        }
        ksort($files, SORT_STRING);

        return $files;
    }

    private function run(PDO $pdo, string $name, string $path): void
    {
        $sql = file_get_contents($path);
        if ($sql === false) {
            throw new RuntimeException(sprintf('No se pudo leer la migración %s', $name));
        }

        $start = hrtime(true);
        foreach ($this->splitter->split($sql) as $index => $statement) {
            try {
                $pdo->exec($statement);
            } catch (\PDOException $e) {
                throw new RuntimeException(
                    sprintf('Falló la migración %s en la sentencia #%d: %s', $name, $index + 1, $e->getMessage()),
                    0,
                    $e,
                );
            }
        }
        $elapsedMs = (int) ((hrtime(true) - $start) / 1_000_000);

        $insert = $pdo->prepare(
            'INSERT INTO schema_migrations (migration, checksum, execution_ms, applied_at) VALUES (:migration, :checksum, :ms, UTC_TIMESTAMP())',
        );
        $insert->execute(['migration' => $name, 'checksum' => $this->checksum($path), 'ms' => $elapsedMs]);
    }

    private function ensureTable(PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS schema_migrations (
                migration VARCHAR(191) NOT NULL PRIMARY KEY,
                checksum CHAR(64) NOT NULL,
                execution_ms INT UNSIGNED NOT NULL,
                applied_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        );
    }

    private function acquireLock(PDO $pdo): void
    {
        $result = $pdo->query("SELECT GET_LOCK('" . self::LOCK_NAME . "', 10)");
        if ($result === false || (int) $result->fetchColumn() !== 1) {
            throw new RuntimeException('Otra ejecución de migraciones está en curso.');
        }
    }

    /** @return array<string, array{checksum: string, applied_at: string}> */
    private function appliedMigrations(PDO $pdo): array
    {
        $rows = [];
        $statement = $pdo->query('SELECT migration, checksum, applied_at FROM schema_migrations');
        if ($statement === false) {
            return $rows;
        }
        foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
            /** @var array{migration: string, checksum: string, applied_at: string} $row */
            $rows[$row['migration']] = ['checksum' => $row['checksum'], 'applied_at' => $row['applied_at']];
        }

        return $rows;
    }

    /** @param array<string, array{checksum: string, applied_at: string}> $applied */
    private function assertNoModifiedMigrations(array $applied): void
    {
        foreach ($this->availableMigrations() as $name => $path) {
            if (isset($applied[$name]) && $applied[$name]['checksum'] !== $this->checksum($path)) {
                throw new RuntimeException(sprintf(
                    'La migración %s ya fue aplicada y su archivo cambió. Cree una nueva migración en lugar de modificarla.',
                    $name,
                ));
            }
        }
    }

    private function checksum(string $path): string
    {
        // Se normalizan los saltos de línea para que el checksum no dependa del sistema operativo.
        $contents = str_replace("\r\n", "\n", (string) file_get_contents($path));

        return hash('sha256', $contents);
    }
}
