<?php

declare(strict_types=1);

namespace Sigcon\Storage;

use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UploadedFileInterface;

/**
 * Almacenamiento de archivos privados (ADR-003). Los servicios no conocen rutas físicas:
 * cambiar a otro proveedor (ej. almacenamiento de objetos) es cambiar esta implementación.
 */
interface FileStorage
{
    /** Guarda el archivo recibido en la ruta relativa indicada. */
    public function storeUpload(UploadedFileInterface $file, string $relativePath): void;

    /** Guarda un contenido generado por el sistema (ej. imágenes procesadas, PDF). */
    public function storeContents(string $contents, string $relativePath): void;

    public function exists(string $relativePath): bool;

    /** Flujo de lectura para transmitir el archivo sin cargarlo completo en memoria. */
    public function readStream(string $relativePath): StreamInterface;

    public function delete(string $relativePath): void;
}
