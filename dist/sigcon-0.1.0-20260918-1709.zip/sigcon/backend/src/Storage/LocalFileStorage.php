<?php

declare(strict_types=1);

namespace Sigcon\Storage;

use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UploadedFileInterface;
use RuntimeException;
use Sigcon\Config\Settings;
use Slim\Psr7\Stream;

/**
 * Almacenamiento en disco local, dentro de STORAGE_PATH (fuera del document root).
 *
 * Las rutas relativas las genera el sistema (uuid + extensión validada); aun así se
 * rechaza cualquier ruta que intente salir del directorio base.
 */
final class LocalFileStorage implements FileStorage
{
    private readonly string $base;

    public function __construct(Settings $settings)
    {
        $this->base = rtrim($settings->storagePath, '/\\');
    }

    public function storeUpload(UploadedFileInterface $file, string $relativePath): void
    {
        $target = $this->absolute($relativePath);
        $this->ensureDirectory(dirname($target));
        // En peticiones HTTP, UploadedFile::moveTo usa move_uploaded_file (verifica que el
        // archivo provenga realmente de una carga HTTP).
        $file->moveTo($target);
        @chmod($target, 0640);
    }

    public function storeContents(string $contents, string $relativePath): void
    {
        $target = $this->absolute($relativePath);
        $this->ensureDirectory(dirname($target));
        if (file_put_contents($target, $contents, LOCK_EX) === false) {
            throw new RuntimeException('No fue posible escribir el archivo en el almacenamiento.');
        }
        @chmod($target, 0640);
    }

    public function exists(string $relativePath): bool
    {
        return is_file($this->absolute($relativePath));
    }

    public function readStream(string $relativePath): StreamInterface
    {
        $path = $this->absolute($relativePath);
        $handle = is_file($path) ? fopen($path, 'rb') : false;
        if ($handle === false) {
            throw new RuntimeException('Archivo no disponible en el almacenamiento.');
        }

        return new Stream($handle);
    }

    public function delete(string $relativePath): void
    {
        $path = $this->absolute($relativePath);
        if (is_file($path)) {
            unlink($path);
        }
    }

    private function absolute(string $relativePath): string
    {
        if ($relativePath === '' || str_contains($relativePath, '..') || str_contains($relativePath, "\0")
            || preg_match('/^[A-Za-z0-9_\/.-]+$/', $relativePath) !== 1 || str_starts_with($relativePath, '/')) {
            throw new RuntimeException('Ruta de almacenamiento no válida.');
        }

        return $this->base . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
    }

    private function ensureDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
            throw new RuntimeException('No fue posible crear el directorio de almacenamiento.');
        }
    }
}
