<?php

declare(strict_types=1);

namespace Sigcon\Models;

/**
 * Tipos de documento de identificación admitidos. Los patrones validan la forma (sin puntos
 * ni guiones), no la existencia del documento.
 */
enum DocumentType: string
{
    case CC = 'CC';
    case CE = 'CE';
    case PPT = 'PPT';
    case PA = 'PA';
    case NIT = 'NIT';

    public function label(): string
    {
        return match ($this) {
            self::CC => 'Cédula de ciudadanía',
            self::CE => 'Cédula de extranjería',
            self::PPT => 'Permiso por protección temporal',
            self::PA => 'Pasaporte',
            self::NIT => 'NIT',
        };
    }

    public function pattern(): string
    {
        return match ($this) {
            self::CC => '/^[0-9]{3,10}$/',
            self::NIT => '/^[0-9]{6,15}$/',
            self::CE, self::PPT, self::PA => '/^[A-Z0-9]{3,20}$/',
        };
    }

    public function formatHint(): string
    {
        return match ($this) {
            self::CC => 'Solo números, sin puntos (3 a 10 dígitos).',
            self::NIT => 'Solo números, sin puntos ni dígito de verificación (6 a 15 dígitos).',
            self::CE, self::PPT, self::PA => 'Letras y números, sin espacios ni guiones (3 a 20 caracteres).',
        };
    }
}
