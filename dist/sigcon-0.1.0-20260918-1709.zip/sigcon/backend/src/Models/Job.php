<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Job
{
    /** @param array<string, mixed> $payload */
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly string $type,
        public readonly array $payload,
        public readonly ?string $dedupeKey,
        public readonly JobStatus $status,
        public readonly int $attempts,
        public readonly int $maxAttempts,
        public readonly DateTimeImmutable $availableAt,
        public readonly ?DateTimeImmutable $lockedUntil,
        public readonly ?string $lockedBy,
        public readonly ?string $lastError,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $updatedAt,
        public readonly ?DateTimeImmutable $completedAt,
        public readonly ?DateTimeImmutable $failedAt,
    ) {
    }
}
