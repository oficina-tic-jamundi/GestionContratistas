<?php

declare(strict_types=1);

namespace Sigcon\Models;

/**
 * pending → processing → completed
 *              └──(error)──► pending (reintento con espera) … → failed (agotó los intentos)
 * failed ──reintento manual──► pending
 */
enum JobStatus: string
{
    case Pending = 'pending';
    case Processing = 'processing';
    case Completed = 'completed';
    case Failed = 'failed';

    public function label(): string
    {
        return match ($this) {
            self::Pending => 'Pendiente',
            self::Processing => 'En proceso',
            self::Completed => 'Completado',
            self::Failed => 'Fallido',
        };
    }
}
