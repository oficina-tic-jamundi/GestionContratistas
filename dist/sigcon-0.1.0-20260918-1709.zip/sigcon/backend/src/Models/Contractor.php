<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Contractor
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly PersonType $personType,
        public readonly DocumentType $documentType,
        public readonly string $documentNumber,
        public readonly ?int $verificationDigit,
        public readonly string $name,
        public readonly ?string $email,
        public readonly ?string $phone,
        public readonly ?string $address,
        public readonly ActiveStatus $status,
        public readonly ?int $userId,
        public readonly ?string $userUuid,
        public readonly ?string $userEmail,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $updatedAt,
    ) {
    }

    /** Documento para mostrar: "CC 1234567" o "NIT 900123456-7". */
    public function displayDocument(): string
    {
        $number = $this->verificationDigit === null
            ? $this->documentNumber
            : $this->documentNumber . '-' . $this->verificationDigit;

        return $this->documentType->value . ' ' . $number;
    }

    public function isActive(): bool
    {
        return $this->status === ActiveStatus::Active;
    }
}
