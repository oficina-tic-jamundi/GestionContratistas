<?php

declare(strict_types=1);

namespace Sigcon\Models;

/**
 * Estados del contrato y transiciones permitidas.
 *
 * IMPORTANTE: el grafo de transiciones es una PROPUESTA técnica pendiente de validación por la
 * Oficina Jurídica de la Alcaldía (ver ADR-012). Está centralizado aquí para poder ajustarlo sin
 * tocar servicios, controladores ni interfaz.
 *
 *   draft ──► active ──► suspended ──► active (reanudación)
 *               │            │
 *               └──► terminated ◄──┘
 *                        │
 *                        ├──► liquidated ──► archived
 *                        └──► archived
 */
enum ContractStatus: string
{
    case Draft = 'draft';
    case Active = 'active';
    case Suspended = 'suspended';
    case Terminated = 'terminated';
    case Liquidated = 'liquidated';
    case Archived = 'archived';

    public function label(): string
    {
        return match ($this) {
            self::Draft => 'Borrador',
            self::Active => 'Activo',
            self::Suspended => 'Suspendido',
            self::Terminated => 'Terminado',
            self::Liquidated => 'Liquidado',
            self::Archived => 'Archivado',
        };
    }

    /** @return list<self> */
    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Draft => [self::Active],
            self::Active => [self::Suspended, self::Terminated],
            self::Suspended => [self::Active, self::Terminated],
            self::Terminated => [self::Liquidated, self::Archived],
            self::Liquidated => [self::Archived],
            self::Archived => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }

    /**
     * Las transiciones que alteran la ejecución normal exigen una observación escrita
     * (queda en el historial de negocio).
     */
    public function transitionRequiresComment(self $target): bool
    {
        return $target !== self::Archived && !($this === self::Draft && $target === self::Active);
    }

    /** Verbo para el historial ("Contrato activado", "Contrato suspendido", ...). */
    public function transitionSummary(self $from): string
    {
        return match ($this) {
            self::Active => $from === self::Suspended ? 'Contrato reanudado' : 'Contrato activado',
            self::Suspended => 'Contrato suspendido',
            self::Terminated => 'Contrato terminado',
            self::Liquidated => 'Contrato liquidado',
            self::Archived => 'Contrato archivado',
            self::Draft => 'Contrato en borrador',
        };
    }

    /** Solo el borrador admite edición libre; los cambios posteriores requieren otrosí (pendiente, ADR-012). */
    public function isEditable(): bool
    {
        return $this === self::Draft;
    }

    /** El supervisor puede cambiarse (designación) mientras el contrato no haya terminado. */
    public function allowsSupervisorChange(): bool
    {
        return in_array($this, [self::Draft, self::Active, self::Suspended], true);
    }
}
