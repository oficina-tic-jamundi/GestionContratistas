<?php

declare(strict_types=1);

namespace Sigcon\Models;

final class Department
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly string $code,
        public readonly string $name,
        public readonly ActiveStatus $status,
        public readonly int $activeContracts = 0,
    ) {
    }

    public function isActive(): bool
    {
        return $this->status === ActiveStatus::Active;
    }
}
