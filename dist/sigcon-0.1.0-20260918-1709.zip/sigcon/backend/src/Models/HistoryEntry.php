<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class HistoryEntry
{
    /** @param array<mixed>|null $metadata */
    public function __construct(
        public readonly int $id,
        public readonly string $event,
        public readonly string $summary,
        public readonly ?string $comment,
        public readonly ?string $fromStatus,
        public readonly ?string $toStatus,
        public readonly ?string $userName,
        public readonly DateTimeImmutable $occurredAt,
        public readonly ?array $metadata,
    ) {
    }
}
