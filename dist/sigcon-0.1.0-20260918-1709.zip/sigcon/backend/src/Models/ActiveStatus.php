<?php

declare(strict_types=1);

namespace Sigcon\Models;

/** Estado de registros de catálogo que no se eliminan, solo se desactivan (dependencias, contratistas). */
enum ActiveStatus: string
{
    case Active = 'active';
    case Inactive = 'inactive';

    public function label(): string
    {
        return match ($this) {
            self::Active => 'Activo',
            self::Inactive => 'Inactivo',
        };
    }
}
