<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Payment
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly int $contractId,
        public readonly string $contractUuid,
        public readonly string $contractNumber,
        public readonly string $contractorName,
        public readonly int $reportId,
        public readonly string $reportUuid,
        public readonly int $reportNumber,
        public readonly DateTimeImmutable $periodStart,
        public readonly DateTimeImmutable $periodEnd,
        public readonly int $number,
        public readonly string $amount,
        public readonly ?string $notes,
        public readonly PaymentStatus $status,
        public readonly ?bool $lastEligible,
        public readonly ?DateTimeImmutable $lastEvaluatedAt,
        public readonly int $createdBy,
        public readonly string $createdByName,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $updatedAt,
        public readonly ?int $submittedBy,
        public readonly ?DateTimeImmutable $submittedAt,
        public readonly ?string $approvedByName,
        public readonly ?DateTimeImmutable $approvedAt,
        public readonly ?DateTimeImmutable $paymentDate,
        public readonly ?string $paymentReference,
        public readonly ?string $paidRegisteredByName,
        public readonly ?string $cancelledReason,
        public readonly ?DateTimeImmutable $cancelledAt,
    ) {
    }
}
