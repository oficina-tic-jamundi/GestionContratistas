<?php

declare(strict_types=1);

namespace Sigcon\Models;

enum PersonType: string
{
    case Natural = 'natural';
    case Juridica = 'juridica';

    public function label(): string
    {
        return match ($this) {
            self::Natural => 'Persona natural',
            self::Juridica => 'Persona jurídica',
        };
    }

    /** @return list<DocumentType> tipos de documento válidos para este tipo de persona */
    public function allowedDocumentTypes(): array
    {
        return match ($this) {
            self::Natural => [DocumentType::CC, DocumentType::CE, DocumentType::PPT, DocumentType::PA, DocumentType::NIT],
            self::Juridica => [DocumentType::NIT],
        };
    }
}
