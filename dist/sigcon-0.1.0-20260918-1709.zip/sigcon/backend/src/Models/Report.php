<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Report
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly int $contractId,
        public readonly string $contractUuid,
        public readonly string $contractNumber,
        public readonly string $contractorName,
        public readonly int $number,
        public readonly DateTimeImmutable $periodStart,
        public readonly DateTimeImmutable $periodEnd,
        public readonly ReportStatus $status,
        public readonly ?string $summary,
        public readonly ?string $contractorNotes,
        public readonly int $currentVersion,
        public readonly ?int $approvedVersion,
        public readonly ?DateTimeImmutable $approvedAt,
        public readonly ?string $approvedByName,
        public readonly int $createdBy,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $updatedAt,
    ) {
    }
}
