<?php

declare(strict_types=1);

namespace Sigcon\Models;

/**
 * Estados del informe (§19, ADR-015).
 *
 *   draft ──enviar──► submitted ──iniciar revisión──► in_review ──aprobar──► approved
 *                                                        │   └──rechazar──► rejected
 *                                                        └──observar──► observed
 *   observed ──corregir y reenviar──► resubmitted ──iniciar revisión──► in_review
 *   approved ──reabrir (con motivo)──► observed
 */
enum ReportStatus: string
{
    case Draft = 'draft';
    case Submitted = 'submitted';
    case InReview = 'in_review';
    case Observed = 'observed';
    case Resubmitted = 'resubmitted';
    case Approved = 'approved';
    case Rejected = 'rejected';

    public function label(): string
    {
        return match ($this) {
            self::Draft => 'Borrador',
            self::Submitted => 'Enviado',
            self::InReview => 'En revisión',
            self::Observed => 'Con observaciones',
            self::Resubmitted => 'Corregido (reenviado)',
            self::Approved => 'Aprobado',
            self::Rejected => 'Rechazado',
        };
    }

    /** El contratista solo edita en borrador o cuando el supervisor pidió correcciones. */
    public function isEditable(): bool
    {
        return $this === self::Draft || $this === self::Observed;
    }

    public function canBeSubmitted(): bool
    {
        return $this->isEditable();
    }

    public function submittedStatus(): self
    {
        return $this === self::Observed ? self::Resubmitted : self::Submitted;
    }

    public function awaitsReview(): bool
    {
        return $this === self::Submitted || $this === self::Resubmitted;
    }

    /**
     * Un informe rechazado no cuenta para el cruce de períodos: se puede presentar otro
     * informe para el mismo período.
     */
    public function occupiesPeriod(): bool
    {
        return $this !== self::Rejected;
    }
}
