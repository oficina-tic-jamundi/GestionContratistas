<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Session
{
    public function __construct(
        public readonly int $id,
        public readonly int $userId,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $lastActivityAt,
        public readonly DateTimeImmutable $expiresAt,
        public readonly ?DateTimeImmutable $revokedAt,
    ) {
    }
}
