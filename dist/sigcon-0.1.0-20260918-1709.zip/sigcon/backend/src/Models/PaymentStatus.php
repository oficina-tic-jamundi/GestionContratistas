<?php

declare(strict_types=1);

namespace Sigcon\Models;

/**
 * Estados del pago (ADR-018):
 *
 *   draft ──enviar (si es elegible)──► ready_for_approval ──aprobar (si sigue elegible)──► approved ──registrar pago──► paid
 *     ▲                                      │
 *     └──────────devolver (con motivo)───────┘
 *   draft | ready_for_approval ──anular (con motivo)──► cancelled
 */
enum PaymentStatus: string
{
    case Draft = 'draft';
    case ReadyForApproval = 'ready_for_approval';
    case Approved = 'approved';
    case Paid = 'paid';
    case Cancelled = 'cancelled';

    public function label(): string
    {
        return match ($this) {
            self::Draft => 'En preparación',
            self::ReadyForApproval => 'Listo para aprobación',
            self::Approved => 'Aprobado',
            self::Paid => 'Pagado',
            self::Cancelled => 'Anulado',
        };
    }

    public function isEditable(): bool
    {
        return $this === self::Draft;
    }

    public function isCancellable(): bool
    {
        return $this === self::Draft || $this === self::ReadyForApproval;
    }

    /** Cuenta para el valor comprometido del contrato. */
    public function commitsBudget(): bool
    {
        return $this !== self::Cancelled;
    }
}
