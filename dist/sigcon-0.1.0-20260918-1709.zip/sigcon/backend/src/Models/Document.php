<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Document
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly string $entityType,
        public readonly int $entityId,
        public readonly string $typeCode,
        public readonly string $typeName,
        public readonly ?string $description,
        public readonly string $originalName,
        public readonly string $extension,
        public readonly string $mimeType,
        public readonly int $sizeBytes,
        public readonly string $sha256,
        public readonly string $storagePath,
        public readonly string $status,
        public readonly ?string $withdrawnReason,
        public readonly ?DateTimeImmutable $withdrawnAt,
        public readonly ?string $withdrawnByName,
        public readonly int $uploadedBy,
        public readonly string $uploadedByName,
        public readonly DateTimeImmutable $createdAt,
    ) {
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
