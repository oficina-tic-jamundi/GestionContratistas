<?php

declare(strict_types=1);

namespace Sigcon\Models;

final class Role
{
    public const ADMIN = 'admin';

    /**
     * @param list<string> $permissions códigos de permiso
     */
    public function __construct(
        public readonly int $id,
        public readonly string $code,
        public readonly string $name,
        public readonly ?string $description,
        public readonly bool $isSystem,
        public readonly array $permissions = [],
        public readonly int $userCount = 0,
    ) {
    }
}
