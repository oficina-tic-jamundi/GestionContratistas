<?php

declare(strict_types=1);

namespace Sigcon\Models;

/** Niveles del árbol de ejecución contractual. */
enum ActivityLevel: string
{
    case Obligation = 'obligation';
    case Task = 'task';
    case Subtask = 'subtask';

    public function label(): string
    {
        return match ($this) {
            self::Obligation => 'Obligación',
            self::Task => 'Tarea',
            self::Subtask => 'Subtarea',
        };
    }

    /** Nivel que pueden tener sus hijos (null = no admite hijos). */
    public function childLevel(): ?self
    {
        return match ($this) {
            self::Obligation => self::Task,
            self::Task => self::Subtask,
            self::Subtask => null,
        };
    }
}
