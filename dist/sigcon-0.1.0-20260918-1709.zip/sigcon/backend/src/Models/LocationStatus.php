<?php

declare(strict_types=1);

namespace Sigcon\Models;

/**
 * Estado de la ubicación de una evidencia. Nunca se inventan coordenadas: si el dispositivo no
 * las entregó, el estado explica por qué (ADR-006).
 */
enum LocationStatus: string
{
    case Ok = 'ok';
    case LowAccuracy = 'low_accuracy';
    case Denied = 'denied';
    case Unavailable = 'unavailable';
    case Timeout = 'timeout';

    public function label(): string
    {
        return match ($this) {
            self::Ok => 'Ubicación registrada',
            self::LowAccuracy => 'Ubicación de baja precisión',
            self::Denied => 'Ubicación no disponible: permiso denegado',
            self::Unavailable => 'Ubicación no disponible en el dispositivo',
            self::Timeout => 'Ubicación no disponible: tiempo de espera agotado',
        };
    }

    public function hasCoordinates(): bool
    {
        return $this === self::Ok || $this === self::LowAccuracy;
    }
}
