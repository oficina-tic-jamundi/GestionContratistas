<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

final class Evidence
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly int $contractId,
        public readonly int $activityId,
        public readonly string $activityUuid,
        public readonly string $activityTitle,
        public readonly ActivityLevel $activityLevel,
        public readonly ?string $description,
        public readonly string $originalPath,
        public readonly string $originalMime,
        public readonly int $originalSizeBytes,
        public readonly string $originalSha256,
        public readonly int $width,
        public readonly int $height,
        public readonly string $officialPath,
        public readonly string $officialSha256,
        public readonly string $thumbnailPath,
        public readonly LocationStatus $locationStatus,
        public readonly ?string $latitude,
        public readonly ?string $longitude,
        public readonly ?string $accuracyM,
        public readonly ?string $altitudeM,
        public readonly ?string $headingDeg,
        public readonly ?string $speedMps,
        public readonly ?DateTimeImmutable $locationCapturedAt,
        public readonly ?DateTimeImmutable $deviceCapturedAt,
        public readonly DateTimeImmutable $capturedAt,
        public readonly int $capturedBy,
        public readonly string $capturedByName,
        public readonly string $status,
        public readonly ?string $withdrawnReason,
        public readonly ?DateTimeImmutable $withdrawnAt,
        public readonly ?string $withdrawnByName,
    ) {
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
