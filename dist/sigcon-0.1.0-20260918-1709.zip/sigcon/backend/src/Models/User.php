<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

/**
 * Usuario del sistema. No incluye el hash de la contraseña: este se obtiene aparte
 * (UserRepository::findPasswordHash) solo cuando se necesita verificar credenciales.
 */
final class User
{
    public function __construct(
        public readonly int $id,
        public readonly string $uuid,
        public readonly string $firstName,
        public readonly string $lastName,
        public readonly string $email,
        public readonly ?string $phone,
        public readonly UserStatus $status,
        public readonly bool $mustChangePassword,
        public readonly ?DateTimeImmutable $lastLoginAt,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $updatedAt,
        public readonly ?int $departmentId = null,
        public readonly ?string $departmentUuid = null,
        public readonly ?string $departmentCode = null,
        public readonly ?string $departmentName = null,
    ) {
    }

    public function fullName(): string
    {
        return trim($this->firstName . ' ' . $this->lastName);
    }

    public function isActive(): bool
    {
        return $this->status === UserStatus::Active;
    }
}
