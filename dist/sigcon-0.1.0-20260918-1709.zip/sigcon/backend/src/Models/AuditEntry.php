<?php

declare(strict_types=1);

namespace Sigcon\Models;

use DateTimeImmutable;

/** Registro de auditoría tal como se consulta (con los datos públicos del usuario que actuó). */
final class AuditEntry
{
    /**
     * @param array<mixed>|null $metadata
     */
    public function __construct(
        public readonly int $id,
        public readonly DateTimeImmutable $occurredAt,
        public readonly string $action,
        public readonly ?string $entityType,
        public readonly ?string $entityId,
        public readonly ?string $ipAddress,
        public readonly ?string $userAgent,
        public readonly ?string $requestId,
        public readonly ?array $metadata,
        public readonly ?string $userUuid,
        public readonly ?string $userName,
        public readonly ?string $userEmail,
    ) {
    }
}
