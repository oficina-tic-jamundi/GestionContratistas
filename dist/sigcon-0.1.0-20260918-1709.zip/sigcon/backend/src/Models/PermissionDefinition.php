<?php

declare(strict_types=1);

namespace Sigcon\Models;

/** Permiso tal como está registrado en el catálogo de la base de datos. */
final class PermissionDefinition
{
    public function __construct(
        public readonly string $code,
        public readonly string $module,
        public readonly string $description,
    ) {
    }
}
