<?php

declare(strict_types=1);

/**
 * Front controller de la API.
 *
 * En cPanel, el document root público solo contiene un index.php mínimo que incluye
 * este archivo con una ruta absoluta (ver docs/deployment/cpanel.md). Así el código,
 * vendor/, .env y storage/ quedan fuera del directorio público.
 */

use Sigcon\Bootstrap\Kernel;

// PHP la agrega por su cuenta (expose_php); no revelar la versión del servidor.
header_remove('X-Powered-By');

$rootPath = dirname(__DIR__);

require $rootPath . '/vendor/autoload.php';

try {
    $container = Kernel::container($rootPath);
} catch (Throwable $e) {
    // La aplicación no pudo arrancar (configuración inválida). No se exponen detalles.
    error_log('[SIGCON] Error de arranque: ' . $e->getMessage());
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'data' => null,
        'message' => 'El servicio no está disponible temporalmente.',
        'errors' => [],
        'meta' => ['code' => 'service_unavailable'],
    ]);
    exit;
}

Kernel::http($container)->run();
