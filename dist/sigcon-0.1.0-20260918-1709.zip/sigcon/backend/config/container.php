<?php

declare(strict_types=1);

/**
 * Definiciones del contenedor de dependencias (PHP-DI).
 * Las clases concretas sin configuración especial se resuelven por autowiring;
 * aquí solo se declaran las que necesitan parámetros o una fábrica.
 */

use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Log\LoggerInterface;
use Sigcon\Config\BackupSettings;
use Sigcon\Config\EvidenceSettings;
use Sigcon\Config\JobSettings;
use Sigcon\Config\SecuritySettings;
use Sigcon\Config\Settings;
use Sigcon\Helpers\Clock;
use Sigcon\Helpers\SystemClock;
use Sigcon\Storage\FileStorage;
use Sigcon\Storage\LocalFileStorage;
use Sigcon\Database\Database;
use Sigcon\Database\Migrator;
use Sigcon\Database\SqlStatementSplitter;
use Sigcon\Logging\LogChannel;
use Sigcon\Logging\LoggerFactory;
use Sigcon\Repositories\JobRepository;
use Sigcon\Repositories\PaymentRuleSettingsRepository;
use Sigcon\Security\AuthContext;
use Sigcon\Services\AI\AIProviderInterface;
use Sigcon\Services\AI\DisabledAIProvider;
use Sigcon\Services\Audit\AuditLogger;
use Sigcon\Services\Notifications\NotificationService;
use Sigcon\Services\Payments\PaymentEligibilityService;
use Sigcon\Services\Payments\Rules\ContractActiveRule;
use Sigcon\Services\Payments\Rules\MinEvidencesRule;
use Sigcon\Services\Payments\Rules\MinProgressRule;
use Sigcon\Services\Payments\Rules\NoPendingObservationsRule;
use Sigcon\Services\Payments\Rules\ReportApprovedRule;
use Sigcon\Services\Payments\Rules\RequiredDocumentsRule;
use Sigcon\Services\Jobs\JobRunner;
use Sigcon\Services\Reports\Pdf\ReportPdfHandler;
use Slim\Psr7\Factory\ResponseFactory;

return [
    ResponseFactoryInterface::class => static fn (): ResponseFactoryInterface => new ResponseFactory(),

    Database::class => static fn (Settings $settings): Database => new Database($settings->database),

    Migrator::class => static fn (Database $db, Settings $settings): Migrator => new Migrator(
        $db,
        new SqlStatementSplitter(),
        $settings->migrationsPath,
    ),

    Clock::class => static fn (): Clock => new SystemClock(),

    FileStorage::class => static fn (Settings $settings): FileStorage => new LocalFileStorage($settings),

    SecuritySettings::class => static fn (Settings $settings): SecuritySettings => $settings->security,
    EvidenceSettings::class => static fn (Settings $settings): EvidenceSettings => $settings->evidence,
    JobSettings::class => static fn (Settings $settings): JobSettings => $settings->jobs,
    BackupSettings::class => static fn (Settings $settings): BackupSettings => $settings->backup,

    LoggerInterface::class => static fn (LoggerFactory $factory): LoggerInterface => $factory->channel(LogChannel::Application),

    // IA (ADR-008): deshabilitada. Settings rechaza cualquier otro valor de AI_PROVIDER.
    AIProviderInterface::class => static fn (): AIProviderInterface => new DisabledAIProvider(),

    // Reglas de elegibilidad de pagos (ADR-007, ADR-018). Cada regla nueva se registra aquí.
    PaymentEligibilityService::class => static fn (ContainerInterface $c): PaymentEligibilityService => new PaymentEligibilityService(
        [
            $c->get(ContractActiveRule::class),
            $c->get(ReportApprovedRule::class),
            $c->get(NoPendingObservationsRule::class),
            $c->get(RequiredDocumentsRule::class),
            $c->get(MinEvidencesRule::class),
            $c->get(MinProgressRule::class),
        ],
        $c->get(PaymentRuleSettingsRepository::class),
        $c->get(AuditLogger::class),
        $c->get(AuthContext::class),
        $c->get(Clock::class),
    ),

    // Procesadores de la cola de trabajos (ADR-017). Cada tipo nuevo se registra aquí.
    JobRunner::class => static fn (ContainerInterface $c): JobRunner => new JobRunner(
        [$c->get(ReportPdfHandler::class)],
        $c->get(JobRepository::class),
        $c->get(JobSettings::class),
        $c->get(Clock::class),
        $c->get(LoggerInterface::class),
        $c->get(NotificationService::class),
    ),
];
